(define A (make-accumulator 5))
(A 10)
