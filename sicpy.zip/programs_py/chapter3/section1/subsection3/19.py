def make_account(balance):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return "Insufficient funds"
    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance
    def dispatch(m):
        return (withdraw if m == "withdraw"
                else deposit if m == "deposit"
                else error("unknown request -- make_account", m))
    return dispatch
peter_acc = make_account(100)
paul_acc = peter_acc
peter_acc("withdraw")(10)
peter_acc("withdraw")(20)
print(paul_acc("withdraw")(50))

# expected: 20
