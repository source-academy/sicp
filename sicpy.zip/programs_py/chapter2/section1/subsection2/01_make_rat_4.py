def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)
def make_rat(n, d):
    return pair(n, d)
def numer(x):
    g = gcd(head(x), tail(x))
    return head(x) // g
def denom(x):
    g = gcd(head(x), tail(x))
    return tail(x) // g

one_half = make_rat(1, 2)

print(one_half)

# expected: [ 1, 2 ]
