def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def pi_sum(a, b):
    def pi_term(x):
        return 1 / (x * (x + 2))
    def pi_next(x):
        return x + 4
    return sum(pi_term, a, pi_next, b)
print(8 * pi_sum(1, 1000))
