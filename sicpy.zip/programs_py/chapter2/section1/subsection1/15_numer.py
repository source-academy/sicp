def numer(x):
    return head(x)
def denom(x):
    return tail(x)
