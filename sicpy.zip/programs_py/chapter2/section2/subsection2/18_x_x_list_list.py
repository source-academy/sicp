x = llist(llist(1, 2), llist(3, 4))
print_llist(x)
