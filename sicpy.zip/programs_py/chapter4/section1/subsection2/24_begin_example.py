def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
my_sequence = parse('1\nTrue\n45')
print(is_sequence(my_sequence))
my_actions = sequence_statements(my_sequence)
print(is_empty_sequence(my_actions))
print(is_last_statement(my_actions))
print(first_statement(my_actions))
print(rest_statements(my_actions))
print(llist_ref(rest_statements(my_actions), 1))
