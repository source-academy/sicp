# None is the empty environment (not used here)
print(analyze_literal(parse('True'))(None))
