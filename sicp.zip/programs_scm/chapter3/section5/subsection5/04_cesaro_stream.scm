(define random-numbers
  (cons-stream random-init
               (stream-map rand-update random-numbers)))
(define (gcd a b)
  (if (= b 0)
      a
      (gcd b (remainder a b))))
(define cesaro-stream
  (map-successive-pairs (lambda (r1 r2) (= (gcd r1 r2) 1))
                        random-numbers))

(define (map-successive-pairs f s)
  (cons-stream
   (f (stream-car s) (stream-car (stream-cdr s)))
      (map-successive-pairs f (stream-cdr (stream-cdr s)))))

; expected: true
