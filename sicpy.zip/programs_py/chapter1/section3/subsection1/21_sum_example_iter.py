def cube(x):
    return x * x * x
def sum(term, a, next, b):
    def iterate(a, result):
        return result if a > b else iterate(next(a), result + term(a))
    return iterate(a, 0)

def inc(n):
    return n + 1
def sum_cubes(a, b):
    return sum(cube, a, inc, b)
print(sum_cubes(1, 10))

# expected: 3025
