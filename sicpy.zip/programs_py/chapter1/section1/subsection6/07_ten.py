print(10)

# expected: 10
