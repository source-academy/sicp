def scale_tree(tree, factor):
    return (None if is_none(tree)
            else tree * factor if not is_pair(tree)
            else pair(scale_tree(head(tree), factor),
                      scale_tree(tail(tree), factor)))
print(head(scale_tree(llist(1, llist(2, llist(3, 4), 5), llist(6, 7)),
           10)))
