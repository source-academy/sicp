# chapter=3 
print(get_coercion("python_number", "complex"))
