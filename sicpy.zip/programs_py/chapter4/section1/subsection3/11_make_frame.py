def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

def add_binding_to_frame(symbol, val, frame):
    set_head(frame, pair(symbol, head(frame)))
    set_tail(frame, pair(val, tail(frame)))

my_frame = make_frame(llist('x', 'y'), llist(1, 2))
print(frame_symbols(my_frame))

# expected: [ 'x', [ 'y', None ] ]
