def abs(x):
    return x if x >= 0 else - x
def square(x): return x * x
def is_good_enough(guess, x):
    return abs(square(guess) - x) < 0.001

print(is_good_enough(1.41, 2))
