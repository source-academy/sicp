# chapter=3 variant=non-det 
def a_pythagorean_triple_between(low, high):
    i = an_integer_between(low, high)
    hsq = high * high
    j = an_integer_between(i, high)
    ksq = i * i + j * j
    require(hsq >= ksq)
    k = math_sqrt(ksq)
    require(is_integer(k))
    return llist(i, j, k)

def is_integer(x):
    return x == math_floor(x)
a_pythagorean_triple_between(5, 15)
