def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def is_literal(component):
    return is_tagged_list(component, "literal")
def literal_value(component):
    return head(tail(component))

my_program = parse("true; 1;")
my_true_statement = ref(ref(my_program, 1), 0)
is_literal(my_true_statement)

# expected: true
