def square(x): return x * x
def is_even(n):
    return n % 2 == 0
def fast_expt(b, n):
    return (1 if n == 0
            else square(fast_expt(b, n // 2)) if is_even(n)
            else b * fast_expt(b, n - 1))
def pair(a, b):
    return fast_expt(2, a) * fast_expt(3, b)
def head(p):
    return (head(p // 2) + 1 if p % 2 == 0
            else 0)
def tail(p):
    return (tail(p // 3) + 1 if p % 3 == 0
            else 0)

print(tail(pair(3, 4)))

# expected: 4
