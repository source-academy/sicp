(define (adjoin-set x set)
  (if (element-of-set? x set)
    set
    (cons x set)))
(define (element-of-set? x set)
  (cond ((null? set) false)
        ((equal? x (car set)) true)
        (else (element-of-set? x (cdr set)))))

(element-of-set? 15 (adjoin-set 10 (adjoin-set 15 (adjoin-set 20 nil))))

; expected: true
