; chapter=3 variant=non-det 
(list (amb 1 2 3) (amb 'a 'b))
