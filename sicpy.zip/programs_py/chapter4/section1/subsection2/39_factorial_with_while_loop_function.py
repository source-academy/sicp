def factorial(n):
    product = 1
    counter = 1
    def pred():
        return counter <= n
    def body():
        nonlocal product, counter
        product = counter * product
        counter = counter + 1
    while_loop(pred, body)
    return product
