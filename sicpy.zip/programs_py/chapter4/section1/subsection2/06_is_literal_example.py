def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
my_program = parse('True\n1')
my_true_statement = llist_ref(llist_ref(my_program, 1), 0)
print(is_literal(my_true_statement))
