zero = lambda f: lambda x: x

def add_1(n):
    return lambda f: lambda x: f(n(f)(x))
