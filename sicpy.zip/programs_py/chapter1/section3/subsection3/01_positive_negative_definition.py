def positive(x):
    return x > 0
def negative(x):
    return x < 0
