def cube(x):
    return x * x * x
def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def inc(k):
    return k + 1

def simpsons_rule_integral(f, a, b, n):
    def helper(h):
        def y(k):
            return f((k * h) + a)
        def term(k):
            return (y(k) if k == 0 or k == n
                    else 2 * y(k) if k % 2 == 0
                    else 4 * y(k))
        return sum(term, 0, inc, n) * (h / 3)
    return helper((b - a) / n)
print(simpsons_rule_integral(cube, 0, 1, 100))
