def is_even(n):
    return n % 2 == 0
def square(x): return x * x
def expmod(base, exp, m):
    return (1 if exp == 0
            else square(expmod(base, exp // 2, m)) % m if is_even(exp)
            else (base * expmod(base, exp - 1, m)) % m)
def expmod(base, exp, m):
    if exp == 0:
        return 1
    else:
        if is_even(exp):
            half_exp = expmod(base, exp // 2, m)
            return (half_exp * half_exp) % m
        else:
            return (base * expmod(base, exp - 1, m)) % m

print(expmod(4, 3, 5))

# expected: 4
