# chapter=2 variant=lazy 
# Source Academy opens this program
# in lazy mode. Choose "Source §2" to
# to compare with strict mode
def unless(condition, usual_value, exceptional_value):
    return exceptional_value if condition else usual_value
xs = None
unless(is_none(xs), head(xs), print("error: xs should not be null"))
