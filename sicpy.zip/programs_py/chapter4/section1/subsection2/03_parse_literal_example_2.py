parse("'hello world';")
