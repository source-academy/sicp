print(head(tail(head(tail(head(tail(tail(deriv(llist("**", "x", 4), "x")))))))))
