const gcd_controller =
