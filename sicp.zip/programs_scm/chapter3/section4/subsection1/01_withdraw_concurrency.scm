(define (withdraw amount)
   (if (>= balance amount)
     (begin (set! balance (- balance amount))
            balance)
     "Insufficient funds"))

(withdraw 25) ;; output: 75

; expected: 75
