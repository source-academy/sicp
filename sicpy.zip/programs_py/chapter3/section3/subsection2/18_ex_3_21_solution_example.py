q1 = make_queue()
print_queue(q1)  # prints: None
insert_queue(q1, "a")
print_queue(q1)  # prints: ["a", None]
insert_queue(q1, "b")
print_queue(q1)  # prints: ["a", ["b", None]]
delete_queue(q1)
print(print_queue(q1))  # prints: ["b", None]
