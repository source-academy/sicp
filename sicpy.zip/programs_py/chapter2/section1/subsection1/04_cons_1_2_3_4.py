x = pair(1, 2)

y = pair(3, 4)

z = pair(x, y)

print(head(head(z)))
