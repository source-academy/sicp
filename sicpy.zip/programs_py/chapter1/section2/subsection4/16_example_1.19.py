def is_even(n):
    return n % 2 == 0
def double(x):
    return x + x

def half(x):
    return x // 2

def fast_times_iter(total, a, b):
    return (total + a if b == 1
            else 0 if a == 0 or b == 0
            else fast_times_iter(total, double(a), half(b)) if is_even(b)
            else fast_times_iter(total + a, a, b - 1))

def times(a, b):
    return fast_times_iter(0, a, b)
print(times(3, 4))

# expected: 12
