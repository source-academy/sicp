def fold_left(op, initial, sequence):
    def iter(result, rest):
        return (result if is_none(rest)
                else iter(op(result, head(rest)),
                          tail(rest)))
    return iter(initial, sequence)
print(fold_left(llist, None, llist(1, 2, 3)))
# result: [[[None, [1, None]], [2, None]], [3, None]]

# expected: [ [ [ None, [ 1, None ] ], [ 2, None ] ], [ 3, None ] ]
