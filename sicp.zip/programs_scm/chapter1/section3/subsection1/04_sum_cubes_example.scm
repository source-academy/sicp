(sum-cubes 3 7)
