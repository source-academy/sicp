(define (inc n) (+ n 1))
(define (square x) (* x x))




; expected: 49
