def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def is_safe(k, positions):
    first_row = head(head(positions))
    first_col = tail(head(positions))
    def check(pos, so_far):
        row = head(pos)
        col = tail(pos)
        return (so_far
                and first_row - first_col != row - col
                and first_row + first_col != row + col
                and first_row != row)
    return accumulate(check, True, tail(positions))
