def is_variable(x): return is_string(x)

print(is_variable("xyz"))

# expected: True
