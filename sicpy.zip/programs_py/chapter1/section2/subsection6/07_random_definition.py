def random(n):
    return math_floor(random_random() * n)
