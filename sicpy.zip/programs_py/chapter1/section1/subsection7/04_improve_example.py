print(improve(3, 25))
