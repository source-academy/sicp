(define balance 100)

(define (withdraw amount)
   (if (>= balance amount)
     (begin (set! balance (- balance amount))
            balance)
     "Insufficient funds"))
(withdraw 25)
(withdraw 25)

; expected: 50
