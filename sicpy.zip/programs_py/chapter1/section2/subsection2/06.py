# iterative function
def f_iterative(n):
    return n if n < 3 else f_iterative_impl(2, 1, 0, n - 2)

def f_iterative_impl(a, b, c, count):
    return a if count == 0 else f_iterative_impl(a + 2 * b + 3 * c, a, b, count - 1)

print(f_iterative(5))

# expected: 25
