# chapter=4 
z = make_complex_from_real_imag(3, 4)

print(magnitude(z))

z = make_complex_from_real_imag(3, 4)

print(magnitude(z))
