def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
my_function_definition = parse("function f(x) { return x; }")
my_return = ref(my_function_definition, 3)
ref(my_return, 1)
