def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
dx = 0.00001
def deriv(g):
    return lambda x: (g(x + dx) - g(x)) / dx
def newton_transform(g):
    return lambda x: x - g(x) / deriv(g)(x)
def newtons_method(g, guess):
    return fixed_point(newton_transform(g), guess)
def square(x): return x * x
def sqrt(x):
    return newtons_method(lambda y: square(y) - x, 1)

print(sqrt(6))
