import { beside } from 'rune';

(define right-split (split beside below))
(define up-split (split below beside))
