def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag

print(is_tagged_llist(llist('name', 'x'), 'name'))

# expected: True
