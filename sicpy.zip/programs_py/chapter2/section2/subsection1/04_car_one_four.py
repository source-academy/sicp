one_through_four = llist(1, 2, 3, 4)
print(head(one_through_four))

# expected: 1
