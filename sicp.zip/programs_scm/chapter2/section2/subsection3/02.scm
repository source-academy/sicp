(define (square x) (* x x))
(define (odd? n)
  (= (remainder n 2) 1))
(define (sum-odd-squares tree)
  (cond ((null? tree) 0)  
        ((not (pair? tree))
          (if (odd? tree) (square tree) 0))
        (else (+ (sum-odd-squares (car tree))
          (sum-odd-squares (cdr tree))))))

(sum-odd-squares (list (list 2 3) (list 4 5)))

; expected: 34
