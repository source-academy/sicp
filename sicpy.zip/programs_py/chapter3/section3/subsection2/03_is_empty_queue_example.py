q = pair(None, 2)
print(is_empty_queue(q))
