def make_agenda():
    return llist(0)

def current_time(agenda):
    return head(agenda)

def set_current_time(agenda, time):
    set_head(agenda, time)

def segments(agenda):
    return tail(agenda)

def set_segments(agenda, segs):
    set_tail(agenda, segs)

def first_segment(agenda):
    return head(segments(agenda))

def rest_segments(agenda):
    return tail(segments(agenda))
the_agenda = make_agenda()
inverter_delay = 2
and_gate_delay = 3
or_gate_delay = 5
def get_signal(wire):
    return wire("get_signal")

def set_signal(wire, new_value):
    return wire("set_signal")(new_value)

def add_action(wire, action_function):
    return wire("add_action")(action_function)
def probe(name, wire):
    add_action(wire,
               lambda: name + " " +
                       str(current_time(the_agenda)) +
                       ", new value = " +
                       str(get_signal(wire)))
