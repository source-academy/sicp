print(tan_cf(math_pi, 14))
# math_tan(math_pi)
