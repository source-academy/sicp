print(abs(-5))
