def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def square(x): return x * x
def fib(n):
    return (0 if n == 0
            else 1 if n == 1
            else fib(n - 1) + fib(n - 2))
def enumerate_interval(low, high):
    return (None if low > high
            else pair(low,
                      enumerate_interval(low + 1, high)))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def list_fib_squares(n):
    return reduce(pair,
                  None,
                  map(square,
                      map(fib,
                          enumerate_interval(0, n))))

print(length(list_fib_squares(10)))

# expected: 11
