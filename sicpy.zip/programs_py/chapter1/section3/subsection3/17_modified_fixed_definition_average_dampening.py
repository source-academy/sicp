def abs(x):
    return x if x >= 0 else - x
def fixed_point_with_average_dampening(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        print(guess)
        next = (guess + f(guess)) / 2
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)

print(fixed_point_with_average_dampening(lambda x: math_log(1000) / math_log(x), 2.0))
