(define pi 3.14159)
(define radius 10)
(* pi (* radius radius))

; expected: 314.159
