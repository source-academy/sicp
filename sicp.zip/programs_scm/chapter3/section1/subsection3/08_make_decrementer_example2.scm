(define (make-decrementer balance)
            (lambda (amount)
            (- balance amount)))
(define D (make-decrementer 25))
(D 20)
(D 10)

; expected: 15
