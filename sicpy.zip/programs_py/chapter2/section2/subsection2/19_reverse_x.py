x = llist(llist(1, 2), llist(3, 4))
def reverse(items):
    def reverse_iter(items, result):
        return (result if is_none(items)
                else reverse_iter(tail(items),
                                  pair(head(items), result)))
    return reverse_iter(items, None)
print_llist(reverse(x))
