(variable? 'xyz)
