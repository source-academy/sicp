(define (map proc items)
  (if (null? items)
      nil
      (cons (proc (car items))
            (map proc (cdr items)))))
(map (lambda (x) (* x x))
     (list 1 2 3 4))

; expected: [ 4, [ 9, [ 16, null ] ] ]
