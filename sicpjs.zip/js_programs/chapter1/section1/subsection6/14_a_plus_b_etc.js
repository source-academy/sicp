const a = 3;
const b = a + 1;
a + b + a * b;

// expected: 19
