print(eval('5 * 5'))
