x = llist(llist(1, 2), llist(3, 4))
# fringe to be written by student
print_llist(fringe(x))
