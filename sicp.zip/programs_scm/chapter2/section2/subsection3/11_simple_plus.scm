;; in Scheme, the operator symbol + is procedure name
