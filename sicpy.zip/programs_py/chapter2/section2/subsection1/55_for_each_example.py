# for_each to be given by student
def for_each(fun, items):
    if is_none(items):
        return None
    else:
        fun(head(items))
        for_each(fun, tail(items))
print(for_each(lambda x: x,
         llist(57, 321, 88)))
