def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
my_program = parse("true; 1;")
my_true_statement = ref(ref(my_program, 1), 0)
is_literal(my_true_statement)
