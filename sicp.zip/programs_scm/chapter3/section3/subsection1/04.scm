
(define (cons x y)
  (let ((new (get-new-pair)))
    (set-car! new x)
    (set-cdr! new y)
    new))



; expected: [ [ 1, 2 ], 4 ]
