def make_queue():
    return pair(None, None)
q1 = make_queue()
