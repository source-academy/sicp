print(tail(head(llist(llist("x1", "x2"), llist("y1", "y2")))))
# ["x2", None]

# expected: [ 'x2', None ]
