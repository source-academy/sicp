(define x '((a b) c d))
(define y '(e f))
(define z (cons y (cdr x)))
