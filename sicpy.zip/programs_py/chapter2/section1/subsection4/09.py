def make_interval(x, y):
    return pair(x, y)
def lower_bound(i):
    return head(i)
def upper_bound(i):
    return tail(i)
# printing the interval in one line requires some string
# manipulation: str turns a number into a string
# and the operator + can be applied to strings for
# string concatenation
def print_interval(i):
    return ("[ "  + str(lower_bound(i)) +
            " , " + str(upper_bound(i)) + " ]")
def sub_interval(x, y):
    return make_interval(lower_bound(x) - upper_bound(y),
                         upper_bound(x) - lower_bound(y))

print(print_interval(sub_interval(make_interval(0, 1),
                            make_interval(0.6, 1.5))))

# expected: '[ -1.5 , 0.4 ]'
