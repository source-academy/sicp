function average(x, y) {
    return (x + y) / 2;
}

average(3, 6);
