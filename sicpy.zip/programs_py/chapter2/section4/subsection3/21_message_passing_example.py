my_complex_number = make_from_real_imag(1.0, 4.5)

result = add_complex(my_complex_number,
                     my_complex_number)

print(imag_part(result))
