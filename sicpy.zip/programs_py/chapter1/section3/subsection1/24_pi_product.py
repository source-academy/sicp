# pi product
def pi(n):
    def is_odd(i):
        return i % 2 == 1
    def term(i):
        return (i + 1) / (i + 2) if is_odd(i) else (i + 2) / (i + 1)
    def next(i):
        return i + 1
    return 4 * (product_i(term, 1.0, next, n))
