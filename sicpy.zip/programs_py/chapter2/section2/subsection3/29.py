def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def map(f, sequence):
    return reduce(lambda x, y: pair(f(x), y),
                  None,
                  sequence)
def append(seq1, seq2):
    return reduce(pair, seq2, seq1)
def length(sequence):
    return reduce(lambda x, y: y + 1,
                  0,
                  sequence)

print(tail(map(math_sqrt, llist(1, 2, 3, 4))))

# expected: [ 1.4142135623730951, [ 1.7320508075688772, [ 2, None ] ] ]
