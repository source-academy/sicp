def abs(x):
    return x if x >= 0 else - x
def abs(x):
    return x if x > 0 else 0 if x == 0 else - x

print(abs(-5))
