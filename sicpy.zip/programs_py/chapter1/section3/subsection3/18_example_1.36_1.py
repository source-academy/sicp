def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        print(guess)
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
print(fixed_point(lambda x: math_log(1000) / math_log(x), 2.0))
