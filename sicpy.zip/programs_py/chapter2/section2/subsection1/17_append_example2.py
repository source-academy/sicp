def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
squares = llist(1, 4, 9, 16, 25)
odds = llist(1, 3, 5, 7)
print(length(append(odds, squares)))

# expected: 9
