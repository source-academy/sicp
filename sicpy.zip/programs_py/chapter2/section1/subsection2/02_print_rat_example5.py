one_half = make_rat(1, 2)

print(one_half)
