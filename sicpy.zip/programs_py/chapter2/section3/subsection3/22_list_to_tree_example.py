print(head(tail(linked_list_to_tree(llist(10, 20, 30)))))
