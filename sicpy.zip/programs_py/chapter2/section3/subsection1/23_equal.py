# function equal to be written by student
def equal(xs, ys):
    return ((is_pair(ys) and
             equal(head(xs), head(ys)) and
             equal(tail(xs), tail(ys)))
            if is_pair(xs)
            else is_none(ys)
            if is_none(xs)
            else (is_number(ys) and xs == ys)
            if is_number(xs)
            else (is_string(ys) and xs == ys)
            if is_string(xs)
            else is_none(ys)
            if is_none(xs)
            else
            # we know now that xs is a function
            (is_function(ys) and xs == ys))

print(   llist("this", "is", "a", "linked", "list")
      == llist("this", "is", "a", "linked", "list"))

# expected: True
