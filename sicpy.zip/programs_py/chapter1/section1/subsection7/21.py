def abs(x):
    return x if x >= 0 else - x
def cube(x):
    return x * x * x
def is_good_enough(guess, x):
    return abs(cube(guess) - x) < 0.001
def div3(x, y):
     return (x + y) / 3
def improve(guess, x):
    return div3(x / (guess * guess), 2 * guess)
def cube_root(guess, x):
    return (guess 
            if is_good_enough(guess, x)
            else cube_root(improve(guess, x), x))

print(cube_root(3, 27))
