(define (average x y)
  (/ (+ x y) 2))

(average 3 6)
