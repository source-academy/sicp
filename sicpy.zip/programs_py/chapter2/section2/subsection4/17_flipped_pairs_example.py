print(show(flipped_pairs(heart)))
