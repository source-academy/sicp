(good-enough? 1.41 2)
