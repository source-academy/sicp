def make_exponentiation(base, exp):
    return llist("**", base, exp)
def base(operands):
    return head(operands)
def exponent(operands):
    return head(tail(operands))
