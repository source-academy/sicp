def make_decrementer(balance):
    return lambda amount: balance - amount
D1 = make_decrementer(25)

D2 = make_decrementer(25)
