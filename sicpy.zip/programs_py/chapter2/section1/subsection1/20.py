def abs(x):
    return x if x >= 0 else - x
def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)
def sign(x):
    return -1 if x < 0 else (1 if x > 0 else 0)
def make_rat(n, d):
    g = gcd(n, d)
    return pair(sign(n) * sign(d) * abs(n // g),
                abs(d // g))

print(make_rat(3, -4))

# expected: [ -3, 4 ]
