(define (square y) (* y y))

(square 14)
