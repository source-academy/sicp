;; last-pair to be given by student
(last-pair (list 23 72 149 34))
