def greater_or_equal(x, y):
    return x > y or x == y

print(greater_or_equal(7, 4))
