x = llist("a", "b")
z1 = pair(x, x)
