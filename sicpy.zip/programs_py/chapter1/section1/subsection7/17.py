def conditional(predicate, then_clause, else_clause):
    return then_clause if predicate else else_clause
print(conditional(1 == 1, 0, 5))
