def square(x): return x * x
def is_even(n):
    return n % 2 == 0
def expmod(base, exp, m):
    return (1 if exp == 0
            else square(expmod(base, exp // 2, m)) % m if is_even(exp)
            else (base * expmod(base, exp - 1, m)) % m)
def random(n):
    return math_floor(random_random() * n)
def fermat_test(n):
    def try_it(a):
        return expmod(a, n, n) == a
    return try_it(1 + math_floor(random_random() * (n - 1)))
def fast_is_prime(n, times):
    return (True if times == 0
            else fast_is_prime(n, times - 1) if fermat_test(n)
            else False)
print(fast_is_prime(97, 3))

# expected: true
