(define (make-agenda) (list 0))
                
(define (current-time agenda) (car agenda))
                
(define (set-current-time! agenda time)
  (set-car! agenda time))
                
(define (segments agenda) (cdr agenda))
                
(define (set-segments! agenda segments)
  (set-cdr! agenda segments))
                
(define (first-segment agenda) (car (segments agenda)))
                
(define (rest-segments agenda) (cdr (segments agenda)))
(define (empty-agenda? agenda)
  (null? (segments agenda)))
(define (make-time-segment time queue)
  (cons time queue))
                
(define (segment-time s) (car s))
                
(define (segment-queue s) (cdr s))
(define (front-ptr queue) (car queue))

(define (rear-ptr queue) (cdr queue))

(define (set-front-ptr! queue item) (set-car! queue item))

(define (set-rear-ptr! queue item) (set-cdr! queue item))
(define (empty-queue? queue) (null? (front-ptr queue)))
(define (front-queue queue)
  (if (empty-queue? queue)
      (error "FRONT called with an empty queue" queue)
      (car (front-ptr queue))))
(define (first-agenda-item agenda)
  (if (empty-agenda? agenda)
      (error "Agenda is empty -- FIRST-AGENDA-ITEM")
      (let ((first-seg (first-segment agenda)))
        (set-current-time! agenda (segment-time first-seg))
        (front-queue (segment-queue first-seg)))))
