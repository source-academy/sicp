def cube(x):
    return x * x * x
def sum_cubes(a, b):
    return 0 if a > b else cube(a) + sum_cubes(a + 1, b)

print(sum_cubes(3, 7))

# expected: 775
