job($x, llist("computer", "wizard"))
