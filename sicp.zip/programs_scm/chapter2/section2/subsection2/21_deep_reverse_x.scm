(define x (list (list 1 2) (list 3 4)))
;; deep_reverse to be written by student
(deep-reverse x)
