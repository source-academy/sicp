# chapter=3 variant=concurrent 
def test_and_set(cell):
    if head(cell):
        return True
    else:
        set_head(cell, True)
        return False
