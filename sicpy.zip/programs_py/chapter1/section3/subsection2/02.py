lambda x: 1 / (x * (x + 2))
