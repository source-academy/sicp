head(make_leaf_set( list( list("A", 4),
                          list("B", 2),
                          list("C", 1),
                          list("D", 1) ) ) );
