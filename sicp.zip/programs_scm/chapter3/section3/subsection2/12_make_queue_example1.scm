(define (make-queue) (cons '() '()))
(define q1 (make-queue))
