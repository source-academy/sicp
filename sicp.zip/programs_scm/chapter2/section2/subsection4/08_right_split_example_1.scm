import { corner, beside } from 'rune';

(define (right-split painter n)
  (if (= n 0)
    painter
    (let ((smaller (right-split painter (- n 1))))
      (beside painter (below smaller smaller)))))
(right-split wave 4)
      (right-split rogers 4)
      (corner-split wave 4)
      (corner-split rogers 4)
