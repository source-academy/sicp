# cont_frac to be written by student; see exercise 1.37
# recursive process
def cont_frac(n, d, k):
    def fraction(i):
        return 0 if i > k else n(i) / (d(i) + fraction(i + 1))
    return fraction(1)

print(cont_frac(lambda i: 1, lambda i: 1, 20))

# expected: 0.6180339850173578
