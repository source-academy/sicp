seg = make_segment(make_point(0, 0),
                   make_point(1, 1))
print(midpoint_segment(seg))
