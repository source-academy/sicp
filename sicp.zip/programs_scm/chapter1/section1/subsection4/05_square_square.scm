(define (square x) (* x x))
(square (square 3))

; expected: 81
