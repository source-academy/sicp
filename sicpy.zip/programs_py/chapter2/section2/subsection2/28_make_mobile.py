def make_mobile(left, right):
    return llist(left, right)
