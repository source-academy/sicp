dx = 0.00001
def deriv(g):
    return lambda x: (g(x + dx) - g(x)) / dx

def cube(x):
    return x * x * x

print(deriv(cube)(5))
