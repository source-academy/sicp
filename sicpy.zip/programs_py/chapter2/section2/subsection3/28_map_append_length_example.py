def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
print(tail(map(math_sqrt, llist(1, 2, 3, 4))))
