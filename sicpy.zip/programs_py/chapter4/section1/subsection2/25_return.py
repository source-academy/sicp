def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_return_statement(component):
    return is_tagged_llist(component, 'return_statement')
def return_expression(component):
    return head(tail(component))
def make_return_statement(expression):
    return llist('return_statement', expression)

my_function_definition = parse('def f(x):\n    return x')
my_return = llist_ref(my_function_definition, 3)
print(llist_ref(my_return, 1))

# expected: [ 'name', [ 'x', None ] ]
