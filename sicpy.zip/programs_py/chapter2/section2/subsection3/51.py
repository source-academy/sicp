def plus(x, y):
    return x + y
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
# same as accumulate
fold_right = accumulate
print(fold_right(plus, 0, llist(1, 2, 3)))

# expected: 6
