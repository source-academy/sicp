print(llist(llist("george")))
# [["george", None], None]

# expected: [ [ 'george', None ], None ]
