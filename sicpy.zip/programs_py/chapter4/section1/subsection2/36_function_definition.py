def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_function_definition(component):
    return is_tagged_list(component, "function_definition")
def function_definition_name(component):
    return ref(component, 1)
def function_definition_parameters(component):
    return ref(component, 2)
def function_definition_body(component):
    return ref(component, 3)
def function_decl_to_constant_decl(component):
    return make_constant_declaration( function_definition_name(component), make_lambda_expression( function_definition_parameters(component), function_definition_body(component)))
