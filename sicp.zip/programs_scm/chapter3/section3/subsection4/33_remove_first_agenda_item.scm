(define (make-agenda) (list 0))
                
(define (current-time agenda) (car agenda))
                
(define (set-current-time! agenda time)
  (set-car! agenda time))
                
(define (segments agenda) (cdr agenda))
                
(define (set-segments! agenda segments)
  (set-cdr! agenda segments))
                
(define (first-segment agenda) (car (segments agenda)))
                
(define (rest-segments agenda) (cdr (segments agenda)))
(define (front-ptr queue) (car queue))

(define (rear-ptr queue) (cdr queue))

(define (set-front-ptr! queue item) (set-car! queue item))

(define (set-rear-ptr! queue item) (set-cdr! queue item))
(define (empty-queue? queue) (null? (front-ptr queue)))
(define (delete-queue! queue)
  (cond ((empty-queue? queue)
         (error "DELETE! called with an empty queue" queue))
        (else
         (set-front-ptr! queue (cdr (front-ptr queue)))
         queue)))
(define (make-time-segment time queue)
  (cons time queue))
                
(define (segment-time s) (car s))
                
(define (segment-queue s) (cdr s))
(define (remove-first-agenda-item! agenda)
  (let ((q (segment-queue (first-segment agenda))))
    (delete-queue! q)
    (if (empty-queue? q)
        (set-segments! agenda (rest-segments agenda)))))
