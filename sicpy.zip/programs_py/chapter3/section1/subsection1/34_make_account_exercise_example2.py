# make_account function to be written by students
acc = make_account(100, "secret password")
print(acc("secret password", "withdraw")(40))
print(acc("some other password", "deposit")(40))
