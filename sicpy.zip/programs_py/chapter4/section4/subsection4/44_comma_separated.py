def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def comma_separated(strings):
    return accumulate(lambda s, acc: (s + ("" if acc == "" else ", " + acc)), "", strings)
