def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
odds = llist(1, 3, 5, 7)

print(length(odds))
