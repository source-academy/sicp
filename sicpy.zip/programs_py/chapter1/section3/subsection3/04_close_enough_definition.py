def abs(x):
    return x if x >= 0 else - x
def close_enough(x, y):
    return abs(x - y) < 0.001

print(close_enough(7.7654, 7.7666))

# expected: False
