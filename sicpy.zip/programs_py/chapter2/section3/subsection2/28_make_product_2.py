def number_equal(exp, num):
    return is_number(exp) and exp == num
def make_product(m1, m2):
    return (0
            if number_equal(m1, 0) or number_equal(m2, 0)
            else m2
            if number_equal(m1, 1)
            else m1
            if number_equal(m2, 1)
            else m1 * m2
            if is_number(m1) and is_number(m2)
            else llist("*", m1, m2))

print(make_product(2, 3))

# expected: 6
