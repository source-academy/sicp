my_pair_lazy = """
