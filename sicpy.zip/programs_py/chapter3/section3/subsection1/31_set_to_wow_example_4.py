def set_to_wow(x):
    set_head(head(x), "wow")
    return x
z2 = pair(llist("a", "b"), llist("a", "b"))
print(set_to_wow(z2))

# expected: [ [ 'wow', [ 'b', None ] ], [ 'a', [ 'b', None ] ] ]
