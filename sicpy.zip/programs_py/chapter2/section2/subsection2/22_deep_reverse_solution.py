def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
x = llist(llist(1, 2), llist(3, 4))
# deep_reverse to be written by student
def deep_reverse(items):
    return (None if is_none(items)
            else append(deep_reverse(tail(items)),
                        pair(deep_reverse(head(items)),
                             None))
            if is_pair(items)
            else items)

print(head(deep_reverse(x)))

# expected: [ 4, [ 3, None ] ]
