def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
print(member("red", llist(llist("red", "shoes"), llist("blue", "socks"))))
# None

# expected: None
