(define square
  (lambda (x) (* x x)))

(square 14)

; expected: 196
