def f(g):
    return g(2)
def square(x): return x * x
print(f(square))
