// return 3; return 4; return 7;
display(count_pairs(three_list));
display(count_pairs(four_list));
display(count_pairs(seven_list));

// never return at all
display(count_pairs(cycle));
