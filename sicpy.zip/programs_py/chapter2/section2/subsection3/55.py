def fold_left(op, initial, sequence):
    def iter(result, rest):
        return (result if is_none(rest)
                else iter(op(result, head(rest)),
                          tail(rest)))
    return iter(initial, sequence)
def reverse(items):
    def reverse_iter(items, result):
        return (result if is_none(items)
                else reverse_iter(tail(items),
                                  pair(head(items), result)))
    return reverse_iter(items, None)
def reverse(sequence):
    return fold_left(lambda x, y: pair(y, x), None, sequence)

print(head(reverse(llist(1, 4, 5, 9, 16, 25))))

# expected: 25
