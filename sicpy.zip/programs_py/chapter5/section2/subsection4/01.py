def make_stack():
    stack = None
    number_pushes = 0
    max_depth = 0
    current_depth = 0
    def push(x):
        nonlocal stack, number_pushes, current_depth, max_depth
        stack = pair(x, stack)
        number_pushes = number_pushes + 1
        current_depth = current_depth + 1
        max_depth = math_max(current_depth, max_depth)
        return "done"
    def pop():
        nonlocal stack, current_depth
        if is_null(stack):
            error("empty stack -- pop")
        else:
            top = head(stack)
            stack = tail(stack)
            current_depth = current_depth - 1
            return top
    def initialize():
        nonlocal stack, number_pushes, max_depth, current_depth
        stack = None
        number_pushes = 0
        max_depth = 0
        current_depth = 0
        return "done"
    def print_statistics():
        display("total pushes = " + stringify(number_pushes))
        display("maximum depth = " + stringify(max_depth))
    def dispatch(message):
        return (push if message == "push"
                else pop() if message == "pop"
                else initialize() if message == "initialize"
                else print_statistics() if message == "print_statistics"
                else error("unknown request -- stack", message))
    return dispatch
