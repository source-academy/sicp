def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_application(component):
    return is_tagged_list(component, "application")
def function_expression(component):
    return head(tail(component))
def arg_expressions(component):
    return head(tail(tail(component)))

my_application = parse("math_pow(3, 4);")
print(is_application(my_application))
print(function_expression(my_application))
my_expressions = arg_expressions(my_application)
print(no_arg_expressions(my_expressions))
print(first_arg_expression(my_expressions))
print(rest_arg_expressions(my_expressions))
