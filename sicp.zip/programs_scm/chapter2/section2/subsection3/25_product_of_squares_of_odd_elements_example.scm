(define (square x) (* x x))
(define (odd? n)
  (= (remainder n 2) 1))
;; in Scheme, the operator symbol * is procedure name
(define (product-of-squares-of-odd-elements sequence)
  (accumulate *
              1
              (map square
                (filter odd? sequence))))
(product-of-squares-of-odd-elements (list 1 2 3 4 5))
