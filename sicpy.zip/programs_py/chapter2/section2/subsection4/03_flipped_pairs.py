import { heart, stack, beside, flip_vert, show } from 'rune';

def flipped_pairs(painter):
    painter2 = beside(painter, flip_vert(painter))
    return stack(painter2, painter2)

heart4 = flipped_pairs(heart)
print(show(heart4))
