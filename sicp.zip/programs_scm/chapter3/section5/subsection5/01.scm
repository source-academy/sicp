(define rand
  (let ((x random-init))
    (lambda ()
      (set! x (rand-update x))
    x)))

; expected: 40083849805
