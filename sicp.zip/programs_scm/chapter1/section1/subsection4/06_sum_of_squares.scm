(define (square x) (* x x))
(define (sum-of-squares x y)
  (+ (square x) (square y)))

(sum-of-squares 3 4)

(sum-of-squares 3 4)

; expected: 25
