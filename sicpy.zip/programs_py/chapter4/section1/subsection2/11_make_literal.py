def make_literal(value):
    return llist("literal", value)
