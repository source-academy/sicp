a = 3
b = a + 1
print(a == b)

# expected: false
