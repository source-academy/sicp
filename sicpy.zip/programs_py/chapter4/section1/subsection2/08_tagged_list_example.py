print(is_tagged_llist(llist('name', 'x'), 'name'))
