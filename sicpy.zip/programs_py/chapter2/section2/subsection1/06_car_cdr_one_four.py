one_through_four = llist(1, 2, 3, 4)
print(head(tail(one_through_four)))

# expected: 2
