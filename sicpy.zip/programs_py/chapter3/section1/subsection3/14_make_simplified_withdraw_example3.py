def make_simplified_withdraw(balance):
    def withdraw(amount):
        nonlocal balance
        balance = balance - amount
        return balance
    return withdraw
W1 = make_simplified_withdraw(25)

W2 = make_simplified_withdraw(25)
