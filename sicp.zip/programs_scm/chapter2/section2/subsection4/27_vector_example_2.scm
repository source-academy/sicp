(origin-frame a-frame)

; expected: [ 1, 2 ]
