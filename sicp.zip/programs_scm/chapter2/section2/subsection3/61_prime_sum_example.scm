(prime-sum? (list 8 9))
