def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def count_leaves(t):
    return accumulate(lambda leaves, total: leaves + total,
                      0,
                      map(lambda sub_tree: (count_leaves(sub_tree)
                                            if is_pair(sub_tree)
                                            else 1),
                          t))

print(count_leaves(pair(llist(1, 2), llist(3, 4))))

# expected: 4
