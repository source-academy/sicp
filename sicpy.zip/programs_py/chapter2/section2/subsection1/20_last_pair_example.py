# last_pair to be given by student
print_llist(last_pair(llist(23, 72, 149, 34)))
