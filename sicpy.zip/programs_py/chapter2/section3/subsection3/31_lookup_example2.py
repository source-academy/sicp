def entry(tree): return head(tree)

def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def make_tree(entry, left, right):
    return llist(entry, left, right)
my_fav_planets = make_tree(
    make_record(4, "Mars"),
    make_tree(make_record(2, "Venus"),
              None,
              make_tree(make_record(3, "Earth"),
                        None, None)),
    make_tree(make_record(6, "Saturn"),
              make_tree(make_record(5, "Jupiter"),
                        None, None),
              None))

print(lookup(3, my_fav_planets))
