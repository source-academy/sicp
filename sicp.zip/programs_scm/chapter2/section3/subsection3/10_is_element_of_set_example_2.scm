(element-of-set 15 (list 10 15 20))
