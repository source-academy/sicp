def make_point(x, y):
    return pair(x, y)
def x_point(x):
    return head(x)
def y_point(x):
    return tail(x)

def make_rect(bottom_left, top_right):
    return pair(bottom_left, top_right)

def top_right(rect):
    return tail(rect)

def bottom_right(rect):
    return make_point(x_point(tail(rect)),
                      y_point(head(rect)))

def top_left(rect):
    return make_point(x_point(head(rect)),
                      y_point(tail(rect)))

def bottom_left(rect):
    return head(rect)

def abs(x):
    return - x if x < 0 else x

def width_rect(rect):
    return abs(x_point(bottom_left(rect)) -
               x_point(bottom_right(rect)))

def height_rect(rect):
    return abs(y_point(bottom_left(rect)) -
               y_point(top_left(rect)))

def area_rect(rect):
    return width_rect(rect) * height_rect(rect)

def perimeter_rect(rect):
    return 2 * (width_rect(rect) + height_rect(rect))

v = make_rect(make_point(0, 1), make_point(2, 3))

print(perimeter_rect(v))

# expected: 8
