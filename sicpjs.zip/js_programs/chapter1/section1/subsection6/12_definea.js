const a = 3;

// expected: undefined
