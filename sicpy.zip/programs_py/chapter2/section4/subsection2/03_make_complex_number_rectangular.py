def attach_tag(type_tag, contents):
    return pair(type_tag, contents)
def type_tag(datum):
    return (head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))
def square(x): return x * x
def real_part_rectangular(z): return head(z)

def imag_part_rectangular(z): return tail(z)

def magnitude_rectangular(z):
    return math_sqrt(square(real_part_rectangular(z)) +
                     square(imag_part_rectangular(z)))
def angle_rectangular(z):
    return math_atan2(imag_part_rectangular(z),
                      real_part_rectangular(z))
def make_from_real_imag_rectangular(x, y):
    return attach_tag("rectangular", pair(x, y))
def make_from_mag_ang_rectangular(r, a):
    return attach_tag("rectangular",
                      pair(r * math_cos(a), r * math_sin(a)))

bens_co_num = make_from_mag_ang_rectangular(3.0, 0.7)

print(imag_part_rectangular(contents(bens_co_num)))

# expected: 1.932653061713073
