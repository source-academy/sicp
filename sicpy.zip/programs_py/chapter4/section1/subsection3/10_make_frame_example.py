my_frame = make_frame(llist("x", "y"), llist(1, 2))
frame_symbols(my_frame)
