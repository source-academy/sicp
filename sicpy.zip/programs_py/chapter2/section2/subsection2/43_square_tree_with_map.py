def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def square(x): return x * x
# square_tree to be written by student
def square_tree(tree):
    return map(lambda sub_tree: (square(sub_tree)
                                 if not is_pair(sub_tree)
                                 else square_tree(sub_tree)),
               tree)

print(tail(tail(square_tree(llist(1,
                 llist(2, llist(3, 4), 5), 
                 llist(6, 7))))))

# expected: [ [ 36, [ 49, None ] ], None ]
