def expt(b, n):
    return 1 if n == 0 else b * expt(b, n - 1)
print(expt(3, 4))

# expected: 81
