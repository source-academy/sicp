a = 1
b = 2
print(llist("a", b))

# expected: [ 'a', [ 2, None ] ]
