a = 3

# expected: 
