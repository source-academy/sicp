(define (=number? exp num)
  (and (number? exp) (= exp num)))

(number_equal 3 3))

; expected: true
