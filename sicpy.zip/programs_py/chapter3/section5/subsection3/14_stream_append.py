def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
def stream_append(s1, s2):
    return (s2 if is_none(s1)
            else pair(head(s1),
                      lambda: stream_append(stream_tail(s1), s2)))

ones = pair(1, lambda: ones)
twos = pair(2, lambda: twos)
appended = stream_append(ones, twos)
print(stream_ref(appended, 100))

# expected: 1
