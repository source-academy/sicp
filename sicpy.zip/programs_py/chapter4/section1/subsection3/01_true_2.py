def is_truthy(x):
    return not is_falsy(x)

def is_falsy(x):
    return x is None or x is False or x == 0 or x == ''
