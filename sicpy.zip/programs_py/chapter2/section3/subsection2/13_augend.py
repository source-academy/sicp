def make_sum(a1, a2): return llist("+", a1, a2)

def make_product(m1, m2): return llist("*", m1, m2)
def augend(s): return head(tail(tail(s)))

print(augend(make_sum("x", 3)))

# expected: 3
