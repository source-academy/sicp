a = 3
b = a + 1
print(2 + (b if b < a else a))

# expected: 5
