def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def enumerate_tree(tree):
    return (None if is_none(tree)
            else llist(tree) if not is_pair(tree)
            else append(enumerate_tree(head(tree)),
                        enumerate_tree(tail(tree))))
print(tail(tail(enumerate_tree(llist(1, llist(2, llist(3, 4)), 5)))))
