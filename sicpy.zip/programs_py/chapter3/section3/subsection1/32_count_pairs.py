def count_pairs(x):
    return (0 if not is_pair(x)
            else count_pairs(head(x)) +
                 count_pairs(tail(x)) +
                 1)
