# try these separately
print(f(0) + f(1))  # returns 0
print(f(1) + f(0))  # returns 1
