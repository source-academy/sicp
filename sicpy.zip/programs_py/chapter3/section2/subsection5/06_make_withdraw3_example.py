W1 = make_withdraw(100)
print(W1(80))
