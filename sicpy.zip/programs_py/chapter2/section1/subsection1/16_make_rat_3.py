def numer(x):
    return head(x)
def denom(x):
    return tail(x)
def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)
def make_rat(n, d):
    g = gcd(n, d)
    return pair(n // g, d // g)

print(make_rat(4, 6))

# expected: [ 2, 3 ]
