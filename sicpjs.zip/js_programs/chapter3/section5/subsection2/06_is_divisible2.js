function is_divisible(x, y) { return x % y === 0; }

is_divisible(42, 7);
