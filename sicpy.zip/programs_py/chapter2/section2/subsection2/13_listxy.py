x = llist(1, 2, 3)

y = llist(4, 5, 6)
print(head(tail(llist(x, y))))
