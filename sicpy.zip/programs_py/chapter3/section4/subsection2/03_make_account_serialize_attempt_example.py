my_account = make_account(100)

def t1():
    print(my_account("balance"), "T1 balance")
    my_account("withdraw")(50)
    print(my_account("balance"), "T1 balance")
    my_account("deposit")(100)

def t2():
    print(my_account("balance"), "T2 balance")
    my_account("withdraw")(50)
    print(my_account("balance"), "T2 balance")
    my_account("deposit")(100)

print(concurrent_execute(t1, t2))
