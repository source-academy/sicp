is_truthy(False)
# should return false because only true is truthy
