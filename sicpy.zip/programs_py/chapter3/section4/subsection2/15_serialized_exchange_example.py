a1 = make_account_and_serializer(100)
a2 = make_account_and_serializer(200)
a3 = make_account_and_serializer(300)

def peter():
    print(a1("balance"), "Peter balance a1 before")
    print(a2("balance"), "Peter balance a2 before")
    serialized_exchange(a1, a2)
    print(a1("balance"), "Peter balance a1 after")
    print(a2("balance"), "Peter balance a2 after")

def paul():
    print(a1("balance"), "Paul balance a1 before")
    print(a3("balance"), "Paul balance a3 before")
    serialized_exchange(a1, a3)
    print(a1("balance"), "Paul balance a1 after")
    print(a3("balance"), "Paul balance a3 after")

print(concurrent_execute(peter, paul))
