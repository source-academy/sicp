def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_function(parameters, body, env):
    return llist("compound_function", parameters, body, env)
def is_compound_function(f):
    return is_tagged_list(f, "compound_function")
def function_parameters(f):
    return ref(f, 1)

def function_body(f):
    return ref(f, 2)

def function_environment(f):
    return ref(f, 3)

my_function = make_function(llist("x", "y"), llist("return_statement", parse("x + y;")), the_empty_environment)
is_compound_function(my_function)
function_body(my_function)
function_environment(my_function)
function_parameters(my_function)

# expected: [ 'x', [ 'y', null ] ]
