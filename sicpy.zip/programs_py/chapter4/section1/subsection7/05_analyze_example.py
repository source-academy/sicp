print(analyze(parse('''
x = 1
x + 1
'''))(the_global_environment))
