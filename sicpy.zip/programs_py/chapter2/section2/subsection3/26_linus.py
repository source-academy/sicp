my_records = llist(llist("Linus", "programmer", 30000),
                         llist("Richard", "programmer", 25000),
                         llist("Bill", "manager", 2500000))
def is_programmer(record):
    return head(tail(record)) == "programmer"
def salary(record):
    return head(tail(tail(record)))
print(salary_of_highest_paid_programmer(my_records))
