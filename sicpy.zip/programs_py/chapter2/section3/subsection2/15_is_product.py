def make_sum(a1, a2): return llist("+", a1, a2)

def make_product(m1, m2): return llist("*", m1, m2)
def is_product(x):
    return is_pair(x) and head(x) == "*"

print(is_product(make_product("x", 3)))

# expected: True
