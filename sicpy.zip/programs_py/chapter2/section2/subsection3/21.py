def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def is_even(n):
    return n % 2 == 0
def fib(n):
    return (0 if n == 0
            else 1 if n == 1
            else fib(n - 1) + fib(n - 2))
def enumerate_interval(low, high):
    return (None if low > high
            else pair(low,
                      enumerate_interval(low + 1, high)))
def even_fibs(n):
    return accumulate(pair,
                      None,
                      filter(is_even,
                             map(fib,
                                 enumerate_interval(0, n))))

print(tail(even_fibs(9)))

# expected: [ 2, [ 8, [ 34, None ] ] ]
