# chapter=4 
install_rational_package()

r1 = make_rational(1, 3)
r2 = make_rational(2, 5)

print(add(r1, r2))
