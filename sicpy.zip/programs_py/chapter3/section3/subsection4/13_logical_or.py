# contributed by GitHub user clean99

def logical_or(s1, s2):
    return (0 if s1 == 0 and s2 == 0
            else (1 if s2 == 0 or s2 == 1
                  else error("invalid signal", s2))
                if s1 == 0 or s1 == 1
            else error("invalid signal", s1))
