print(make_pair_sum(llist(8, 9)))
