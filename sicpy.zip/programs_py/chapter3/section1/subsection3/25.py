v = -0.5

def f(x):
    global v
    v = x + v
    return v

# try these separately
print(f(0) + f(1))  # returns 0
print(f(1) + f(0))  # returns 1
