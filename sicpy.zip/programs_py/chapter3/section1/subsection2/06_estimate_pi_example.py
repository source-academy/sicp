print(estimate_pi(10000))
