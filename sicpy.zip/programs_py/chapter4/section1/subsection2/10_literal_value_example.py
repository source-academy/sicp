print(literal_value(parse('None')))
