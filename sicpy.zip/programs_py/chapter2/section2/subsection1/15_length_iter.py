def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def length(items):
    def length_iter(a, count):
        return (count if is_none(a)
                else length_iter(tail(a), count + 1))
    return length_iter(items, 0)

odds = llist(1, 3, 5, 7)

print(length(odds))

# expected: 4
