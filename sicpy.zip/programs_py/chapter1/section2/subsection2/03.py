def fib(n):
    return (0 if n == 0
            else 1 if n == 1
            else fib(n - 1) + fib(n - 2))
def fib(n):
    return fib_iter(1, 0, n)

def fib_iter(a, b, count):
    return b if count == 0 else fib_iter(a + b, a, count - 1)

print(fib(6))

# expected: 8
