# iterative process
def cont_frac(n, d, k):
    def fraction(i, current):
        return current if i == 0 else fraction(i - 1, n(i) / (d(i) + current))
    return fraction(k, 0)
print(2 + cont_frac(lambda i: 1,
                    lambda i: 2 * (i + 1) / 3 if (i + 1) % 3 < 1 else 1,
                    20))

# expected: 2.718281828459045
