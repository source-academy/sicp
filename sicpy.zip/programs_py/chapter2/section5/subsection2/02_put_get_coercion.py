coercion_list = None

def clear_coercion_list():
    global coercion_list
    coercion_list = None

def put_coercion(type1, type2, item):
    global coercion_list
    if is_none(get_coercion(type1, type2)):
        coercion_list = pair(llist(type1, type2, item),
                             coercion_list)
    else:
        return coercion_list

def get_coercion(type1, type2):
    def get_type1(list_item):
        return head(list_item)
    def get_type2(list_item):
        return head(tail(list_item))
    def get_item(list_item):
        return head(tail(tail(list_item)))
    def get_coercion_iter(items):
        if is_none(items):
            return None
        else:
            top = head(items)
            return (get_item(top)
                    if type1 == get_type1(top) and
                       type2 == get_type2(top)
                    else get_coercion_iter(tail(items)))
    return get_coercion_iter(coercion_list)
