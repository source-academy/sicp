def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
# encode_symbol function to be written by students
def encode(message, tree):
    return (None
            if is_none(message)
            else append(encode_symbol(head(message), tree),
                        encode(tail(message), tree)))
