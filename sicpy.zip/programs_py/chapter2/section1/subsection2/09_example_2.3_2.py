v = make_rect(make_point(1, 2), 2, 2)

print(perimeter_rect(v))
