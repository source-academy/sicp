def cube(x):
    return x * x * x
def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def inc(n):
    return n + 1
def sum_cubes(a, b):
    return sum(cube, a, inc, b)

print(sum_cubes(1, 10))

# expected: 3025
