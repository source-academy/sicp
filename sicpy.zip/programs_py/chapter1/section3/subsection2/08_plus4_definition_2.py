def plus4(x):
    return x + 4

print(plus4(3))
