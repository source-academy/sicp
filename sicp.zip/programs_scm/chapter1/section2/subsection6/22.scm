(define (even? n)
  (= (remainder n 2) 0))
(define (expmod base exp m)
  (cond ((= exp 0) 1)
        ((even? exp)
         (remainder 
           (* (expmod base (/ exp 2) m)
              (expmod base (/ exp 2) m))
           m))
        (else
         (remainder 
           (* base (expmod base (- exp 1) m))
           m))))

(expmod 4 3 5)
