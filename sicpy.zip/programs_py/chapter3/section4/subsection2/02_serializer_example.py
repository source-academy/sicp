# chapter=3 variant=concurrent 
def make_mutex():
    cell = llist(False)
    def the_mutex(m):
        return ((the_mutex("acquire")  # retry
                     if test_and_set(cell)
                 else True)
                   if m == "acquire"
                else clear(cell) if m == "release"
                else error("unknown request -- mutex", m))
    return the_mutex

def clear(cell):
    set_head(cell, False)
def make_serializer():
    mutex = make_mutex()
    def serializer(f):
        def serialized_f():
            mutex("acquire")
            val = f()
            mutex("release")
            return val
        return serialized_f
    return serializer
x = 10

s = make_serializer()

def t1():
    global x
    x = x * x

def t2():
    global x
    x = x + 1

concurrent_execute(s(t1), s(t2))
