import { heart, show } from 'rune';

print(show(corner_split(heart, 4)))

print(show(corner_split(heart, 4)))
