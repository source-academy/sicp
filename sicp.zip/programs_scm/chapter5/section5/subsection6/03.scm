(find-variable 'c '((y z) (a b c d e) (x y)))
