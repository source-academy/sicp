def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_llist(component, 'name')
def symbol_of_name(component):
    return head(tail(component))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def is_global_statement(component):
    return is_tagged_llist(component, 'global_statement')
def is_nonlocal_statement(component):
    return is_tagged_llist(component, 'nonlocal_statement')
def declaration_symbols(component):
    return map(symbol_of_name, head(tail(component)))

my_declaration = parse('global x, y')
print(declaration_symbols(my_declaration))

# expected: ['x', ['y', None]]
