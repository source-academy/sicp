(define (set-to-wow! x)
  (set-car! (car x) 'wow)
  x)
(define z2 (cons (list 'a 'b) (list 'a 'b)))
(set-to-wow! z2)

; expected: [ [ 'wow', [ 'b', null ] ], [ 'a', [ 'b', null ] ] ]
