print(sum_odd_squares(llist(llist(2, 3), llist(4, 5))))
