one_through_four = llist(1, 2, 3, 4)
print(tail(tail(pair(10, one_through_four))))

# expected: [ 2, [ 3, [ 4, None ] ] ]
