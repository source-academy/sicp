p1 = make_polynomial("x",
                     llist(llist(2, make_python_number(4)),
                           llist(1, make_python_number(3)),
                           llist(0, make_python_number(7))))
p2 = make_polynomial("x",
                     llist(llist(2, make_python_number(5)),
                           llist(1, make_python_number(2)),
                           llist(0, make_python_number(10))))

print(head(tail(tail(tail(mul(p1, p2))))))
