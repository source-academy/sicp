my_integral = """
