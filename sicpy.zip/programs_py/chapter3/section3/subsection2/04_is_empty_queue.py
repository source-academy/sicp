def front_ptr(queue):
    return head(queue)

def rear_ptr(queue):
    return tail(queue)

def set_front_ptr(queue, item):
    set_head(queue, item)

def set_rear_ptr(queue, item):
    set_tail(queue, item)
def is_empty_queue(queue):
    return is_none(front_ptr(queue))

q = pair(None, 2)
print(is_empty_queue(q))

# expected: True
