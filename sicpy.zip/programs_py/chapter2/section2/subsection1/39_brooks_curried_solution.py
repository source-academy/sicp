def plus_curried(x):
    return lambda y: x + y
def brooks(f, items):
    return (f if is_none(items)
            else brooks(f(head(items)), tail(items)))
# brooks_curried to be written by the student
def brooks_curried(items):
    return brooks(head(items), tail(items))

print(brooks_curried(llist(plus_curried, 3, 4)))

# expected: 7
