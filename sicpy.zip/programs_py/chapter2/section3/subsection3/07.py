def is_element_of_set(x, set):
    return (False
            if is_none(set)
            else True
            if x == head(set)
            else is_element_of_set(x, tail(set)))
def adjoin_set(x, set):
    return (set
            if is_element_of_set(x, set)
            else pair(x, set))
def union_set(set1, set2):
    return (set2
            if is_none(set1)
            else adjoin_set(head(set1),
                            union_set(tail(set1), set2)))

print(tail(tail(tail(union_set(
   adjoin_set(10, adjoin_set(20, adjoin_set(30, None))),
   adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))))))

# expected: [ 20, None ]
