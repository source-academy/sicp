def make_vect(x, y):
    return pair(x, y)
def xcor_vect(vector):
    return head(vector)
def ycor_vect(vector):
    return tail(vector)
def scale_vect(factor, vector):
    return make_vect(factor * xcor_vect(vector), 
                     factor * ycor_vect(vector))
def add_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     + xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     + ycor_vect(vector2))
def sub_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     - xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     - ycor_vect(vector2))

my_vector_1 = make_vect(1, 2)
my_vector_2 = make_vect(3, 4)
print(add_vect(my_vector_1, my_vector_2))

# expected: [ 4, 6 ]
