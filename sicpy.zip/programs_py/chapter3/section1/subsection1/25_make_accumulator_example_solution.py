a = make_accumulator(5)
a(10)
print(a(10))
