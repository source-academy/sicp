(define (pi-sum a b)
  (if (> a b)
      0
      (+ (/ 1.0 (* a (+ a 2))) 
         (pi-sum (+ a 4) b))))

(* 8 (pi-sum 1 1000))

; expected: 3.139592655589783
