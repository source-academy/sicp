(define x (cons 1 2))

(define y (cons 3 4))

(define z (cons x y))
(car (cdr z))

; expected: 3
