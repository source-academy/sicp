def entry(tree): return head(tree)

def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def make_tree(entry, left, right):
    return llist(entry, left, right)

print(entry(
  left_branch(
    right_branch(
      make_tree(10,
                None,
                make_tree(30,
                          make_tree(20, None, None),
                          None))))))

# expected: 20
