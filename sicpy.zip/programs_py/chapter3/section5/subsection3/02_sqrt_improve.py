def average(x, y):
    return (x + y) / 2
def sqrt_improve(guess, x):
    return average(guess, x / guess)

print(sqrt_improve(1.2, 2))

# expected: 1.4333333333333333
