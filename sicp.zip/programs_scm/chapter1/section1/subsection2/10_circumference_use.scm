(define pi 3.14159)
(define radius 10)
(define circumference (* 2 pi radius))
circumference

; expected: 62.8318
