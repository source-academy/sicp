function make_decrementer(balance) {
    return amount => balance - amount;
}
