# chapter=2 variant=lazy 
# Source Academy opens this program
# in lazy mode. Choose the Python §2 language
# to compare with strict mode
def unless(condition, usual_value, exceptional_value):
    return exceptional_value if condition else usual_value
# Source Academy opens this program
# in lazy mode. Choose the Python §2 language
# to compare with strict mode
def factorial(n):
    return unless(n == 1, n * factorial(n - 1), 1)

factorial(5)
