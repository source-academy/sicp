(define (accumulate op initial sequence)
  (if (null? sequence)
    initial
    (op (car sequence)
        (accumulate op initial (cdr sequence)))))
;; in Scheme, the operator symbol * is procedure name
(accumulate * 1 (list 1 2 3 4 5))

; expected: 120
