def call_the_cops(reason):
    return 'calling the cops because ' + reason

def make_account(balance, p):

    invalid_attempts = 0  # initializes to 0

    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return 'Insufficient funds'

    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance

    def calling_the_cops(_):
        return call_the_cops('you have exceeded ' +
                             'the max no of failed attempts')

    def dispatch(q, m):
        nonlocal invalid_attempts
        if invalid_attempts > 7:
            return calling_the_cops
        elif p == q:
            invalid_attempts = 0  # reset after a correct password
            return (withdraw if m == 'withdraw'
                    else deposit if m == 'deposit'
                    else 'unknown request -- make_account')
        else:
            invalid_attempts = invalid_attempts + 1
            if invalid_attempts > 7:
                return calling_the_cops
            else:
                return lambda x: 'Incorrect password'

    return dispatch

a = make_account(100, 'rosebud')
a('rosebad', 'withdraw')(50)
a('rosebad', 'withdraw')(50)
a('rosebad', 'withdraw')(50)
a('rosebad', 'withdraw')(50)
a('rosebad', 'withdraw')(50)
a('rosebad', 'withdraw')(50)
a('rosebad', 'withdraw')(50)
print(a('rosebad', 'withdraw')(50))

# expected: 'calling the cops because you have exceeded the max no of failed attempts'
