def plus_curried(x):
    return lambda y: x + y
# brooks_curried to be written by the student
brooks_curried(llist(brooks_curried,
                     llist(brooks_curried,
                           llist(plus_curried, 3, 4))))
