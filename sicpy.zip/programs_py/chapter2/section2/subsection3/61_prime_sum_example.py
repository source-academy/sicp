print(is_prime_sum(llist(8, 9)))
