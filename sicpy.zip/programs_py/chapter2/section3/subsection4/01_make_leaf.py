def make_leaf(symbol, weight):
    return llist("leaf", symbol, weight)
def is_leaf(object):
    return head(object) == "leaf"
def symbol_leaf(x): return head(tail(x))

def weight_leaf(x): return head(tail(tail(x)))

my_leaf = make_leaf("A", 8)

print(weight_leaf(my_leaf))

# expected: 8
