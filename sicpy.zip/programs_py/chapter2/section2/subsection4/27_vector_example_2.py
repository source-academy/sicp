def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def make_vect(x, y):
    return pair(x, y)
def xcor_vect(vector):
    return head(vector)
def ycor_vect(vector):
    return tail(vector)
def scale_vect(factor, vector):
    return make_vect(factor * xcor_vect(vector), 
                     factor * ycor_vect(vector))
def add_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     + xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     + ycor_vect(vector2))
def sub_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     - xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     - ycor_vect(vector2))
def make_frame(origin, edge1, edge2):
    return llist(origin, edge1, edge2)
def origin_frame(frame):
    return llist_ref(frame, 0)
def edge1_frame(frame):
    return llist_ref(frame, 1)
def edge2_frame(frame):
    return llist_ref(frame, 2)
a_frame = make_frame(make_vect(1, 2), 
                           make_vect(3, 4),
                           make_vect(5, 5))
print(origin_frame(a_frame))

# expected: [ 1, 2 ]
