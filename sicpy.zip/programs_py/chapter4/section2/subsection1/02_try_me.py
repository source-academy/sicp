# chapter=2 variant=lazy 
# Source Academy opens this program
# in lazy mode. Choose "Source §2" to
# to compare with strict mode
def try_me(a, b):
    return 1 if a == 0 else b

try_me(0, head(None))

# expected: 1
