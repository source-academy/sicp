# make_monitored function to be written by students
s = make_monitored(math_sqrt)
