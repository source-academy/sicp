print(sqrt(0.0001))
print(sqrt(4000000000000))
