# chapter=3 variant=non-det 
def an_element_of(items):
    require( not is_none(items))
    return amb(head(items), an_element_of(tail(items)))

xs = llist("apple", "banana", "cranberry")
an_element_of(xs)
# Press "Run" for the first solution. Type
# retry
# in the REPL on the right, for more solutions

# expected: 'apple'
