a = 3
b = a + 1

# expected: 
