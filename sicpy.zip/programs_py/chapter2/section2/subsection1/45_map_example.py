def abs(x):
    return x if x >= 0 else - x
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
print(tail(map(abs, llist(-10, 2.5, -11.6, 17))))

# expected: [ 2.5, [ 11.6, [ 17, None ] ] ]
