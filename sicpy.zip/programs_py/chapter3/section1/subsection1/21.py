def make_account(balance):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return 'Insufficient funds'
    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance
    def dispatch(m):
        return (withdraw if m == 'withdraw'
                else deposit if m == 'deposit'
                else error('unknown request -- make_account', m))
    return dispatch
acc2 = make_account(100)
