(define A (make-accumulator 5))
