gcd_elaborated_controller =
