print(head(make_leaf_set( llist(llist("A", 4),
                          llist("B", 2),
                          llist("C", 1),
                          llist("D", 1)))))
