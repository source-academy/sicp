(define (flatmap proc seq)
  (accumulate append nil (map proc seq)))



; expected: 8
