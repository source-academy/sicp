def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
# same as reduce
fold_right = reduce
def divide(x, y):
    return x / y
print(fold_right(divide, 1, llist(1, 2, 3)))
# result: 1.5

# expected: 1.5
