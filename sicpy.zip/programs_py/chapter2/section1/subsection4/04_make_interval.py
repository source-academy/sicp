def make_interval(x, y):
    return pair(x, y)
def lower_bound(i):
    return head(i)
def upper_bound(i):
    return tail(i)
