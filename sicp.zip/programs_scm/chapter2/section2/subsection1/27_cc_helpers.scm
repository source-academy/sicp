;; first-denomination, except-first-denomination
;; and no-more? to be given by student
