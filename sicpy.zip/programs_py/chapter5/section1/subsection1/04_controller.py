def controller(sequence):
    return llist("controller", sequence)
def controller_sequence(controller):
    return head(tail(controller))
