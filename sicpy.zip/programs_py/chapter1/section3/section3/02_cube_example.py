def cube(x):
    return x * x * x
print(cube(3))

# expected: 27
