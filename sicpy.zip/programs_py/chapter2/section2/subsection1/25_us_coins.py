us_coins = llist(50, 25, 10, 5, 1)
uk_coins = llist(100, 50, 20, 10, 5, 2, 1)
