z2 = pair(llist("a", "b"), llist("a", "b"))
print(z2)

# expected: [ [ 'a', [ 'b', None ] ], [ 'a', [ 'b', None ] ] ]
