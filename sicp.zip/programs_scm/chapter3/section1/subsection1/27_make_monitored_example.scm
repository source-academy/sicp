(define s (make-monitored sqrt))
