(define s (make-monitored sqrt))
(s 100)
