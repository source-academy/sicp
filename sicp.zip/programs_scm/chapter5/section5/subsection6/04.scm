(find-variable 'x '((y z) (a b c d e) (x y)))
