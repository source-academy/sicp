def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
def numbers_starting_from(t, dt):
    return pair(t,
                lambda: numbers_starting_from(t + dt, dt))

dt = 0.01
linear = numbers_starting_from(0, dt)
linear_integral = integral(linear, 0, dt)
# computing integral from 0 to 3 of f(x) = x
# (the integral is g(x) = 0.5 x^2, and therefore
# the result is near 0.5 * 3^2 = 4.5)
print(stream_ref(linear_integral, round(3 / dt)))
