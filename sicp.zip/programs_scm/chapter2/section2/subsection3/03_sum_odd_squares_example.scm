(sum-odd-squares (list (list 2 3) (list 4 5)))
