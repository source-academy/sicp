def assoc(key, records):
    return (None if is_none(records)
            else head(records) if key == head(head(records))
            else assoc(key, tail(records)))
def insert(key_1, key_2, value, table):
    subtable = assoc(key_1, tail(table))
    if is_none(subtable):
        set_tail(table,
                 pair(llist(key_1, pair(key_2, value)), tail(table)))
    else:
        record = assoc(key_2, tail(subtable))
        if is_none(record):
            set_tail(subtable,
                     pair(pair(key_2, value), tail(subtable)))
        else:
            set_tail(record, value)
    return "ok"
