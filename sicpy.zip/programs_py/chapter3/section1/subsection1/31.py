def make_monitored(f):
    counter = 0  # initialized to 0
    def mf(cmd):
        nonlocal counter
        if cmd == "how many calls":
            return counter
        elif cmd == "reset count":
            counter = 0
            return counter
        else:
            counter = counter + 1
            return f(cmd)
    return mf

s = make_monitored(math_sqrt)
s(100)
print(s("how many calls"))
s(5)
print(s("how many calls"))

# expected: 2
