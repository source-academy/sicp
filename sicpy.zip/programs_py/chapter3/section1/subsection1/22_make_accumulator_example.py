# make_accumulator to be written by students
a = make_accumulator(5)
