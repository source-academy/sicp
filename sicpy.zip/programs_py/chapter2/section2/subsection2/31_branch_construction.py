def make_mobile(left, right):
    return llist(left, right)
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def make_branch(length, structure):
    return llist(length, structure)
def left_branch(m):
    return head(m)
def right_branch(m):
    return head(tail(m))
def branch_length(b):
    return head(b)
def branch_structure(b):
    return head(tail(b))
