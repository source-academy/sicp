def abs(x):
    return x if x >= 0 else - x
def square(x): return x * x
def average(x, y):
    return (x + y) / 2
def sqrt(x):
    def is_good_enough(guess, x):
        return abs(square(guess) - x) < 0.001
    def improve(guess, x):
        return average(guess, x / guess)
    def sqrt_iter(guess, x):
        return (guess
                if is_good_enough(guess, x)
                else sqrt_iter(improve(guess, x), x))
    return sqrt_iter(1, x)

print(sqrt(5))

# expected: 2.2360688956433634
