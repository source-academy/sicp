def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_llist(component, 'name')
def make_application(function_expression, argument_expressions):
    return llist('application', function_expression, argument_expressions)

my_name_statement = parse('x')
print(is_name(my_name_statement))
print(symbol_of_name(my_name_statement))
