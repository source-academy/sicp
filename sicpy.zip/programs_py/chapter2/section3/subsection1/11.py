llist("a", "b", "c")
