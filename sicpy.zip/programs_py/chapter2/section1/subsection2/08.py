def make_point(x, y):
    return pair(x, y)

def make_rect(bottom_left, width, height):
    return pair(bottom_left, pair(width, height))

def height_rect(rect):
    return tail(tail(rect))

def width_rect(rect):
    return head(tail(rect))

def area_rect(rect):
    return width_rect(rect) * height_rect(rect)

def perimeter_rect(rect):
    return 2 * (width_rect(rect) + height_rect(rect))

v = make_rect(make_point(1, 2), 2, 2)

print(perimeter_rect(v))
