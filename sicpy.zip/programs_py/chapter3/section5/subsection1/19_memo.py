def memo(fun):
    already_run = False
    result = None
    def memoized():
        nonlocal already_run, result
        if not already_run:
            result = fun()
            already_run = True
            return result
        else:
            return result
    return memoized

calls = 0
def square_4():
    global calls
    result = 4 * 4
    calls = calls + 1
    return result

memo_square_4 = memo(square_4)
memo_square_4()
memo_square_4()
print(calls)

# expected: 1
