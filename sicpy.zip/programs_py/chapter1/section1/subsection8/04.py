def square(y): return y * y

print(square(14))
