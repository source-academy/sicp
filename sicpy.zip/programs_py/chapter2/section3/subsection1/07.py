def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
print(member("apple", llist("x", "y", "apple", "pear")))

# expected: [ 'apple', [ 'pear', None ] ]
