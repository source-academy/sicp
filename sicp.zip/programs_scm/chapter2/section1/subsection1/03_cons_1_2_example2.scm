(define x (cons 1 2))
(cdr x)

; expected: 2
