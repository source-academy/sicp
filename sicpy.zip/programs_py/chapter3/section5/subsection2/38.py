def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
def integrate_series(s):
    def helper(ss, iter):
        return pair(head(ss) / iter, lambda: helper(stream_tail(ss), iter + 1))
    return helper(s, 1)

cos_series = pair(1, lambda: integrate_series(
        pair(0,
            lambda: stream_map(
                    lambda x: -x,
                    integrate_series(cos_series)))))

sin_series = pair(0, lambda: integrate_series(
        pair(1,
            lambda: integrate_series(
                stream_map(lambda x: -x, sin_series)
                ))
        ))
