import { square, beside } from 'rune';

(define (square-of-four tl tr bl br)
  (lambda (painter)
    (let ((top (beside (tl painter) (tr painter)))
          (bottom (beside (bl painter) (br painter))))
      (below bottom top))))
(define (identity x) x)
(define flipped-pairs
  (square-of-four identity flip-vert identity flip-vert))

((flipped-pairs rogers) full-frame)
