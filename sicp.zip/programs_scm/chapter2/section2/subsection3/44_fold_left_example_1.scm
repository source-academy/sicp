(define (fold-left op initial sequence)
  (define (iter result rest)
    (if (null? rest)
      result
      (iter (op result (car rest))
            (cdr rest))))
  (iter initial sequence))
;; in Scheme, the operator symbol * is procedure name
(fold-left / 1 (list 1 2 3))
