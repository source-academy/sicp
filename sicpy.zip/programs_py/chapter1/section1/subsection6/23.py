def plus(a, b): return a + b

def minus(a, b): return a - b

def a_plus_abs_b(a, b):
    return (plus if b >= 0 else minus)(a, b)

print(a_plus_abs_b(5, -4))
