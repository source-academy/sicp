def call_each(functions):
    if is_none(functions):
        return "done"
    else:
        head(functions)()
        return call_each(tail(functions))
def make_wire():
    signal_value = 0
    action_functions = None
    def set_my_signal(new_value):
        nonlocal signal_value
        if signal_value != new_value:
            signal_value = new_value
            return call_each(action_functions)
        else:
            return "done"
    def accept_action_function(fun):
        nonlocal action_functions
        action_functions = pair(fun, action_functions)
        fun()
    def dispatch(m):
        return (signal_value if m == "get_signal"
                else set_my_signal if m == "set_signal"
                else accept_action_function if m == "add_action"
                else error("unknown operation -- wire", m))
    return dispatch
def make_agenda():
    return llist(0)

def current_time(agenda):
    return head(agenda)

def set_current_time(agenda, time):
    set_head(agenda, time)

def segments(agenda):
    return tail(agenda)

def set_segments(agenda, segs):
    set_tail(agenda, segs)

def first_segment(agenda):
    return head(segments(agenda))

def rest_segments(agenda):
    return tail(segments(agenda))
the_agenda = make_agenda()
inverter_delay = 2
and_gate_delay = 3
or_gate_delay = 5
def get_signal(wire):
    return wire("get_signal")

def set_signal(wire, new_value):
    return wire("set_signal")(new_value)

def add_action(wire, action_function):
    return wire("add_action")(action_function)
def probe(name, wire):
    add_action(wire,
               lambda: name + " " +
                       str(current_time(the_agenda)) +
                       ", new value = " +
                       str(get_signal(wire)))
input_1 = make_wire()
input_2 = make_wire()
sum = make_wire()
carry = make_wire()

probe("sum", sum)
probe("carry", carry)
