(define (even? n)
  (= (remainder n 2) 0))



; expected: 12
