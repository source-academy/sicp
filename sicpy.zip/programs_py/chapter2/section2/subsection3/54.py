def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
# same as accumulate
fold_right = accumulate
def reverse(items):
    def reverse_iter(items, result):
        return (result if is_none(items)
                else reverse_iter(tail(items),
                                  pair(head(items), result)))
    return reverse_iter(items, None)
def reverse(sequence):
    return fold_right(lambda x, y: append(y, llist(x)),
                      None, sequence)

print(head(reverse(llist(1, 4, 5, 9, 16, 25))))

# expected: 25
