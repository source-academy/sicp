def print_point(p):
    print("(" + str(x_point(p)) + ", "
              + str(y_point(p)) + ")")
def x_point(x):
    return head(x)
def y_point(x):
    return tail(x)
def make_point(x, y):
    return pair(x, y)
def make_segment(start_point, end_point):
    return pair(start_point, end_point)
def start_segment(x):
    return head(x)
def end_segment(x):
    return tail(x)
def average(a, b):
    return (a + b) / 2
def midpoint_segment(x):
    a = start_segment(x)
    b = end_segment(x)
    return make_point(average(x_point(a),
                              x_point(b)),
                      average(y_point(a),
                              y_point(b)))

seg = make_segment(make_point(0, 0),
                   make_point(1, 1))
print(midpoint_segment(seg))

# expected: [ 0.5, 0.5 ]
