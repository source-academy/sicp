print(f(4, 7, 2))
