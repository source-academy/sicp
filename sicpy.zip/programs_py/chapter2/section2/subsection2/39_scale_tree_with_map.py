def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def scale_tree(tree, factor):
    return map(lambda sub_tree: (scale_tree(sub_tree, factor)
                                 if is_pair(sub_tree)
                                 else sub_tree * factor),
               tree)

print(head(scale_tree(llist(1, llist(2, llist(3, 4), 5), llist(6, 7)),
           10)))

# expected: 10
