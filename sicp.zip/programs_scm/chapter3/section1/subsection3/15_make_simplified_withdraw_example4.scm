(define (make-simplified-withdraw balance)
  (lambda (amount)
    (set! balance (- balance amount))
    balance))
(define W1 (make-simplified-withdraw 25))

(define W2 (make-simplified-withdraw 25))
(W1 20)

; expected: 5
