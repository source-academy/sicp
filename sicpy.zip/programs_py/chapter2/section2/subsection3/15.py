def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
print(tail(tail(reduce(pair, None, llist(1, 2, 3, 4, 5)))))

# expected: [ 3, [ 4, [ 5, None ] ] ]
