(define (make-time-segment time queue)
  (cons time queue))
                
(define (segment-time s) (car s))
                
(define (segment-queue s) (cdr s))
(define (make-queue) (cons '() '()))
(define (front-ptr queue) (car queue))

(define (rear-ptr queue) (cdr queue))

(define (set-front-ptr! queue item) (set-car! queue item))

(define (set-rear-ptr! queue item) (set-cdr! queue item))
(define (empty-queue? queue) (null? (front-ptr queue)))
(define (insert-queue! queue item)
  (let ((new-pair (cons item '())))
    (cond ((empty-queue? queue)
           (set-front-ptr! queue new-pair)
           (set-rear-ptr! queue new-pair)
           queue)
          (else
           (set-cdr! (rear-ptr queue) new-pair)
           (set-rear-ptr! queue new-pair)
           queue))))
(define (make-agenda) (list 0))
                
(define (current-time agenda) (car agenda))
                
(define (set-current-time! agenda time)
  (set-car! agenda time))
                
(define (segments agenda) (cdr agenda))
                
(define (set-segments! agenda segments)
  (set-cdr! agenda segments))
                
(define (first-segment agenda) (car (segments agenda)))
                
(define (rest-segments agenda) (cdr (segments agenda)))
(define (add-to-agenda! time action agenda)
  (define (belongs-before? segments)
    (or (null? segments)
        (< time (segment-time (car segments)))))
  (define (make-new-time-segment time action)
    (let ((q (make-queue)))
      (insert-queue! q action)
      (make-time-segment time q)))
  (define (add-to-segments! segments)
     (if (= (segment-time (car segments)) time)
         (insert-queue! (segment-queue (car segments))
                        action)
         (let ((rest (cdr segments)))
           (if (belongs-before? rest)
               (set-cdr!
                segments
                (cons (make-new-time-segment time action)
                      (cdr segments)))
               (add-to-segments! rest)))))
  (let ((segments (segments agenda)))
    (if (belongs-before? segments)
        (set-segments!
         agenda
         (cons (make-new-time-segment time action)
               segments))
        (add-to-segments! segments))))
(define the-agenda (make-agenda))
(define inverter-delay 2)
(define and-gate-delay 3)
(define or-gate-delay 5)
(define (after-delay delay action)
  (add-to-agenda! (+ delay (current-time the-agenda))
                  action
                  the-agenda))
