(define (square x) (* x x))
(define (smallest-divisor n)
  (find-divisor n 2))

(define (find-divisor n test-divisor)
  (cond ((> (square test-divisor) n) n)
        ((divides? test-divisor n) test-divisor)
        (else (find-divisor n (+ test-divisor 1)))))

(define (divides? a b)
  (= (remainder b a) 0))
(define (prime? n)
  (= n (smallest-divisor n)))
(define (enumerate-interval low high)
   (if (> low high)
      nil
      (cons low (enumerate-interval (+ low 1) high))))
(define (sum-primes a b)
  (accumulate +
              0
              (filter prime? (enumerate-interval a b))))

; expected: 3437
