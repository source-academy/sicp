# functions from SICP JS 4.1.2
def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_literal(component):
    return is_tagged_llist(component, 'literal')
def literal_value(component):
    return head(tail(component))
def make_literal(value):
    return llist('literal', value)
def is_name(component):
    return is_tagged_llist(component, 'name')
def make_name(symbol):
    return llist('name', symbol)
def symbol_of_name(component):
    return head(tail(component))
def is_assignment(component):
    return is_tagged_llist(component, 'assignment')
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def is_lambda_expression(component):
    return is_tagged_llist(component, 'lambda_expression')
def lambda_parameter_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def lambda_body(component):
    return head(tail(tail(component)))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_function_definition(component):
    return is_tagged_llist(component, 'function_definition')
def function_definition_name(component):
    return llist_ref(component, 1)
def function_definition_symbol(component):
    return symbol_of_name(function_definition_name(component))
def function_definition_parameters(component):
    return llist_ref(component, 2)
def function_definition_parameter_symbols(component):
    return map(symbol_of_name, function_definition_parameters(component))
def function_definition_body(component):
    return llist_ref(component, 3)
def is_return_statement(component):
    return is_tagged_llist(component, 'return_statement')
def return_expression(component):
    return head(tail(component))
def make_return_statement(expression):
    return llist('return_statement', expression)
def is_pass_statement(component):
    return is_tagged_llist(component, 'pass_statement')
def is_conditional(component):
    return (is_tagged_llist(component, 'conditional_expression') or
            is_tagged_llist(component, 'conditional_statement'))
def conditional_predicate(component):
    return llist_ref(component, 1)
def conditional_consequent(component):
    return llist_ref(component, 2)
def conditional_alternative(component):
    return llist_ref(component, 3)
def is_sequence(stmt):
    return is_tagged_llist(stmt, 'sequence')
def sequence_statements(stmt):
    return head(tail(stmt))
def first_statement(stmts):
    return head(stmts)
def rest_statements(stmts):
    return tail(stmts)
def is_empty_sequence(stmts):
    return is_none(stmts)
def is_last_statement(stmts):
    return is_none(tail(stmts))
def is_operator_combination(component):
    return is_unary_operator_combination(component) or is_binary_operator_combination(component)
def is_unary_operator_combination(component):
    return is_tagged_llist(component, 'unary_operator_combination')
def is_binary_operator_combination(component):
    return is_tagged_llist(component, 'binary_operator_combination')
def operator_symbol(component):
    return llist_ref(component, 1)
def first_operand(component):
    return llist_ref(component, 2)
def second_operand(component):
    return llist_ref(component, 3)
def make_application(function_expression, argument_expressions):
    return llist('application', function_expression, argument_expressions)
def operator_combination_to_application(component):
    operator = operator_symbol(component)
    if is_unary_operator_combination(component):
        return make_application(make_name(operator),
                                llist(first_operand(component)))
    else:
        return make_application(make_name(operator),
                                llist(first_operand(component),
                                      second_operand(component)))
def is_application(component):
    return is_tagged_llist(component, 'application')
def function_expression(component):
    return head(tail(component))
def arg_expressions(component):
    return head(tail(tail(component)))

# functions from SICP Python 4.1.3
def is_truthy(x):
    if is_boolean(x):
        return x
    else:
        error('boolean expected, received', x)
def is_falsy(x):
    return not is_truthy(x)
def make_function(parameters, body, env):
    return llist('compound_function', parameters, body, env)
def is_compound_function(f):
    return is_tagged_llist(f, 'compound_function')
def function_parameters(f):
    return llist_ref(f, 1)

def function_body(f):
    return llist_ref(f, 2)

def function_environment(f):
    return llist_ref(f, 3)
def make_return_value(content):
    return llist('return_value', content)
def is_return_value(value):
    return is_tagged_llist(value, 'return_value')
def return_value_content(value):
    return head(tail(value))
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

def add_binding_to_frame(symbol, val, frame):
    set_head(frame, pair(symbol, head(frame)))
    set_tail(frame, pair(val, tail(frame)))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def extend_environment(symbols, vals, base_env):
    if length(symbols) == length(vals):
        return pair(make_frame(symbols, vals), base_env)
    elif length(symbols) < length(vals):
        error('too many arguments supplied', pair(symbols, vals))
    else:
        error('too few arguments supplied', pair(symbols, vals))
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
built_in_constants = llist(llist('math_pi', math_pi), llist('math_e', math_e))
built_in_constant_symbols = map(lambda c: head(c), built_in_constants)
built_in_constant_values = map(lambda c: head(tail(c)), built_in_constants)
def is_built_in_function(fun):
    return is_tagged_llist(fun, 'built_in')

def built_in_implementation(fun):
    return head(tail(fun))
def print_without_environments(*objects):
    def prepare(object):
        if is_compound_function(object):
            return '<compound-function>'
        elif is_built_in_function(object):
            return '<built-in-function>'
        elif is_pair(object):
            return pair(prepare(head(object)), prepare(tail(object)))
        else:
            return object
    return apply_in_underlying_python(print,
                                      map(prepare, llist(*objects)))
built_in_functions = llist(llist('head', head), llist('tail', tail), llist('pair', pair), llist('is_none', is_none), llist('llist', llist), llist('print', print_without_environments), llist('error', error), llist('abs', abs), llist('+', lambda x, y: x + y), llist('-', lambda x, y: x - y), llist('*', lambda x, y: x * y), llist('/', lambda x, y: x / y), llist('//', lambda x, y: x // y), llist('%', lambda x, y: x % y), llist('**', lambda x, y: x ** y), llist('==', lambda x, y: x == y), llist('!=', lambda x, y: x != y), llist('<', lambda x, y: x < y), llist('<=', lambda x, y: x <= y), llist('>', lambda x, y: x > y), llist('>=', lambda x, y: x >= y), llist('is', lambda x, y: x is y), llist('is not', lambda x, y: x is not y), llist('not', lambda x: not x), llist('-unary', lambda x: -x), llist('+unary', lambda x: +x))
built_in_function_symbols = map(head, built_in_functions)
built_in_function_objects = map(lambda fun: llist('built_in', head(tail(fun))), built_in_functions)
def setup_environment():
    built_in_environment = extend_environment(
        append(built_in_function_symbols, built_in_constant_symbols),
        append(built_in_function_objects, built_in_constant_values),
        the_empty_environment)
    return extend_environment(None, None, built_in_environment)
the_global_environment = setup_environment()
def lookup_symbol_value(symbol, env):
    def env_loop(env):
        def scan(symbols, vals):
            if is_none(symbols):
                return env_loop(enclosing_environment(env))
            elif symbol == head(symbols):
                if head(vals) == '*global*':
                    return lookup_symbol_value(symbol, the_global_environment)
                else:
                    return head(vals)
            else:
                return scan(tail(symbols), tail(vals))
        if env is the_empty_environment:
            error('unbound name', symbol)
        else:
            frame = first_frame(env)
            return scan(frame_symbols(frame), frame_values(frame))
    return env_loop(env)
def assign_symbol_value(symbol, val, env):
    def scan(symbols, vals):
        if is_none(symbols):
            if env is the_global_environment:
                add_binding_to_frame(symbol, val, first_frame(env))
            else:
                assign_symbol_value(symbol, val, enclosing_environment(env))
        elif symbol == head(symbols):
            if head(vals) == '*global*':
                assign_symbol_value(symbol, val, the_global_environment)
            else:
                set_head(vals, val)
        else:
            scan(tail(symbols), tail(vals))
    frame = first_frame(env)
    scan(frame_symbols(frame), frame_values(frame))

# functions from SICP Python 4.1.4
def apply_built_in_function(fun, arg_llist):
    return apply_in_underlying_python(built_in_implementation(fun), arg_llist)

def analyze_name(component):
    return lambda env: (lookup_symbol_value(symbol_of_name(component), env))

print(analyze_name(parse('myname'))(
          extend_environment(llist('myname'), llist(1), the_global_environment)))

# expected: 1
