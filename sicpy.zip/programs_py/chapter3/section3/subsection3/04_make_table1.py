def make_table():
    return llist("*table*")
