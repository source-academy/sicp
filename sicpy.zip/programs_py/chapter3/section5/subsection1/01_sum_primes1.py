def square(x): return x * x
def smallest_divisor(n):
    return find_divisor(n, 2)

def find_divisor(n, test_divisor):
    return (n if square(test_divisor) > n
            else test_divisor if divides(test_divisor, n)
            else find_divisor(n, test_divisor + 1))

def divides(a, b):
    return b % a == 0
def is_prime(n):
    return n == smallest_divisor(n)
def sum_primes(a, b):
    def iter(count, accum):
        return (accum if count > b
                else iter(count + 1, count + accum) if is_prime(count)
                else iter(count + 1, accum))
    return iter(a, 0)

print(sum_primes(7, 182))

# expected: 3437
