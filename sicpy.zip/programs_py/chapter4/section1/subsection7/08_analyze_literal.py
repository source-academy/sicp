# functions from SICP JS 4.1.2
def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_literal(component):
    return is_tagged_llist(component, 'literal')
def literal_value(component):
    return head(tail(component))
def make_literal(value):
    return llist('literal', value)
def is_name(component):
    return is_tagged_llist(component, 'name')
def make_name(symbol):
    return llist('name', symbol)
def symbol_of_name(component):
    return head(tail(component))
def is_assignment(component):
    return is_tagged_llist(component, 'assignment')
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def is_lambda_expression(component):
    return is_tagged_llist(component, 'lambda_expression')
def lambda_parameter_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def lambda_body(component):
    return head(tail(tail(component)))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_function_definition(component):
    return is_tagged_llist(component, 'function_definition')
def function_definition_name(component):
    return llist_ref(component, 1)
def function_definition_symbol(component):
    return symbol_of_name(function_definition_name(component))
def function_definition_parameters(component):
    return llist_ref(component, 2)
def function_definition_parameter_symbols(component):
    return map(symbol_of_name, function_definition_parameters(component))
def function_definition_body(component):
    return llist_ref(component, 3)
def is_return_statement(component):
    return is_tagged_llist(component, 'return_statement')
def return_expression(component):
    return head(tail(component))
def make_return_statement(expression):
    return llist('return_statement', expression)
def is_pass_statement(component):
    return is_tagged_llist(component, 'pass_statement')
def is_conditional(component):
    return (is_tagged_llist(component, 'conditional_expression') or
            is_tagged_llist(component, 'conditional_statement'))
def conditional_predicate(component):
    return llist_ref(component, 1)
def conditional_consequent(component):
    return llist_ref(component, 2)
def conditional_alternative(component):
    return llist_ref(component, 3)
def is_sequence(stmt):
    return is_tagged_llist(stmt, 'sequence')
def sequence_statements(stmt):
    return head(tail(stmt))
def first_statement(stmts):
    return head(stmts)
def rest_statements(stmts):
    return tail(stmts)
def is_empty_sequence(stmts):
    return is_none(stmts)
def is_last_statement(stmts):
    return is_none(tail(stmts))
def is_operator_combination(component):
    return is_unary_operator_combination(component) or is_binary_operator_combination(component)
def is_unary_operator_combination(component):
    return is_tagged_llist(component, 'unary_operator_combination')
def is_binary_operator_combination(component):
    return is_tagged_llist(component, 'binary_operator_combination')
def operator_symbol(component):
    return llist_ref(component, 1)
def first_operand(component):
    return llist_ref(component, 2)
def second_operand(component):
    return llist_ref(component, 3)
def make_application(function_expression, argument_expressions):
    return llist('application', function_expression, argument_expressions)
def operator_combination_to_application(component):
    operator = operator_symbol(component)
    if is_unary_operator_combination(component):
        return make_application(make_name(operator),
                                llist(first_operand(component)))
    else:
        return make_application(make_name(operator),
                                llist(first_operand(component),
                                      second_operand(component)))
def is_application(component):
    return is_tagged_llist(component, 'application')
def function_expression(component):
    return head(tail(component))
def arg_expressions(component):
    return head(tail(tail(component)))

def analyze_literal(component):
    return lambda env: (literal_value(component))

# None is the empty environment (not used here)
print(analyze_literal(parse('True'))(None))

# expected: True
