(define (square x) (* x x))
;; in Scheme, the operator symbol + is procedure name
(define (odd? n)
  (= (remainder n 2) 1))
(define (enumerate-tree tree)
   (cond ((null? tree) nil)
         ((not (pair? tree)) (list tree))
         (else (append (enumerate-tree (car tree))
                       (enumerate-tree (cdr tree))))))
(define (sum-odd-squares tree)
   (accumulate +
               0
               (map square
                 (filter odd?
                  (enumerate-tree tree)))))

(sum-odd-squares (list (list 2 3) (list 4 5)))

; expected: 34
