def make_pair_sum(pair):
    return llist(head(pair), head(tail(pair)),
                 head(pair) + head(tail(pair)))

print(make_pair_sum(llist(8, 9)))

# expected: [ 8, [ 9, [ 17, None ] ] ]
