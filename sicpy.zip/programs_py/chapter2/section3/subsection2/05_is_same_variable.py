def is_variable(x): return is_string(x)
def is_same_variable(v1, v2):
    return is_variable(v1) and is_variable(v2) and v1 == v2

print(is_same_variable("xyz", "xyz"))

# expected: True
