(define radius 10)
