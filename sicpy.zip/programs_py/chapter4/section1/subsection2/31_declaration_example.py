my_declaration = parse('global x, y')
print(declaration_symbols(my_declaration))
