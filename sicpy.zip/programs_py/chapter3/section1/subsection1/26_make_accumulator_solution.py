def make_accumulator(current):
    def add(arg):
        nonlocal current
        current = current + arg
        return current
    return add

a = make_accumulator(5)
a(10)
print(a(10))

# expected: 25
