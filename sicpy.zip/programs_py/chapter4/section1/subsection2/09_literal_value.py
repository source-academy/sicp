def literal_value(component):
    return head(tail(component))

print(literal_value(parse('None')))

# expected: None
