(append-to-form ?x ?y (a b c d))

; expected: 'append_to_form(list("a", "b", "c", "d"), null, list("a", "b", "c", "d"))'
