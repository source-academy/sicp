def random(n):
    return math_floor(random_random() * n)
def random_in_range(low, high):
    range = high - low
    return low + math_random() * range

print(random_in_range(80000, 81000))
