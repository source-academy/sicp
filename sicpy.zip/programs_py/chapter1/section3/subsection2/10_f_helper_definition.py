def square(x): return x * x
def f(x, y):
    def f_helper(a, b):
        return x * square(a) + y * b + a * b
    return f_helper(1 + x * y, 1 - y)

print(f(3, 4))

# expected: 456
