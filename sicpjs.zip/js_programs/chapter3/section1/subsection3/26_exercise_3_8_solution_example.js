// try these separately
display(f(0) + f(1)); // returns 0
display(f(1) + f(0)); // returns 1
