(scale-list (list 1 2 3 4 5) 10)
