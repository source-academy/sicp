def square(x): return x * x
def square_linked_list(items):
    return (None if is_none(items)
            else pair(square(head(items)),
                      square_linked_list(tail(items))))

print(tail(square_linked_list(llist(1, 2, 3, 4))))

# expected: [ 4, [ 9, [ 16, None ] ] ]
