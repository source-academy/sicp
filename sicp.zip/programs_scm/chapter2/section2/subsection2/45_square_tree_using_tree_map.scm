;; tree_map to be written by student
(define (square-tree tree) (tree-map square tree))
