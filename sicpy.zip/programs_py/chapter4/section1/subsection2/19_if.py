def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_conditional(component):
    return is_tagged_list(component, "conditional_expression") or is_tagged_list(component, "conditional_statement")
def conditional_predicate(component):
    return ref(component, 1)
def conditional_consequent(component):
    return ref(component, 2)
def conditional_alternative(component):
    return ref(component, 3)

my_cond_expr = parse("true ? 1 : 2;")
is_conditional(my_cond_expr)
conditional_predicate(my_cond_expr)
conditional_consequent(my_cond_expr)
conditional_alternative(my_cond_expr)

# expected: [ 'literal', [ 2, null ] ]
