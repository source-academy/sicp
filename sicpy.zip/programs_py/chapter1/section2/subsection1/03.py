def factorial(n):
    def iterate(product, counter):
        return (product
                if counter > n
                else iterate(counter * product, counter + 1))
    return iterate(1, 1)

print(factorial(5))

# expected: 120
