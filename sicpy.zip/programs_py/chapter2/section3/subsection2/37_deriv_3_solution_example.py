deriv(llist("*", "x", "y", llist("+", "x", 3)), "x")
