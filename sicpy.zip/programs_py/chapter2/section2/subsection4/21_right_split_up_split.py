import { beside } from 'rune';

# function split to be written by student
right_split = split(beside, below)
up_split = split(below, beside)
