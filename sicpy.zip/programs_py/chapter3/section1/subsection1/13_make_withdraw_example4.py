def make_withdraw(balance):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return "Insufficient funds"
    return withdraw
W1 = make_withdraw(100)
W2 = make_withdraw(100)
print(W1(50))
print(W2(70))
print(W2(40))
print(W1(40))

# expected: 10
