def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def make_leaf(symbol, weight):
    return llist("leaf", symbol, weight)
def is_leaf(object):
    return head(object) == "leaf"
def symbol_leaf(x): return head(tail(x))

def weight_leaf(x): return head(tail(tail(x)))
def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def symbols(tree):
    return (llist(symbol_leaf(tree))
            if is_leaf(tree)
            else head(tail(tail(tail(tree)))))
def weight(tree):
    return (weight_leaf(tree)
            if is_leaf(tree)
            else head(tail(tail(tail(tail(tree))))))
def make_code_tree(left, right):
    return llist("code_tree", left, right,
                 append(symbols(left), symbols(right)),
                 weight(left) + weight(right))

my_leaf_1 = make_leaf("A", 8)
my_leaf_2 = make_leaf("B", 3)

print(head(tail(make_code_tree(my_leaf_1, my_leaf_2))))

# expected: [ 'leaf', [ 'A', [ 8, None ] ] ]
