(define (fold-left op initial sequence)
  (define (iter result rest)
    (if (null? rest)
      result
      (iter (op result (car rest))
            (cdr rest))))
  (iter initial sequence))

(fold-left list nil (list 1 2 3))

; expected: [ [ [ null, [ 1, null ] ], [ 2, null ] ], [ 3, null ] ]
