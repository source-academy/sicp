def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_llist(component, 'name')
def symbol_of_name(component):
    return head(tail(component))
def is_assignment(component):
    return is_tagged_llist(component, 'assignment')
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))

my_assignment_statement = parse('x = 1')
print(assignment_symbol(my_assignment_statement))
print(assignment_value_expression(my_assignment_statement))

# expected: [ 'literal', [ 1, None ] ]
