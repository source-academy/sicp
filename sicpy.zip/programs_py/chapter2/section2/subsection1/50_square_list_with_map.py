def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def square(x): return x * x
def square_linked_list(items):
    return map(square, items)

print(tail(square_linked_list(llist(1, 2, 3, 4))))

# expected: [ 4, [ 9, [ 16, None ] ] ]
