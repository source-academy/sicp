def attach_tag(type_tag, contents):
    return pair(type_tag, contents)
def type_tag(datum):
    return (head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))
def square(x): return x * x
def real_part_polar(z):
    return magnitude_polar(z) * math_cos(angle_polar(z))
def imag_part_polar(z):
    return magnitude_polar(z) * math_sin(angle_polar(z))
def magnitude_polar(z): return head(z)

def angle_polar(z): return tail(z)

def make_from_real_imag_polar(x, y):
    return attach_tag("polar",
                      pair(math_sqrt(square(x) + square(y)),
                           math_atan2(y, x)))

def make_from_mag_ang_polar(r, a):
    return attach_tag("polar", pair(r, a))

alyssas_co_num = make_from_mag_ang_polar(3.0, 0.7)

print(imag_part_polar(contents(alyssas_co_num)))

# expected: 1.932653061713073
