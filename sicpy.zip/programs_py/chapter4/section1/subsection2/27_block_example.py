my_block = parse("{ 1; true; 45; }")
print(is_block(my_block))
print(block_body(my_block))
