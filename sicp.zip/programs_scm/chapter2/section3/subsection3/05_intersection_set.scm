(define (element-of-set? x set)
  (cond ((null? set) false)
        ((equal? x (car set)) true)
        (else (element-of-set? x (cdr set)))))
(define (adjoin-set x set)
  (if (element-of-set? x set)
    set
    (cons x set)))
(define (intersection-set set1 set2)
  (cond ((or (null? set1) (null? set2)) '())
        ((element-of-set? (car set1) set2)
          (cons (car set1)
            (intersection-set (cdr set1) set2)))
        (else (intersection-set (cdr set1) set2))))

(intersection-set
  (adjoin-set 10 (adjoin-set 20 (adjoin-set 30 nil)))
  (adjoin-set 10 (adjoin-set 15 (adjoin-set 20 nil))))

; expected: [ 10, [ 20, null ] ]
