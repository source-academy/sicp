def plus_curried(x):
    return lambda y: x + y
# brooks to be written by the student
print(brooks(plus_curried, llist(3, 4)))
