(define (>= x y)
  (or (> x y) (= x y)))

(>= 7 4)
