(define (abs x)
  (cond ((> x 0) x)
        ((= x 0) 0)
        ((< x 0) (- x))))
(define (close-enough? x y)
  (< (abs (- x y)) 0.001))

(close-enough? 7.7654 7.7666)

; expected: false
