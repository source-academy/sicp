def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def make_assignment(name, value_expression):
    return llist("assignment", name, value_expression)

my_assignment_statement = parse("x = 1")
print(is_declaration(my_assignment_statement))
print(assignment_symbol(my_assignment_statement))
print(assignment_value_expression(my_assignment_statement))
