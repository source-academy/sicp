print(137 + 349)
