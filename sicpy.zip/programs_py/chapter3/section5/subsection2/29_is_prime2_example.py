print(is_prime(100003))
