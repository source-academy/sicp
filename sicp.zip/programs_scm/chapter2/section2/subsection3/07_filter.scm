(define (filter predicate sequence)
  (cond ((null? sequence) nil)
        ((predicate (car sequence))
          (cons (car sequence)
                (filter predicate (cdr sequence))))
        (else (filter predicate (cdr sequence)))))

(define (odd? n)
  (= (remainder n 2) 1))

(filter odd? (list 1 2 3 4 5))

; expected: [ 1, [ 3, [ 5, null ] ] ]
