# The book proposes a primitive function get_new_pair.
# Since Python does not provide such a function, let's
# define it as follows, for the sake of the example.

def get_new_pair():
    return [None, None]
