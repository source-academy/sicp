def entry(tree): return head(tree)

def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def make_tree(entry, left, right):
    return llist(entry, left, right)
def tree_to_linked_list_2(tree):
    def copy_to_linked_list(tree, result_list):
        return (result_list
                if is_none(tree)
                else copy_to_linked_list(left_branch(tree),
                         pair(entry(tree),
                              copy_to_linked_list(right_branch(tree),
                                           result_list))))
    return copy_to_linked_list(tree, None)
