def make_mobile(left, right):
    return llist(left, right)
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def make_branch(length, structure):
    return llist(length, structure)
def left_branch(m):
    return head(m)
def right_branch(m):
    return head(tail(m))
def branch_length(b):
    return head(b)
def branch_structure(b):
    return head(tail(b))
def is_weight(x):
    return is_number(x)
def total_weight(x):
    return (x if is_weight(x)
            else total_weight(branch_structure(
                                left_branch(x))) +
                 total_weight(branch_structure(
                                right_branch(x))))

m = make_mobile(
              make_branch(10,
                  make_mobile(make_branch(10, 2), 
                      make_branch(4, 5))), 
              make_branch(10, 23))      
print(total_weight(m))

# expected: 30
