pi = 3.14159
radius = 10
print(pi * radius * radius)

# expected: 314.159
