(stream-ref (solve (lambda (y) y) 1 0.001) 1000)

; expected: 2.716923932235896
