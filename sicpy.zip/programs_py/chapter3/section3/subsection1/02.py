x = llist(llist("a", "b"), "c")
y = llist("e", "f")
z = pair(y, tail(x))
