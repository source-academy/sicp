; chapter=3 variant=non-det 
(define (an-element-of items)
  (require (not (null? items)))
  (amb (car items) (an-element-of (cdr items))))

; expected: 'apple'
