acc = make_account(100)

print(acc("withdraw")(50))
