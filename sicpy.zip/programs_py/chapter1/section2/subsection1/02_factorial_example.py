print(factorial(5))
