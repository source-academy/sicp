(define (remove item sequence)
  (filter (lambda (x) (not (= x item)))
          sequence))

(remove 3 (list 1 2 3 4 5))

; expected: 4
