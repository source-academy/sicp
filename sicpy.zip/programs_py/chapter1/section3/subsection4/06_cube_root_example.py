def average(x, y):
    return (x + y) / 2
def average_damp(f):
    return lambda x: average(x, f(x))
def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
def square(x): return x * x
def cube_root(x):
    return fixed_point(average_damp(lambda y: x / square(y)), 1)
print(cube_root(27))

# expected: 2.9999972321057697
