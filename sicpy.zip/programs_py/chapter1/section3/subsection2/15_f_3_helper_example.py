print(f_3(3, 4))
