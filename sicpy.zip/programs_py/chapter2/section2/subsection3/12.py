def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def plus(x, y):
    return x + y
print(reduce(plus, 0, llist(1, 2, 3, 4, 5)))

# expected: 15
