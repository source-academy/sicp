# chapter=3 variant=concurrent 
x = 10

def t1():
    global x
    x = x * x

def t2():
    global x
    x = x + 1

concurrent_execute(t1, t2)
