def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
my_function = make_function(llist("x", "y"), llist("return_statement", parse("x + y;")), the_empty_environment)
is_compound_function(my_function)
function_body(my_function)
function_environment(my_function)
function_parameters(my_function)
