(define (true? x)
  (not (eq? x false)))

(define (false? x)
  (eq? x false))

; expected: false
