def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def is_odd(n):
    return n % 2 == 1
print(filter(is_odd, llist(1, 2, 3, 4, 5)))

# expected: [ 1, [ 3, [ 5, None ] ] ]
