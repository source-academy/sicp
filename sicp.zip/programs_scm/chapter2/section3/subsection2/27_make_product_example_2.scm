(make-product 2 3))
