def square(x): return x * x
# THIS IS NOT A CORRECT SOLUTION
def square_linked_list(items):
    def iter(things, answer):
        return (answer if is_none(things)
                else iter(tail(things),
                          pair(answer,
                               square(head(things)))))
    return iter(items, None)

print(tail(square_linked_list(llist(1, 2, 3, 4))))

# expected: 16
