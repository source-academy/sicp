def pair(x, y):
    return lambda m: m(x, y)
def head(z):
    return z(lambda p, q: p)

x = pair(1, 2)
print(head(x))

# expected: 1
