def square(x):
    return math_exp(double(math_log(x)))

def double(x): return x + x

print(square(14))
