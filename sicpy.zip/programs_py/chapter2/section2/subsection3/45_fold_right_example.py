def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
# same as accumulate
fold_right = accumulate
print(length(fold_right(llist, None, llist(1, 2, 3))))
