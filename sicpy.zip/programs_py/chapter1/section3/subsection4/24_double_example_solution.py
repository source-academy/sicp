def inc(n):
    return n + 1
print(double(double(double))(inc)(5))  # returns 21
