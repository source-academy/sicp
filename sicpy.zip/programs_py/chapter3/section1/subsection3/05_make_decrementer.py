def make_decrementer(balance):
    return lambda amount: balance - amount
