(define (odd? n)
  (= (remainder n 2) 1))

(filter odd? (list 1 2 3 4 5))

; expected: [ 1, [ 3, [ 5, null ] ] ]
