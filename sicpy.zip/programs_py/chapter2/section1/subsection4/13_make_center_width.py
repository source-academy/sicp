def make_interval(x, y):
    return pair(x, y)
def lower_bound(i):
    return head(i)
def upper_bound(i):
    return tail(i)
def make_center_width(c, w):
    return make_interval(c - w, c + w)
def center(i):
    return (lower_bound(i) + upper_bound(i)) / 2
def width(i):
    return (upper_bound(i) - lower_bound(i)) / 2

my_interval = make_center_width(1, 0.5)
print(width(my_interval))

# expected: 0.5
