(define one-through-four (list 1 2 3 4))
(cons 10 one-through-four)

; expected: [ 2, [ 3, [ 4, null ] ] ]
