def inc(n):
    return n + 1
def double(f):
    return lambda x: f(f(x))

print(double(double(double))(inc)(5))  # returns 21

# expected: 21
