put(llist("a"), 1)
put(llist("b", "c"), 2)
put(llist("d", "e", "f"), 3)

print(get(llist("a")))
print(get(llist("b", "c")))
print(get(llist("d", "e", "f")))

put(llist("a", "b"), 1)
print(get(llist("a")))
put(llist("b", "c", "d"), 2)
print(get(llist("b", "c")))
put(llist("b"), 1)
print(get(llist("b")))
