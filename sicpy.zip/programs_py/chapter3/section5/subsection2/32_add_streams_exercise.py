def stream_tail(stream):
    return tail(stream)()
def memo(fun):
    already_run = False
    result = None
    def memoized():
        nonlocal already_run, result
        if not already_run:
            result = fun()
            already_run = True
            return result
        else:
            return result
    return memoized
def stream_map_2(f, s1, s2):
    return (None if is_none(s1) and is_none(s2)
            else error("unexpected argument -- stream_map_2", None)
                if is_none(s1) or is_none(s2)
            else pair(f(head(s1), head(s2)),
                      memo(lambda: stream_map_2(f, stream_tail(s1),
                                                stream_tail(s2)))))
def add_streams(s1, s2):
    return stream_map_2(lambda x1, x2: x1 + x2, s1, s2)
s = pair(1, lambda: add_streams(s, s))

print(eval_stream(s, 50))
