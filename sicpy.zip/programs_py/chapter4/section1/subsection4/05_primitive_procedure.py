def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_built_in_function(fun):
    return is_tagged_llist(fun, 'built_in')

def built_in_implementation(fun):
    return head(tail(fun))

my_built_in_plus = llist('built_in', lambda x, y: x + y)
print(built_in_implementation(my_built_in_plus)(1, 2))
print(is_built_in_function(my_built_in_plus))

# expected: True
