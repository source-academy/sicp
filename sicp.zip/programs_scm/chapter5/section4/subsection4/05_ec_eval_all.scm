(define the-global-environment (setup-environment))

      (start eceval)
