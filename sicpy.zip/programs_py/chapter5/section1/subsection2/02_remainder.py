def remainder(n, d):
    return n if n < d else remainder(n - d, d)

print(remainder(29, 5))
