print(sum_primes(7, 182))
