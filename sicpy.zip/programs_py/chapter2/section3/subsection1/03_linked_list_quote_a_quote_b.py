print(llist("a", "b"))

# expected: [ 'a', [ 'b', None ] ]
