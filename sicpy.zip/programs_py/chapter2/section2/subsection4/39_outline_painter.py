def make_vect(x, y):
    return pair(x, y)
def xcor_vect(vector):
    return head(vector)
def ycor_vect(vector):
    return tail(vector)
def scale_vect(factor, vector):
    return make_vect(factor * xcor_vect(vector), 
                     factor * ycor_vect(vector))
def add_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     + xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     + ycor_vect(vector2))
def sub_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     - xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     - ycor_vect(vector2))
def make_segment(v_start, v_end):
    return pair(v_start, v_end)
def start_segment(v):
    return head(v)
def end_segment(v):
    return tail(v)
def for_each(fun, items):
    if is_none(items):
        return None
    else:
        fun(head(items))
        for_each(fun, tail(items))
def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def make_frame(origin, edge1, edge2):
    return llist(origin, edge1, edge2)
def origin_frame(frame):
    return ref(frame, 0)
def edge1_frame(frame):
    return ref(frame, 1)
def edge2_frame(frame):
    return ref(frame, 2)
def frame_coord_map(frame):
    return lambda v: add_vect(origin_frame(frame), 
                         add_vect(scale_vect(xcor_vect(v), 
                                             edge1_frame(frame)), 
                                  scale_vect(ycor_vect(v), 
                                             edge2_frame(frame))))
# "drawing a line" here simulated
# by printing the coordinates of
# the start and end of the line
def draw_line(v_start, v_end):
    print("line starting at")
    print(v_start)
    print("line ending at")
    print(v_end)
def segments_to_painter(segment_list):
    return lambda frame: 
             for_each(lambda segment:
                        draw_line(
                            frame_coord_map(frame)
                                (start_segment(segment)), 
                            frame_coord_map(frame)
                                (end_segment(segment))), 
                      segment_list)
unit_origin = make_vect(0, 0)
unit_edge_1 = make_vect(1, 0)
unit_edge_2 = make_vect(0, 1)
unit_frame = make_frame(unit_origin, 
                              unit_edge_1,
                              unit_edge_2)
outline_start_1 = make_vect(0, 0)
outline_end_1 = make_vect(1, 0)
outline_segment_1 = make_segment(outline_start_1, 
                                       outline_end_1)
outline_start_2 = make_vect(1, 0)
outline_end_2 = make_vect(1, 1)
outline_segment_2 = make_segment(outline_start_2, 
                                       outline_end_2)
outline_start_3 = make_vect(1, 1)
outline_end_3 = make_vect(0, 1)
outline_segment_3 = make_segment(outline_start_3, 
                                       outline_end_3)
outline_start_4 = make_vect(0, 1)
outline_end_4 = make_vect(0, 0)
outline_segment_4 = make_segment(outline_start_4, 
                                       outline_end_4)
outline_painter = segments_to_painter(
                      llist(outline_segment_1, 
                            outline_segment_2,
                            outline_segment_3,
                            outline_segment_4))

print(outline_painter(unit_frame))
