my_built_in_plus = llist('built_in', lambda x, y: x + y)
print(built_in_implementation(my_built_in_plus)(1, 2))
print(is_built_in_function(my_built_in_plus))
