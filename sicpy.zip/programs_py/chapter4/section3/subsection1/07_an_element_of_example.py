xs = llist('apple', 'banana', 'cranberry')
an_element_of(xs)
# Press the Run button for the first solution. Type
# retry
# in the REPL on the right, for more solutions
