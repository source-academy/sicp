def adjoin_set(x, set):
    return (llist(x)
            if is_none(set)
            else set
            if x == head(set)
            else pair(x, set)
            if x < head(set)
            else pair(head(set),
                      adjoin_set(x, tail(set))))
print(tail(union_set(
   adjoin_set(10, adjoin_set(20, adjoin_set(30, None))),
   adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))))
