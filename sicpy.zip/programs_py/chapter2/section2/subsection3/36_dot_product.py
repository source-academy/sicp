def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def plus(x, y):
    return x + y
def times(x, y):
    return x * y
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def reduce_n(op, init, seqs):
    return (None if is_none(head(seqs))
            else pair(reduce(op, init, map(lambda x: head(x), seqs)),
                      reduce_n(op, init, map(lambda x: tail(x), seqs))))
def dot_product(v, w):
    return reduce(plus, 0, reduce_n(times, 1, llist(v, w)))

print(dot_product(llist(1, 2), llist(3, 4)))

# expected: 11
