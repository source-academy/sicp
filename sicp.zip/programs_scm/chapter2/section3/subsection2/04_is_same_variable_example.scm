(same-variable? 'xyz 'xyz)
