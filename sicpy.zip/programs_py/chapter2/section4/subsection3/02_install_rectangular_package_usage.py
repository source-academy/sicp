# chapter=3 
print(install_rectangular_package())
