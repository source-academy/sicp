def make_tableau(transform, s):
    return pair(s, lambda: make_tableau(transform, transform(s)))
