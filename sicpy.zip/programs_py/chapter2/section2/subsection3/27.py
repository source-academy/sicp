def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def salary_of_highest_paid_programmer(records):
    return accumulate(max,
                      0,
                      map(salary,
                          filter(is_programmer, records)))

my_records = llist(llist("Linus", "programmer", 30000),
                         llist("Richard", "programmer", 25000),
                         llist("Bill", "manager", 2500000))
def is_programmer(record):
    return head(tail(record)) == "programmer"
def salary(record):
    return head(tail(tail(record)))
print(salary_of_highest_paid_programmer(my_records))

# expected: 30000
