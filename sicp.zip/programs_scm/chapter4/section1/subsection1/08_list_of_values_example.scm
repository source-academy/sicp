(define the-global-environment (setup-environment))
(eval (read) the-global-environment)
