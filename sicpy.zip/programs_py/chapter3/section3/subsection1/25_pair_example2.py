z2 = pair(llist("a", "b"), llist("a", "b"))
