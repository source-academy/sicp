def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def entry(tree): return head(tree)

def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def make_tree(entry, left, right):
    return llist(entry, left, right)
def tree_to_linked_list_1(tree):
    return (None
            if is_none(tree)
            else append(tree_to_linked_list_1(left_branch(tree)),
                        pair(entry(tree),
                             tree_to_linked_list_1(right_branch(tree)))))
