def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
print(llist_ref(solve(lambda x: x, 1, 0.1), 10))
"""
