def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
def distinct(items):
    return True if is_none(items) else True if is_none(tail(items)) else distinct(tail(items)) if is_none(member(head(items), tail(items))) else False

distinct(llist(1, 2, 4, 4, 5))

# expected: false
