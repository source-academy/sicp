6 / 2;

// expected: 3
