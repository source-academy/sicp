def f(g):
    return g(2)
