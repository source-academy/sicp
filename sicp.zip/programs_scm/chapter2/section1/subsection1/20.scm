(define (abs x)
  (cond ((> x 0) x)
        ((= x 0) 0)
        ((< x 0) (- x))))
(define (gcd a b)
  (if (= b 0)
      a
      (gcd b (remainder a b))))




; expected: [ -3, 4 ]
