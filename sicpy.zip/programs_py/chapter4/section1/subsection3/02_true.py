def is_truthy(x):
    return x if is_boolean(x) else error(x, "boolean expected, received")
def is_falsy(x):
    return not is_truthy(x)

is_truthy(False)
# should return false because only true is truthy

# expected: false
