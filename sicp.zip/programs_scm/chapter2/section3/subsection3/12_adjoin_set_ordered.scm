

(adjoin-set 10 (adjoin-set 15 (adjoin-set 20 nil)))

; expected: [ 10, [ 15, [ 20, null ] ] ]
