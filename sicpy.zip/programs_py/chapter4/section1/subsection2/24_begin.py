def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def is_sequence(stmt):
    return is_tagged_list(stmt, "sequence")
def sequence_statements(stmt):
    return head(tail(stmt))
def first_statement(stmts):
    return head(stmts)
def rest_statements(stmts):
    return tail(stmts)
def is_empty_sequence(stmts):
    return is_none(stmts)
def is_last_statement(stmts):
    return is_none(tail(stmts))

my_sequence = parse("1; true; 45;")
is_sequence(my_sequence)
my_actions = sequence_statements(my_sequence)
is_empty_sequence(my_actions)
is_last_statement(my_actions)
first_statement(my_actions)
rest_statements(my_actions)
ref(rest_statements(my_actions), 1)

# expected: [ 'literal', [ 45, null ] ]
