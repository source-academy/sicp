(define one-half (make-rat 1 2))

(print-rat one-half)
