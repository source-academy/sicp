# solution provided by GitHub user clean99

def contains_cycle(x):
    counted_pairs = None
    def is_counted_pair(counted_pairs, x):
        return (False if is_none(counted_pairs)
                else True if head(counted_pairs) is x
                else is_counted_pair(tail(counted_pairs), x))
    def detect_cycle(x):
        nonlocal counted_pairs
        if is_none(x):
            return False
        elif is_counted_pair(counted_pairs, x):
            return True
        else:
            counted_pairs = pair(x, counted_pairs)
            return detect_cycle(tail(x))
    return detect_cycle(x)

three_list = llist("a", "b", "c")
cycle = llist("g", "h", "i")
set_tail(tail(tail(cycle)), cycle)

# displays False
print(contains_cycle(three_list))

# displays True
print(contains_cycle(cycle))
