(define (entry tree) (car tree))

(define (left-branch tree) (cadr tree))

(define (right-branch tree) (caddr tree))

(define (make-tree entry left right)
  (list entry left right))

(entry
  (left-branch
    (right-branch
      (make-tree
        10
        'nil
        (make-tree
          30
          (make-tree 20 'nil 'nil)
          'nil)))))

; expected: 20
