(define ones (cons-stream 1 ones))

; expected: 1
