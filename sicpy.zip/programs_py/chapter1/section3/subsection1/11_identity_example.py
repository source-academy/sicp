print(identity(42))
