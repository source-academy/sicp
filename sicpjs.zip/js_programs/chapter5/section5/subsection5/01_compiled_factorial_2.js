// compute $n - 1$ which is the argument for factorial
  assign("fun", list(op("lookup_symbol_value"), constant("-"), reg("env"))),
  assign("val", constant(1)),
  assign("argl", list(op("list"), reg("val"))),
  assign("val", list(op("lookup_symbol_value"), constant("n"), reg("env"))),
  assign("argl", list(op("pair"), reg("val"), reg("argl"))),
  test(list(op("is_primitive_function"), reg("fun"))),
  branch(label("primitive_branch10")),
"compiled_branch11",
  assign("continue", label("after_call12")),
  save("continue"),
  push_marker_to_stack(),
  assign("val", list(op("compiled_function_entry"), reg("fun"))),
  go_to(reg("val")),
"primitive_branch10",
  assign("val", list(op("apply_primitive_function"), 
                     reg("fun"), reg("argl"))),
###
"after_call12",                     // val now holds result of n - 1
  assign("argl", list(op("list"), reg("val"))),
  restore("fun"),
  // apply factorial
  test(list(op("is_primitive_function"), reg("fun"))),
  branch(label("primitive_branch14")),
"compiled_branch15",
  assign("continue", label("after_call16")),
  save("continue"),
  push_marker_to_stack(),
  assign("val", list(op("compiled_function_entry"), reg("fun"))),
  go_to(reg("val")),
"primitive_branch14",
  assign("val", list(op("apply_primitive_function"), reg("fun"), reg("argl"))),
###
"after_call16",                     // val now has result of factorial(n - 1)
  restore("argl"),                  // restore partial argument list for *
  assign("argl", list(op("pair"), reg("val"), reg("argl"))),
  restore("fun"),                   // restore *
  restore("continue"),
  // apply * and return its value
  test(list(op("is_primitive_function"), reg("fun"))),
  branch(label("primitive_branch18")),
###
"compiled_branch19", // note the compound function here is called tail-recursively
  save("continue"),
  push_marker_to_stack(),
  assign("val", list(op("compiled_function_entry"), reg("fun"))),
  go_to(reg("val")),
"primitive_branch18",
  assign("val", list(op("apply_primitive_function"), reg("fun"), reg("argl"))),
  go_to(reg("continue")),
"after_call20",
"after_cond5",
"after_lambda2",
  // assign the function to the name factorial
  perform(list(op("assign_symbol_value"), 
               constant("factorial"), reg("val"), reg("env"))),
  assign("val", constant(undefined)),
  go_to(reg("continue"))
