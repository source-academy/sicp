# "drawing a line" here simulated
# by printing the coordinates of
# the start and end of the line
def draw_line(v_start, v_end):
    print("line starting at")
    print(v_start)
    print("line ending at")
    print(v_end)
