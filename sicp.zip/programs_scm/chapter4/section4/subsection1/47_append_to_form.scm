(rule (append-to-form () ?y ?y))

(rule (append-to-form (?u . ?v) ?y (?u . ?z))
      (append-to-form ?v ?y ?z))

; expected: 'append_to_form(list(1, 2), list(3, 4), list(1, 2, 3, 4))'
