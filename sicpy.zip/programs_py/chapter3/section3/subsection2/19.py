# JavaScript original provided by GitHub user devinryu

def make_queue():
    front_ptr = None
    rear_ptr = None
    def is_empty_queue():
        return is_none(front_ptr)
    def insert_queue(item):
        nonlocal front_ptr, rear_ptr
        new_pair = pair(item, None)
        if is_empty_queue():
            front_ptr = new_pair
            rear_ptr = new_pair
        else:
            set_tail(rear_ptr, new_pair)
            rear_ptr = new_pair
    def delete_queue():
        nonlocal front_ptr
        if is_empty_queue():
            error("FRONT called with an empty queue")
        else:
            front_ptr = tail(front_ptr)
    def print_queue():
        print(front_ptr)
    def dispatch(m):
        return (insert_queue if m == "insert_queue"
                else delete_queue if m == "delete_queue"
                else is_empty_queue if m == "is_empty_queue"
                else print_queue if m == "print_queue"
                else error("Unknown operation -- DISPATCH", m))
    return dispatch

def insert_queue(queue, item):
    return queue("insert_queue")(item)

def delete_queue(queue):
    return queue("delete_queue")()

def print_queue(queue):
    return queue("print_queue")()

q = make_queue()
print_queue(q)  # prints: None
insert_queue(q, "a")
print_queue(q)  # prints: ["a", None]
insert_queue(q, "b")
print_queue(q)  # prints: ["a", ["b", None]]
delete_queue(q)
print(print_queue(q))  # prints: ["b", None]
