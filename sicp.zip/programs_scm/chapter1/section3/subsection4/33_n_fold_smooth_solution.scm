(define (cube x) (* x x x))






; expected: 64.00000000399997
