print(is_truthy(False))
# should print False, because only True is truthy
