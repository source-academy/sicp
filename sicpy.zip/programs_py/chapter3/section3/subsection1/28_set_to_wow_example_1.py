x = llist("a", "b")
z1 = pair(x, x)
print(z1)

# expected: [ [ 'a', [ 'b', None ] ], [ 'a', [ 'b', None ] ] ]
