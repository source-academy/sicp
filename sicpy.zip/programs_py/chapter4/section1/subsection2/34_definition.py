def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_declaration(component):
    return is_tagged_list(component, "constant_declaration") or is_tagged_list(component, "variable_declaration") or is_tagged_list(component, "function_definition")

my_assignment_statement = parse("x = 1")
print(is_declaration(my_assignment_statement))
print(assignment_symbol(my_assignment_statement))
print(assignment_value_expression(my_assignment_statement))
