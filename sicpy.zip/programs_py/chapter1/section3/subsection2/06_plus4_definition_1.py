plus4 = lambda x: x + 4

print(plus4(3))
