;; square-list to be given by student
(square-list (list 1 2 3 4))
