(define us-coins (list 50 25 10 5 1))

(define uk-coins (list 100 50 20 10 5 2 1))
