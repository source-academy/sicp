def set_to_wow(x):
    set_head(head(x), "wow")
    return x
x = llist("a", "b")
z1 = pair(x, x)
print(set_to_wow(z1))

# expected: [ [ 'wow', [ 'b', None ] ], [ 'wow', [ 'b', None ] ] ]
