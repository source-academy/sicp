def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_literal(component):
    return is_tagged_llist(component, 'literal')
def literal_value(component):
    return head(tail(component))

my_program = parse('True\n1')
my_true_statement = llist_ref(llist_ref(my_program, 1), 0)
print(is_literal(my_true_statement))

# expected: True
