def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
def average(x, y):
    return (x + y) / 2
def average_damp(f):
    return lambda x: average(x, f(x))
def sqrt(x):
    return fixed_point_of_transform(lambda y: x / y,
                                    average_damp,
                                    1)
def fixed_point_of_transform(g, transform, guess):
    return fixed_point(transform(g), guess)

print(sqrt(6))

# expected: 2.4494897427875517
