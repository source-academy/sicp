(define (make-pair-sum pair)
  (list (car pair) (cadr pair) (+ (car pair) (cadr pair))))

(make-pair-sum (list 8 9))

; expected: [ 8, [ 9, [ 17, null ] ] ]
