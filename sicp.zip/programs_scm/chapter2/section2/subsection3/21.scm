(define (even? n)
  (= (remainder n 2) 0))
(define (fib n)
  (cond ((= n 0) 0)
        ((= n 1) 1)
        (else (+ (fib (- n 1))
                 (fib (- n 2))))))
(define (enumerate-interval low high)
   (if (> low high)
      nil
      (cons low (enumerate-interval (+ low 1) high))))
(define (even-fibs n)
   (accumulate cons
               nil
               (filter even?
                 (map fib
                      (enumerate-interval 0 n)))))

(even-fibs 9)

; expected: [ 2, [ 8, [ 34, null ] ] ]
