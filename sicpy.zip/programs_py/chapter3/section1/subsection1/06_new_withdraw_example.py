new_withdraw(60)
print(new_withdraw(60))
