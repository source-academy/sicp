empty_board = None
