(define (make-interval a b) (cons a b))

(define (add-interval x y)
  (make-interval (+ (lower-bound x) (lower-bound y))
                 (+ (upper-bound x) (upper-bound y))))

(add-interval (make-interval 1 2) (make-interval 3 5))

; expected: [ 4, 7 ]
