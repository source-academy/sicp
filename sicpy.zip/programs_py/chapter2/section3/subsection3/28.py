def make_record(key, data):
    return pair(key, data)
def key(record):
    return head(record)
def data(record):
    return tail(record)
def lookup(given_key, set_of_records):
    return (False
            if is_none(set_of_records)
            else head(set_of_records)
            if given_key == key(head(set_of_records))
            else lookup(given_key, tail(set_of_records)))

print(lookup(3, llist(make_record(2, "Venus"), 
                make_record(5, "Jupiter"),
                make_record(4, "Mars"),
                make_record(3, "Earth"),
                make_record(6, "Saturn"))))

# expected: [ 3, 'Earth' ]
