def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
x = pair(llist(1, 2), llist(3, 4))
print(length(llist(x, x)))

# expected: 2
