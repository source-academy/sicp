(define (square x) (* x x))
((repeated square 2) 5)
