# The book proposes a primitive function get_new_pair.
# Since Python does not provide such a function, let's
# define it as follows, for the sake of the example.

def get_new_pair():
    return [None, None]
def pair(x, y):
    fresh = get_new_pair()
    set_head(fresh, x)
    set_tail(fresh, y)
    return fresh

print(pair(pair(1, 2), 4))

# expected: [ [ 1, 2 ], 4 ]
