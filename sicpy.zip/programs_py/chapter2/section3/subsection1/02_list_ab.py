a = 1
b = 2
print(llist(a, b))

# expected: [ 1, [ 2, None ] ]
