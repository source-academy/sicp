my_lambda = parse("lambda x: x")
print(is_lambda_expression(my_lambda))
print(lambda_parameter_symbols(my_lambda))
print(lambda_body(my_lambda))
