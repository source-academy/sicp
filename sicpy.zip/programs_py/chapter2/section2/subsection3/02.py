def square(x): return x * x
def is_odd(n):
    return n % 2 == 1
def sum_odd_squares(tree):
    return (0 if is_none(tree)
            else (square(tree) if is_odd(tree)
                  else 0) if not is_pair(tree)
            else sum_odd_squares(head(tree)) +
                 sum_odd_squares(tail(tree)))

print(sum_odd_squares(llist(llist(2, 3), llist(4, 5))))

# expected: 34
