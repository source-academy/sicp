;; positive? and negative? are predefined in Scheme
