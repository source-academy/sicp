a = 3
b = a + 1
print(6 if a == 4 else 6 + 7 + a if b == 4 else 25)

# expected: 16
