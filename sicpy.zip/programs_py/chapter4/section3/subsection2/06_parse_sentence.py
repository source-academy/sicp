# chapter=3 variant=non-det 
nouns = llist("noun", "student", "professor", "cat", "class")
verbs = llist("verb", "studies", "lectures", "eats", "sleeps")
articles = llist("article", "the", "a")
def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
not_yet_parsed = None
def parse_word(word_list):
    require( not is_none(not_yet_parsed))
    require( not is_none(member(head(not_yet_parsed), tail(word_list))))
    found_word = head(not_yet_parsed)
    not_yet_parsed = tail(not_yet_parsed)
    return llist(head(word_list), found_word)
def parse_noun_phrase():
    return llist("noun-phrase", parse_word(articles), parse_word(nouns))
def parse_input(input):
    not_yet_parsed = input
    sent = parse_sentence()
    require(is_none(not_yet_parsed))
    return sent
def parse_sentence():
    return llist("sentence", parse_noun_phrase(), parse_word(verbs))

parse_input(llist("the",  "cat",  "eats"))

# expected: [ "sentence", [ ["noun-phrase", [["article", ["the", null]], [["noun", ["cat", null]], null]]], [["verb", ["eats", null]], null]]]
