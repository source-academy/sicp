def eval_function_definition(component, env):
    fun = make_function(function_definition_parameter_symbols(component),
                        function_definition_body(component),
                        env)
    assign_symbol_value(function_definition_symbol(component), fun, env)
    return None
