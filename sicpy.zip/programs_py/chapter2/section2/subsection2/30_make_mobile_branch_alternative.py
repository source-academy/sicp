def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def make_mobile(left, right):
    return pair(left, right)
def make_branch(length, structure):
    return pair(length, structure)
