def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
squares = llist(1, 4, 9, 16, 25)

print(ref(squares, 3))

# expected: 16
