(define x (cons 1 2))
(car x)

; expected: 1
