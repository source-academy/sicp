(define (remainder n d)
  (if (< n d)
      n
      (remainder (- n d) d)))
