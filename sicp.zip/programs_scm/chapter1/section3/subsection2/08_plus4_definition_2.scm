(define plus4 (lambda (x) (+ x 4)))

(plus4 3)
