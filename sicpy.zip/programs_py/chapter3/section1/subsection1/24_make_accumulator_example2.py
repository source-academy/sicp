# make_accumulator to be written by students
a = make_accumulator(5)
print(a(10))
print(a(10))
