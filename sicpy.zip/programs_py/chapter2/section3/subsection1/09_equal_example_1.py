# function equal to be written by student
print(   llist("this", "is", "a", "linked", "list")
      == llist("this", "is", "a", "linked", "list"))

# expected: True
