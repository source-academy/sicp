print(memo_fib(5))
