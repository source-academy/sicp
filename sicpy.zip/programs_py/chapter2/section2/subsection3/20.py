def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def square(x): return x * x
def plus(x, y):
    return x + y
def is_odd(n):
    return n % 2 == 1
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def enumerate_tree(tree):
    return (None if is_none(tree)
            else llist(tree) if not is_pair(tree)
            else append(enumerate_tree(head(tree)),
                        enumerate_tree(tail(tree))))
def sum_odd_squares(tree):
    return reduce(plus,
                  0,
                  map(square,
                      filter(is_odd,
                             enumerate_tree(tree))))

print(sum_odd_squares(llist(llist(2, 3), llist(4, 5))))

# expected: 34
