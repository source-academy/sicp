def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def make_name(symbol):
    return llist("name", symbol)

my_name_statement = parse("x;")
print(is_name(my_name_statement))
print(symbol_of_name(my_name_statement))
