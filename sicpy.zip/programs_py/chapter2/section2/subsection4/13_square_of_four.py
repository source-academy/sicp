import { heart, stack, quarter_turn_left, quarter_turn_right, turn_upside_down, beside, show } from 'rune';

def identity(x):
    return x
def square_of_four(tl, tr, bl, br):
    return lambda painter: stack(beside(tl(painter), tr(painter)),
                            beside(bl(painter), br(painter)))

print(show(square_of_four(turn_upside_down, identity, 
                    quarter_turn_right, quarter_turn_left)
     (heart)
    ))
