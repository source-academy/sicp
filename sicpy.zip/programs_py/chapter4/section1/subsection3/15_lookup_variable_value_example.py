def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def extend_environment(symbols, vals, base_env):
    if length(symbols) == length(vals):
        return pair(make_frame(symbols, vals), base_env)
    elif length(symbols) < length(vals):
        error('too many arguments supplied', pair(symbols, vals))
    else:
        error('too few arguments supplied', pair(symbols, vals))
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

def add_binding_to_frame(symbol, val, frame):
    set_head(frame, pair(symbol, head(frame)))
    set_tail(frame, pair(val, tail(frame)))
my_environment = extend_environment(llist('x', 'y', 'z'), llist(1, 2, 3), the_empty_environment)
print(lookup_symbol_value('x', my_environment))
