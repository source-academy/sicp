def is_even(n):
    return n % 2 == 0
print(expmod(4, 3, 5))
