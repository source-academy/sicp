(define (get-contents register)
  (register 'get))

(define (set-contents! register value)
  ((register 'set) value))
