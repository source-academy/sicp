print(5 + 3 + 4)

# expected: 12
