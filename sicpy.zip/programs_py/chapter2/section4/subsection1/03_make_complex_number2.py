def add_complex(z1, z2):
    return make_from_real_imag(real_part(z1) + real_part(z2),
                               imag_part(z1) + imag_part(z2))
def sub_complex(z1, z2):
    return make_from_real_imag(real_part(z1) - real_part(z2),
                               imag_part(z1) - imag_part(z2))
def mul_complex(z1, z2):
    return make_from_mag_ang(magnitude(z1) * magnitude(z2),
                             angle(z1) + angle(z2))
def div_complex(z1, z2):
    return make_from_mag_ang(magnitude(z1) / magnitude(z2),
                             angle(z1) - angle(z2))
def square(x): return x * x
def real_part(z):
    return magnitude(z) * math_cos(angle(z))
def imag_part(z):
    return magnitude(z) * math_sin(angle(z))
def magnitude(z): return head(z)

def angle(z): return tail(z)

def make_from_real_imag(x, y):
    return pair(math_sqrt(square(x) + square(y)),
                math_atan2(y, x))
def make_from_mag_ang(r, a): return pair(r, a)

my_co_num_1 = make_from_real_imag(2.5, -0.5)
my_co_num_2 = make_from_real_imag(2.5, -0.5)

result = add_complex(my_co_num_1,
                     mul_complex(my_co_num_2,
                                 my_co_num_2))

print(imag_part(result))

# expected: -3.0
