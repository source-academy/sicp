x = llist(1, 2, 3)

y = llist(4, 5, 6)
pair(x, y)
# result: [[1, [2, [3, None]]], [4, [5, [6, None]]]]
