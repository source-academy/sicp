def assoc(key, records):
    return (None if is_none(records)
            else head(records) if key == head(head(records))
            else assoc(key, tail(records)))
