def intersection_set(set1, set2):
    if is_none(set1) or is_none(set2):
        return None
    else:
        x1 = head(set1)
        x2 = head(set2)
        return (pair(x1, intersection_set(tail(set1), tail(set2)))
                if x1 == x2
                else intersection_set(tail(set1), set2)
                if x1 < x2
                # $\texttt{x2 < x1}$
                else intersection_set(set1, tail(set2)))
print(intersection_set(
   llist(10, 20, 30),
   llist(10, 15, 20)))
