print(fib(6))
