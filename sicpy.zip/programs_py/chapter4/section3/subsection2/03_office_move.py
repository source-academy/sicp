# chapter=3 variant=non-det 
def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
def distinct(items):
    return True if is_none(items) else True if is_none(tail(items)) else distinct(tail(items)) if is_none(member(head(items), tail(items))) else False
def office_move():
    alyssa = amb(1, 2, 3, 4, 5)
    ben = amb(1, 2, 3, 4, 5)
    cy = amb(1, 2, 3, 4, 5)
    lem = amb(1, 2, 3, 4, 5)
    louis = amb(1, 2, 3, 4, 5)
    require(distinct(llist(alyssa, ben, cy, lem, louis)))
    require(alyssa != 5)
    require(ben != 1)
    require(cy != 5)
    require(cy != 1)
    require(lem > ben)
    require(abs(louis - cy) != 1)
    require(abs(cy - ben) != 1)
    return llist(llist("alyssa", alyssa), llist("ben", ben), llist("cy", cy), llist("lem", lem), llist("louis", louis))

head(office_move())

# expected: [ 'alyssa', [ 3, null ] ]
