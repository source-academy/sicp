def times(x, y):
    return x * y
