(lambda n: ((lambda fact: (fact(fact, n))) (lambda ft, k: (1 if k == 1 else k * ft(ft, k - 1)))))(10)

# expected: 3628800
