my_application = parse('math_pow(3, 4)')
print(is_application(my_application))
print(function_expression(my_application))
print(arg_expressions(my_application))
