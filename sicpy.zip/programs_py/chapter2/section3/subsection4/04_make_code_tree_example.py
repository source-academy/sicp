my_leaf_1 = make_leaf("A", 8)
my_leaf_2 = make_leaf("B", 3)

print(head(tail(make_code_tree(my_leaf_1, my_leaf_2))))
