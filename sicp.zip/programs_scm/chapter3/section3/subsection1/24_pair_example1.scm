(define x (list 'a 'b))
(define z1 (cons x x))
