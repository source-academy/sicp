def assoc(key, records):
    return (None if is_none(records)
            else head(records) if key == head(head(records))
            else assoc(key, tail(records)))
def make_table():
    local_table = llist('*table*')
    def lookup(key_1, key_2):
        subtable = assoc(key_1, tail(local_table))
        if is_none(subtable):
            return None
        else:
            record = assoc(key_2, tail(subtable))
            return (None
                    if is_none(record)
                    else tail(record))
    def insert(key_1, key_2, value):
        subtable = assoc(key_1, tail(local_table))
        if is_none(subtable):
            set_tail(local_table,
                     pair(llist(key_1, pair(key_2, value)),
                          tail(local_table)))
        else:
            record = assoc(key_2, tail(subtable))
            if is_none(record):
                set_tail(subtable,
                         pair(pair(key_2, value), tail(subtable)))
            else:
                set_tail(record, value)
    def dispatch(m):
        return (lookup if m == 'lookup'
                else insert if m == 'insert'
                else error('unknown operation -- table', m))
    return dispatch
def insert(key_1, key_2, value, table):
    subtable = assoc(key_1, tail(table))
    if is_none(subtable):
        set_tail(table,
                 pair(llist(key_1, pair(key_2, value)), tail(table)))
    else:
        record = assoc(key_2, tail(subtable))
        if is_none(record):
            set_tail(subtable,
                     pair(pair(key_2, value), tail(subtable)))
        else:
            set_tail(record, value)
    return 'ok'
def lookup(key_1, key_2, table):
    subtable = assoc(key_1, tail(table))
    if is_none(subtable):
        return None
    else:
        record = assoc(key_2, tail(subtable))
        return (None
                if is_none(record)
                else tail(record))

t = llist('*table*')
insert('a', 'b', 10, t)
print(lookup('a', 'b', t))

# expected: 10
