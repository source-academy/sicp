def make_conditional_expr_decl(predicate, consequent_expression, alternative_expression):
    return llist("conditional_expression", predicate, consequent_expression, alternative_expression)
def make_literal(value):
    return llist("literal", value)
# Syntax selectors
def logical_operation(component):
    return head(tail(component))
def first_expression(component):
    return head(tail(tail(component)))
def second_expression(component):
    return head(tail(tail(tail(component))))
def logical_comp_decl_to_conditional_expr_decl(component):
    operation = logical_operation(component)
    return make_conditional_expr_decl( first_expression(component), second_expression(component), False ) if operation == "&&" else make_conditional_expr_decl( first_expression(component), True, second_expression(component) ) if operation == "||" else error(component, "unknown operation -- logical_comp_decl_to_conditional_expr_decl")
print(logical_comp_decl_to_conditional_expr_decl(parse("a && b;")))
print(logical_comp_decl_to_conditional_expr_decl(parse("a || b;")))
print(logical_comp_decl_to_conditional_expr_decl(parse("(a && !b) || (!a && b);")))
