# chapter=3 variant=non-det 
def require(p):
    if not p:
        amb()

x = amb(1, 3, 5, 7, 9)
require(x >= 4)
x
# Press the Run button for the first solution. Type
# retry
# in the REPL on the right, for more solutions
