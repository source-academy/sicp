(define (>= x y)
  (not (< x y)))

(>= 7 4)
