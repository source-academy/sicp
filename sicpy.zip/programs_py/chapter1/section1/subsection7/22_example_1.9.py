print(cube_root(3, 27))
