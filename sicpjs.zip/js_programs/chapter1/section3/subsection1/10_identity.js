function identity(x) {
    return x;
}

identity(42);
