# Solution by GitHub user clean99

def make_table(same_key):
    local_table = llist("*table*")
    def assoc(key, records):
        return (None if is_none(records)
                else head(records) if same_key(key, head(head(records)))
                else assoc(key, tail(records)))
    def lookup(key):
        record = assoc(key, tail(local_table))
        return (None if is_none(record)
                else tail(record))
    def insert(key, value):
        record = assoc(key, tail(local_table))
        if is_none(record):
            set_tail(local_table,
                     pair(pair(key, value), tail(local_table)))
        else:
            set_tail(record, value)
        return "ok"
    def dispatch(m):
        return (lookup if m == "lookup"
                else insert if m == "insert"
                else error("unknow operation -- table", m))
    return dispatch

operation_table = make_table(lambda a, b: a == b)
get = operation_table("lookup")
put = operation_table("insert")
