def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def scale_linked_list(items, factor):
    return (None if is_none(items)
            else pair(head(items) * factor,
                      scale_linked_list(tail(items), factor)))
def scale_linked_list(items, factor):
    return map(lambda x: x * factor, items)

print(tail(tail(scale_linked_list(llist(1, 2, 3, 4, 5), 10))))

# expected: [ 30, [ 40, [ 50, None ] ] ]
