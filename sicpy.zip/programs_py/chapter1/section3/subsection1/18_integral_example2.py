def cube(x):
    return x * x * x
def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def integral(f, a, b, dx):
    def add_dx(x):
        return x + dx
    return sum(f, a + dx / 2, add_dx, b) * dx
print(integral(cube, 0, 1, 0.001))
