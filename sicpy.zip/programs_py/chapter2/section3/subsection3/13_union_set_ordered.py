def adjoin_set(x, set):
    return (llist(x)
            if is_none(set)
            else set
            if x == head(set)
            else pair(x, set)
            if x < head(set)
            else pair(head(set),
                      adjoin_set(x, tail(set))))
def union_set(set1, set2):
    if is_none(set1):
        return set2
    elif is_none(set2):
        return set1
    else:
        x1 = head(set1)
        x2 = head(set2)
        return (pair(x1, union_set(tail(set1),
                                   tail(set2)))
                if x1 == x2
                else pair(x1, union_set(tail(set1), set2))
                if x1 < x2
                else pair(x2, union_set(set1, tail(set2))))

print(tail(union_set(
   adjoin_set(10, adjoin_set(20, adjoin_set(30, None))),
   adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))))

# expected: [ 15, [ 20, [ 30, None ] ] ]
