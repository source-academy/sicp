def make_interval(x, y):
    return pair(x, y)
def lower_bound(i):
    return head(i)
def upper_bound(i):
    return tail(i)
def make_center_width(c, w):
    return make_interval(c - w, c + w)
def center(i):
    return (lower_bound(i) + upper_bound(i)) / 2
def width(i):
    return (upper_bound(i) - lower_bound(i)) / 2
def make_center_percent(center, percent):
    width = center * (percent / 100)
    return make_center_width(center, width)
def percent(i):
    return (width(i) / center(i)) * 100

my_interval = make_center_percent(6.0, 10)
print(percent(my_interval))

# expected: 9.999999999999993
