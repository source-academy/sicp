print(is_variable("xyz"))
