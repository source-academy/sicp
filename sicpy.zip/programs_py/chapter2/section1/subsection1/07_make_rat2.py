def make_rat(n, d): return pair(n, d)

def numer(x): return head(x)

def denom(x): return tail(x)

print(numer(make_rat(2, 3)))

# expected: 2
