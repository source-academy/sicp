def make_sum(a1, a2): return llist("+", a1, a2)

def make_product(m1, m2): return llist("*", m1, m2)
def multiplicand(s): return head(tail(tail(s)))

print(multiplicand(make_product("x", 3)))

# expected: 3
