(define (make-sum a1 a2) (list '+ a1 a2))
(define (make-product m1 m2) (list '* m1 m2))
(define (augend s) (caddr s))

(augend (make-sum 'x 3))

; expected: 3
