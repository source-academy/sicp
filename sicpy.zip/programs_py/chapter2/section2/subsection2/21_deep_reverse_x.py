x = llist(llist(1, 2), llist(3, 4))
# deep_reverse to be written by student
print(head(deep_reverse(x)))
