print(expt(3, 4))
