def last_pair(x):
    return (x if is_none(tail(x))
            else last_pair(tail(x)))

print(last_pair(llist(1, 2, 3, 4, 5)))

# expected: [ 5, None ]
