def make_account(balance, p):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return 'Insufficient funds'
    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance
    def dispatch(q, m):
        if p == q:
            return (withdraw if m == 'withdraw'
                    else deposit if m == 'deposit'
                    else 'unknown request -- make_account')
        else:
            return lambda q: 'Incorrect password'
    return dispatch

a = make_account(100, 'eva')
a('eva', 'withdraw')(50)  # withdraws 50
print(a('ben', 'withdraw')(40))  # incorrect password
peter_acc = make_account(100, 'open sesame')
peter_acc('open sesame', 'withdraw')(10)  # Withdraws 10
peter_acc('ben', 'withdraw')(40)  # Incorrect password

# Make Joint Account
paul_acc = make_joint(peter_acc, 'open sesame', 'rosebud')

print(paul_acc('rosebud', 'withdraw')(50))  # Withdraws 50, should return 40
