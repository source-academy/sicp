(define (make-queue) (cons '() '()))

; expected: null
