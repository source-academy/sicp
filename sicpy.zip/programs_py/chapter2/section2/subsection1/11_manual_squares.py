squares = llist(1, 4, 9, 16, 25)
