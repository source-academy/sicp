def is_even(n):
    return n % 2 == 0
def expmod(base, exp, m):
    if exp == 0:
        return 1
    elif is_even(exp):
        half_exp = expmod(base, exp // 2, m)
        return (half_exp * half_exp) % m
    else:
        return (base * expmod(base, exp - 1, m)) % m

print(expmod(4, 3, 5))

# expected: 4
