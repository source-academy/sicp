# cont_frac to be written by student; see exercise 1.37
print(cont_frac(lambda i: 1, lambda i: 1, 20))
