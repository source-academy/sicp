;; make-segment, start-segment, end-segment,
;; make-point, x-point, and y-point to be
;; written by student
