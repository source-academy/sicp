print(2.7 + 10)
