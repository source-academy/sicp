def make_leaf(symbol, weight):
    return llist("leaf", symbol, weight)
def is_leaf(object):
    return head(object) == "leaf"
def symbol_leaf(x): return head(tail(x))

def weight_leaf(x): return head(tail(tail(x)))
def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def symbols(tree):
    return (llist(symbol_leaf(tree))
            if is_leaf(tree)
            else head(tail(tail(tail(tree)))))
def weight(tree):
    return (weight_leaf(tree)
            if is_leaf(tree)
            else head(tail(tail(tail(tail(tree))))))
def adjoin_set(x, set):
    return (llist(x)
            if is_none(set)
            else pair(x, set)
            if weight(x) < weight(head(set))
            else pair(head(set), adjoin_set(x, tail(set))))

my_leaf_1 = make_leaf("A", 8)
my_leaf_2 = make_leaf("B", 3)

print(head(adjoin_set(my_leaf_1, adjoin_set(my_leaf_2, None))))

# expected: [ 'leaf', [ 'B', [ 3, None ] ] ]
