(entry
  (left-branch
    (right-branch
      (make-tree
        10
        'nil
        (make-tree
          30
          (make-tree 20 'nil 'nil)
          'nil)))))
