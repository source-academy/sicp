# solution provided by GitHub user LucasGdosR
def f(x):
    return (lambda is_even, is_odd: (is_even(is_even, is_odd, x))) (lambda is_ev, is_od, n: (True if n == 0 else is_od(is_ev, is_od, n - 1)), lambda is_ev, is_od, n: (False if n == 0 else is_ev(is_ev, is_od, n - 1)))
