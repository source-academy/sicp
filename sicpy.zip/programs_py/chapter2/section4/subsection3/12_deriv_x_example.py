print(deriv("x", "x"))
# 1
