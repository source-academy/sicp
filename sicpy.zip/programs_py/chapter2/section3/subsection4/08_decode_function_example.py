my_leaf_1 = make_leaf("A", 8)
my_leaf_2 = make_leaf("B", 3)

my_tree = make_code_tree(my_leaf_1, my_leaf_2)

print(tail(decode(llist(0, 1, 1, 0), my_tree)))
