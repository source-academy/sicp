(define (identity x) x)

(identity 42)
