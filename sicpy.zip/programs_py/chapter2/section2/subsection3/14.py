def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def times(x, y):
    return x * y
print(reduce(times, 1, llist(1, 2, 3, 4, 5)))

# expected: 120
