def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
print(length(triples_that_sum_to(10, 6)))
