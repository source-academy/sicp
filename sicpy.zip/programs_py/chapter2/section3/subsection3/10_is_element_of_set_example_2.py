print(is_element_of_set(15, llist(10, 15, 20)))
