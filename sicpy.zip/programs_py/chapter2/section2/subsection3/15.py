def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
print(tail(tail(accumulate(pair, None, llist(1, 2, 3, 4, 5)))))

# expected: [ 3, [ 4, [ 5, None ] ] ]
