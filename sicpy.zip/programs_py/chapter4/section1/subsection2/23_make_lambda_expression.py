def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_list(component, "name")
def make_lambda_expression(parameters, body):
    return llist("lambda_expression", parameters, body)

my_name_statement = parse("x;")
print(is_name(my_name_statement))
print(symbol_of_name(my_name_statement))
