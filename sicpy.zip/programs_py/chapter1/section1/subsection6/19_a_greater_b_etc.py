a = 3
b = a + 1
print((a if a > b else b if a < b else -1) * (a + 1))

# expected: 16
