def average(x, y):
    return (x + y) / 2
def improve(guess, x):
    return average(guess, x / guess)

print(improve(3, 25))
