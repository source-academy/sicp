pi = 3.14159
radius = 10
circumference = 2 * pi * radius
print(circumference)

# expected: 62.8318
