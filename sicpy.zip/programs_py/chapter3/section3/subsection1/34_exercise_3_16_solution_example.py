# return 3; return 4; return 7
print(count_pairs(three_list))
print(count_pairs(four_list))
print(count_pairs(seven_list))

# never return at all
print(count_pairs(cycle))
