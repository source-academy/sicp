def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)
tail(head(extend_environment(llist("x", "y", "z"),
                   llist(1, 2, 3),
                   the_empty_environment)))
