# tree_map to be written by student
def square_tree(tree): return tree_map(square, tree)
