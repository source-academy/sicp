def append(x, y):
    return (y if is_none(x)
            else pair(head(x), append(tail(x), y)))
def last_pair(x):
    return (x if is_none(tail(x))
            else last_pair(tail(x)))
def append_mutator(x, y):
    set_tail(last_pair(x), y)
    return x
x = llist("a", "b")
