def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
print(member("shoes", llist("red", "shoes", "blue", "socks")))
# ["shoes", ["blue", ["socks", None]]]

# expected: [ 'shoes', [ 'blue', [ 'socks', None ] ] ]
