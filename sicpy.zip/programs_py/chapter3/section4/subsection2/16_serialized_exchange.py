# chapter=3 variant=concurrent 
def make_mutex():
    cell = llist(False)
    def the_mutex(m):
        return ((the_mutex('acquire')  # retry
                     if test_and_set(cell)
                 else True)
                   if m == 'acquire'
                else clear(cell) if m == 'release'
                else error('unknown request -- mutex', m))
    return the_mutex

def clear(cell):
    set_head(cell, False)
def make_serializer():
    mutex = make_mutex()
    def serializer(f):
        def serialized_f():
            mutex('acquire')
            val = f()
            mutex('release')
            return val
        return serialized_f
    return serializer
def make_account_and_serializer(balance):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return 'Insufficient funds'
    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance
    balance_serializer = make_serializer()
    return lambda m: (withdraw if m == 'withdraw'
                      else deposit if m == 'deposit'
                      else balance if m == 'balance'
                      else balance_serializer if m == 'serializer'
                      else error('unknown request -- make_account', m))
def make_account(balance):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return 'Insufficient funds'
    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance
    protect = make_serializer()
    def dispatch(m):
        return (protect(withdraw) if m == 'withdraw'
                else protect(deposit) if m == 'deposit'
                else balance if m == 'balance'
                else error('unknown request -- make_account', m))
    return dispatch
def exchange(account1, account2):
    difference = account1('balance') - account2('balance')
    account1('withdraw')(difference)
    account2('deposit')(difference)
def serialized_exchange(account1, account2):
    serializer1 = account1('serializer')
    serializer2 = account2('serializer')
    serializer1(serializer2(exchange))(account1, account2)

a1 = make_account_and_serializer(100)
a2 = make_account_and_serializer(200)
a3 = make_account_and_serializer(300)

def peter():
    print('Peter balance a1 before', a1('balance'))
    print('Peter balance a2 before', a2('balance'))
    serialized_exchange(a1, a2)
    print('Peter balance a1 after', a1('balance'))
    print('Peter balance a2 after', a2('balance'))

def paul():
    print('Paul balance a1 before', a1('balance'))
    print('Paul balance a3 before', a3('balance'))
    serialized_exchange(a1, a3)
    print('Paul balance a1 after', a1('balance'))
    print('Paul balance a3 after', a3('balance'))

print(concurrent_execute(peter, paul))
