def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_pass_statement(component):
    return is_tagged_llist(component, 'pass_statement')
