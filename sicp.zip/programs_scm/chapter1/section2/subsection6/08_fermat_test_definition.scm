(define (square x) (* x x))
(define (even? n)
  (= (remainder n 2) 0))
(define (expmod base exp m)
  (cond ((= exp 0) 1)
        ((even? exp)
         (remainder 
           (square (expmod base (/ exp 2) m))
           m))
        (else
         (remainder 
           (* base (expmod base (- exp 1) m))
           m))))
;; random is predefined in Scheme
(define (fermat-test n)
  (define (try-it a)
    (= (expmod a n n) a))
  (try-it (+ 1 (random (- n 1)))))

(fermat-test 97)
