(append-to-form (a b) (c d) ?z)

; expected: 'append_to_form(list("a", "b"), list("c", "d"), list("a", "b", "c", "d"))'
