def square(x): return x * x
def is_even(n):
    return n % 2 == 0
def expmod(base, exp, m):
    return (1 if exp == 0
            else square(expmod(base, exp // 2, m)) % m if is_even(exp)
            else (base * expmod(base, exp - 1, m)) % m)
def random(n):
    return math_floor(random_random() * n)
def fermat_test(n):
    def try_it(a):
        return expmod(a, n, n) == a
    return try_it(1 + math_floor(random_random() * (n - 1)))
print(fermat_test(97))

# expected: true
