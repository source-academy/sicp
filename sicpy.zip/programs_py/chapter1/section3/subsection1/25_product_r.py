def factorial(n):
    def term(i):
        return i
    def next(i):
        return i + 1
    return product_r(term, 1, next, n)
# pi product
def pi(n):
    def is_odd(i):
        return i % 2 == 1
    def term(i):
        return (i + 1) / (i + 2) if is_odd(i) else (i + 2) / (i + 1)
    def next(i):
        return i + 1
    return 4 * (product_i(term, 1.0, next, n))
# recursive process
def product_r(term, a, next, b):
    return 1 if a > b else term(a) * product_r(term, next(a), next, b)

# iterative process
def product_i(term, a, next, b):
    def iterate(a, result):
        return result if a > b else iterate(next(a), term(a) * result)
    return iterate(a, 1)

print(factorial(5))
# pi(17)

# expected: 120
