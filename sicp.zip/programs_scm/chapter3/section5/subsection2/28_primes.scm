(define (square x) (* x x))
(define (divisible? x y) (= (remainder x y) 0))
(define (integers-starting-from n)
  (cons-stream n (integers-starting-from (+ n 1))))
(define primes
  (cons-stream
   2
   (stream-filter prime? (integers-starting-from 3))))

; expected: 233
