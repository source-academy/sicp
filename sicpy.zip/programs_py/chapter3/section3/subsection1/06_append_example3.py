def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
print(llist_ref(append(llist(1, 3), llist(5, 7, 9)), 4))

# expected: 9
