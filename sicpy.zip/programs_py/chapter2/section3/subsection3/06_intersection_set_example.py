def is_element_of_set(x, set):
    return (False
            if is_none(set)
            else True
            if x == head(set)
            else is_element_of_set(x, tail(set)))
def adjoin_set(x, set):
    return (set
            if is_element_of_set(x, set)
            else pair(x, set))
def intersection_set(set1, set2):
    return (None
            if is_none(set1) or is_none(set2)
            else pair(head(set1), intersection_set(tail(set1), set2))
            if is_element_of_set(head(set1), set2)
            else intersection_set(tail(set1), set2))
print(intersection_set(
   adjoin_set(10, adjoin_set(20, adjoin_set(30, None))),
   adjoin_set(10, adjoin_set(15, adjoin_set(20, None)))))
