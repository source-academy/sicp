;; random is predefined in Scheme
