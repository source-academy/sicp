(define (square x) (* x x))

(square 14)
