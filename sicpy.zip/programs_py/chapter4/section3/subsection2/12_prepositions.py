# chapter=3 variant=non-det 
prepositions = llist("prep", "for", "to", "in", "by", "with")
