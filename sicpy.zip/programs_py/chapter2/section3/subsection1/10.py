# function equal to be written by student
print(   llist("this", "is", "a", "list")
      == llist("this", llist("is", "a"), "linked", "list"))

# expected: False
