def f(g):
    return g(2)
print(f(lambda z: z * (z + 1)))
