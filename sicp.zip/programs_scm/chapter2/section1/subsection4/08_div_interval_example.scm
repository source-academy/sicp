(div-interval (make-interval 1 2) (make-interval 3 5))
