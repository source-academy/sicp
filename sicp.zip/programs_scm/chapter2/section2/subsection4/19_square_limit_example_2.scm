((square-limit rogers 4) full-frame)
