(append-to-form (a b) ?y (a b c d))

; expected: 'append_to_form(list("a", "b"), list("c", "d"), list("a", "b", "c", "d"))'
