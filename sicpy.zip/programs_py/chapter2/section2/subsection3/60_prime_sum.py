def square(x): return x * x
def smallest_divisor(n):
    return find_divisor(n, 2)

def find_divisor(n, test_divisor):
    return (n if square(test_divisor) > n
            else test_divisor if divides(test_divisor, n)
            else find_divisor(n, test_divisor + 1))

def divides(a, b):
    return b % a == 0
def is_prime(n):
    return n == smallest_divisor(n)
def is_prime_sum(pair):
    return is_prime(head(pair) + head(tail(pair)))

print(is_prime_sum(llist(8, 9)))

# expected: True
