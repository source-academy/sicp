def make_sum(a1, a2):
    return llist("+", a1, a2)
            
def make_product(m1, m2):
    return llist("*", m1, m2)
            
def addend(operands):
    return head(operands)
            
def augend(operands):
    return head(tail(operands))
            
def multiplier(operands):
    return head(operands)
            
def multiplicand(operands):
    return head(tail(operands))
