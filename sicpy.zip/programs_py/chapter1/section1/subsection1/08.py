print(1000 - 334)
