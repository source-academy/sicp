x = an_integer_starting_from(1)
require(x >= 4.5)
x
"""
