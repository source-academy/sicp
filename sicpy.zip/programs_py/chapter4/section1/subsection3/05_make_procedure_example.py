def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
my_function = make_function(llist('x', 'y'), parse('return x + y'), the_empty_environment)
print(is_compound_function(my_function))
print(function_body(my_function))
print(function_environment(my_function))
print(function_parameters(my_function))
