(define (integers-starting-from n)
  (cons-stream n (integers-starting-from (+ n 1))))
(define integers (integers-starting-from 1))
(pairs integers integers)

(pairs integers integers)

; expected: [ 1, [ 9, null ] ]
