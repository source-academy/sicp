def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
max_display = 9
def print_stream(s):
    def print_stream_iter(st, n):
        if is_none(st):
            pass
        elif n == 0:
            print('', '...')
        else:
            print(head(st))
            print_stream_iter(stream_tail(st), n - 1)
    print_stream_iter(s, max_display)

my_stream = pair(4, lambda: pair(5, lambda: None))
print_stream(my_stream)
