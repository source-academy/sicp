# square_tree to be written by student
# tree_map to be written by student

print(tail(tail(square_tree(llist(1,
                 llist(2, llist(3, 4), 5), 
                 llist(6, 7))))))
