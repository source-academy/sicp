print(square(14))
