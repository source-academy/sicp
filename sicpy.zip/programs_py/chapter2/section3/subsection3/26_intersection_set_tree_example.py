print(tree_to_linked_list_2(intersection_set_as_tree(
                      linked_list_to_tree(llist(1, 3, 5, 8)),
                      linked_list_to_tree(llist(2, 3, 6, 8)) ) ))
