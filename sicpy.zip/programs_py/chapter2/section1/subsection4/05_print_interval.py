# printing the interval in one line requires some string
# manipulation: str turns a number into a string
# and the operator + can be applied to strings for
# string concatenation
def print_interval(i):
    return ("[ "  + str(lower_bound(i)) +
            " , " + str(upper_bound(i)) + " ]")
