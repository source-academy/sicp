square = lambda x: x * x

print(square(14))

# expected: 196
