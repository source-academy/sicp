; chapter=3 variant=non-det 
(define prepositions '(prep for to in by with))
