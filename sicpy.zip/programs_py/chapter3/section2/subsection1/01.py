def square(x):
    return x * x

print(square(14))

# expected: 196
