def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
# solution provided by GitHub user LucasGdosR

# The Fibonacci function receives n as an argument
# It applies the fib function recursively, passing n as an argument,
# as well as the initial arguments (k = 1, fib1 = 1, fib2 = 1)
(lambda n: (lambda fib: fib(fib, n, 2, 1, 1))
      # The fib function is then defined as ft,
      # with parameters n, k, fib1, and fib2
      # Establish the base cases: n == 1 or n == 2
      (lambda ft, n, k, fib1, fib2:
                  1 if n == 1 else
                  1 if n == 2 else
                  # Iterate until k equals n. Notice k starts at 2, and gets incremented every iteration
                  # When k reaches n, return the accumulated fib2
                  fib2 if k == n else
                  # Otherwise, accumulate the sum as the new fib2
                  ft(ft, n, k + 1, fib2, fib1 + fib2)))
