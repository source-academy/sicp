# chapter=4 
coercion_list = None

def clear_coercion_list():
    global coercion_list
    coercion_list = None

def put_coercion(type1, type2, item):
    global coercion_list
    if is_none(get_coercion(type1, type2)):
        coercion_list = pair(llist(type1, type2, item),
                             coercion_list)
    else:
        return coercion_list

def get_coercion(type1, type2):
    def get_type1(list_item):
        return head(list_item)
    def get_type2(list_item):
        return head(tail(list_item))
    def get_item(list_item):
        return head(tail(tail(list_item)))
    def get_coercion_iter(items):
        if is_none(items):
            return None
        else:
            top = head(items)
            return (get_item(top)
                    if type1 == get_type1(top) and
                       type2 == get_type2(top)
                    else get_coercion_iter(tail(items)))
    return get_coercion_iter(coercion_list)
def python_number_to_complex(n):
    return make_complex_from_real_imag(contents(n), 0)
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
# In Source, most functions have a fixed number of arguments.
# (The function llist is the only exception, to this so far.)
# The function apply_in_underlying_javascript allows us to
# apply any given function fun to all elements of the argument
# linked list args, as if they were separate arguments
def apply(fun, args):
    return apply_in_underlying_javascript(fun, args)
def apply_generic(op, args):
    type_tags = map(type_tag, args)
    fun = get(op, type_tags)
    return (apply_in_underlying_javascript(fun, map(contents, args))
            if not is_none(fun)
            else error("no method for these types -- apply_generic",
                       llist(op, type_tags)))
def add(x, y): return apply_generic("add", llist(x, y))

def sub(x, y): return apply_generic("sub", llist(x, y))

def mul(x, y): return apply_generic("mul", llist(x, y))

def div(x, y): return apply_generic("div", llist(x, y))
def real_part(z): return apply_generic("real_part", llist(z))

def imag_part(z): return apply_generic("imag_part", llist(z))

def magnitude(z): return apply_generic("magnitude", llist(z))

def angle(z): return apply_generic("angle", llist(z))
# operation_table, put and get
# from chapter 3 (section 3.3.3)
def attach_tag(type_tag, contents):
    return pair(type_tag, contents)
def type_tag(datum):
    return (head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))
def square(x): return x * x
def install_rectangular_package():
    # internal functions
    def real_part(z): return head(z)
    def imag_part(z): return tail(z)
    def make_from_real_imag(x, y): return pair(x, y)
    def magnitude(z):
        return math_sqrt(square(real_part(z)) + square(imag_part(z)))
    def angle(z):
        return math_atan2(imag_part(z), real_part(z))
    def make_from_mag_ang(r, a):
        return pair(r * math_cos(a), r * math_sin(a))

    # interface to the rest of the system
    def tag(x): return attach_tag("rectangular", x)
    put("real_part", llist("rectangular"), real_part)
    put("imag_part", llist("rectangular"), imag_part)
    put("magnitude", llist("rectangular"), magnitude)
    put("angle", llist("rectangular"), angle)
    put("make_from_real_imag", "rectangular",
        lambda x, y: tag(make_from_real_imag(x, y)))
    put("make_from_mag_ang", "rectangular",
        lambda r, a: tag(make_from_mag_ang(r, a)))
    return "done"
print(install_rectangular_package())
def install_polar_package():
    # internal functions
    def magnitude(z): return head(z)
    def angle(z): return tail(z)
    def make_from_mag_ang(r, a): return pair(r, a)
    def real_part(z):
        return magnitude(z) * math_cos(angle(z))
    def imag_part(z):
        return magnitude(z) * math_sin(angle(z))
    def make_from_real_imag(x, y):
        return pair(math_sqrt(square(x) + square(y)),
                    math_atan2(y, x))

    # interface to the rest of the system
    def tag(x): return attach_tag("polar", x)
    put("real_part", llist("polar"), real_part)
    put("imag_part", llist("polar"), imag_part)
    put("magnitude", llist("polar"), magnitude)
    put("angle", llist("polar"), angle)
    put("make_from_real_imag", "polar",
        lambda x, y: tag(make_from_real_imag(x, y)))
    put("make_from_mag_ang", "polar",
        lambda r, a: tag(make_from_mag_ang(r, a)))
    return "done"
print(install_polar_package())
def install_complex_package():
    # imported functions from rectangular and polar packages
    def make_from_real_imag(x, y):
        return get("make_from_real_imag", "rectangular")(x, y)
    def make_from_mag_ang(r, a):
        return get("make_from_mag_ang", "polar")(r, a)
    # internal functions
    def add_complex(z1, z2):
        return make_from_real_imag(real_part(z1) + real_part(z2),
                                   imag_part(z1) + imag_part(z2))
    def sub_complex(z1, z2):
        return make_from_real_imag(real_part(z1) - real_part(z2),
                                   imag_part(z1) - imag_part(z2))
    def mul_complex(z1, z2):
        return make_from_mag_ang(magnitude(z1) * magnitude(z2),
                                 angle(z1) + angle(z2))
    def div_complex(z1, z2):
        return make_from_mag_ang(magnitude(z1) / magnitude(z2),
                                 angle(z1) - angle(z2))
    # interface to rest of the system
    def tag(z): return attach_tag("complex", z)
    put("add", llist("complex", "complex"),
        lambda z1, z2: tag(add_complex(z1, z2)))
    put("sub", llist("complex", "complex"),
        lambda z1, z2: tag(sub_complex(z1, z2)))
    put("mul", llist("complex", "complex"),
        lambda z1, z2: tag(mul_complex(z1, z2)))
    put("div", llist("complex", "complex"),
        lambda z1, z2: tag(div_complex(z1, z2)))
    put("make_from_real_imag", "complex",
        lambda x, y: tag(make_from_real_imag(x, y)))
    put("make_from_mag_ang", "complex",
        lambda r, a: tag(make_from_mag_ang(r, a)))
    return "done"
print(install_complex_package())
def make_complex_from_real_imag(x, y):
    return get("make_from_real_imag", "complex")(x, y)
def make_complex_from_mag_ang(r, a):
    return get("make_from_mag_ang", "complex")(r, a)
put_coercion("python_number", "complex",
             python_number_to_complex)

print(get_coercion("python_number", "complex"))
