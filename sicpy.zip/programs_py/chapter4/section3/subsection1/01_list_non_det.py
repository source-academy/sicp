# chapter=3 variant=non-det 
llist(amb(1, 2, 3), amb("a", "b"))
# Press "Run" for the first solution. Type
# retry
# in the REPL on the right, for more solutions
