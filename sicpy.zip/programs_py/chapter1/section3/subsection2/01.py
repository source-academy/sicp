lambda x: x + 4
