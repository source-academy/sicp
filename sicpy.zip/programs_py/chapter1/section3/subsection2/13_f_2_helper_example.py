print(f_2(3, 4))
