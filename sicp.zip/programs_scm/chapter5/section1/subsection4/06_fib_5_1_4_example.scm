(fib 6)
