;; for_each to be given by student


(for-each 
   (lambda (x) (newline) (display x))
   (list 57 321 88))

; expected: undefined
