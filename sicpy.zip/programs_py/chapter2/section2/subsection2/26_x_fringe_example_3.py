def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
x = llist(llist(1, 2), llist(3, 4))
# fringe to be written by student
print(length(fringe(llist(x, x))))
