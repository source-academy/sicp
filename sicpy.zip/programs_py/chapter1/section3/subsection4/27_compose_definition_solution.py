def inc(n):
    return n + 1
def square(x): return x * x
def compose(f, g):
    return lambda x: f(g(x))

print(compose(square, inc)(6))  # returns 49

# expected: 49
