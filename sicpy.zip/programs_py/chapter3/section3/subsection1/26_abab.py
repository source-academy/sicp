print(llist(llist("a", "b"), "a", "b"))

# expected: [ [ 'a', [ 'b', None ] ], [ 'a', [ 'b', None ] ] ]
