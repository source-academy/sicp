def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def make_pair_sum(pair):
    return llist(head(pair), head(tail(pair)),
                 head(pair) + head(tail(pair)))
def square(x): return x * x
def smallest_divisor(n):
    return find_divisor(n, 2)

def find_divisor(n, test_divisor):
    return (n if square(test_divisor) > n
            else test_divisor if divides(test_divisor, n)
            else find_divisor(n, test_divisor + 1))

def divides(a, b):
    return b % a == 0
def is_prime(n):
    return n == smallest_divisor(n)
def is_prime_sum(pair):
    return is_prime(head(pair) + head(tail(pair)))
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def flatmap(f, seq):
    return reduce(append, None, map(f, seq))
def enumerate_interval(low, high):
    return (None if low > high
            else pair(low,
                      enumerate_interval(low + 1, high)))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def prime_sum_pairs(n):
    return map(make_pair_sum,
               filter(is_prime_sum,
                  flatmap(lambda i: map(lambda j: llist(i, j),
                                        enumerate_interval(1, i - 1)),
                          enumerate_interval(1, n))))

print(length(prime_sum_pairs(6)))

# expected: 7
