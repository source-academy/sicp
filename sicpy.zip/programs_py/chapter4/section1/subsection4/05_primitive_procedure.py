def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_primitive_function(fun):
    return is_tagged_list(fun, "primitive")

def primitive_implementation(fun):
    return head(tail(fun))

my_primitive_plus = llist("primitive", lambda x, y: (x + y))
primitive_implementation(my_primitive_plus)
is_primitive_function(my_primitive_plus)

# expected: true
