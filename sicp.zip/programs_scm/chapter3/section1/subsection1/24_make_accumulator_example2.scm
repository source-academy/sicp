(define A (make-accumulator 5))
(A 10)
(A 10)
