(define z2 (cons (list 'a 'b) (list 'a 'b)))
