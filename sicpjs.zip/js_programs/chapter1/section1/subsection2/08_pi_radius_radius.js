const pi = 3.14159;
const radius = 10;
pi * radius * radius;

// expected: 314.159
