def attach_tag(type_tag, contents):
    return pair(type_tag, contents)
def type_tag(datum):
    return (head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))
def is_rectangular(z):
    return type_tag(z) == "rectangular"
def is_polar(z):
    return type_tag(z) == "polar"
def square(x): return x * x
def real_part_rectangular(z): return head(z)

def imag_part_rectangular(z): return tail(z)

def magnitude_rectangular(z):
    return math_sqrt(square(real_part_rectangular(z)) +
                     square(imag_part_rectangular(z)))
def angle_rectangular(z):
    return math_atan2(imag_part_rectangular(z),
                      real_part_rectangular(z))
def make_from_real_imag_rectangular(x, y):
    return attach_tag("rectangular", pair(x, y))
def make_from_mag_ang_rectangular(r, a):
    return attach_tag("rectangular",
                      pair(r * math_cos(a), r * math_sin(a)))
def real_part_polar(z):
    return magnitude_polar(z) * math_cos(angle_polar(z))
def imag_part_polar(z):
    return magnitude_polar(z) * math_sin(angle_polar(z))
def magnitude_polar(z): return head(z)

def angle_polar(z): return tail(z)

def make_from_real_imag_polar(x, y):
    return attach_tag("polar",
                      pair(math_sqrt(square(x) + square(y)),
                           math_atan2(y, x)))

def make_from_mag_ang_polar(r, a):
    return attach_tag("polar", pair(r, a))
def real_part(z):
    return (real_part_rectangular(contents(z))
            if is_rectangular(z)
            else real_part_polar(contents(z))
            if is_polar(z)
            else error("unknown type -- real_part", z))
def imag_part(z):
    return (imag_part_rectangular(contents(z))
            if is_rectangular(z)
            else imag_part_polar(contents(z))
            if is_polar(z)
            else error("unknown type -- imag_part", z))
def magnitude(z):
    return (magnitude_rectangular(contents(z))
            if is_rectangular(z)
            else magnitude_polar(contents(z))
            if is_polar(z)
            else error("unknown type -- magnitude", z))
def angle(z):
    return (angle_rectangular(contents(z))
            if is_rectangular(z)
            else angle_polar(contents(z))
            if is_polar(z)
            else error("unknown type -- angle", z))

alyssas_co_num = make_from_mag_ang_polar(3.0, 0.7)

print(imag_part(alyssas_co_num))

# expected: 1.932653061713073
