(define a 3)
(define b (+ a 1))
(= a b)

; expected: false
