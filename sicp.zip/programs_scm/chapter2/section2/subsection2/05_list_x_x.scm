(define x (cons (list 1 2) (list 3 4)))
(list x x)

; expected: 3
