def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)
def extend_environment(symbols, vals, base_env):
    return pair(make_frame(symbols, vals), base_env) if length(symbols) == length(vals) else error("too many arguments supplied: " + stringify(symbols) + ", " + stringify(vals)) if length(symbols) < length(vals) else error("too few arguments supplied: " + stringify(symbols) + ", " + stringify(vals))

tail(head(extend_environment(llist("x", "y", "z"),
                   llist(1, 2, 3),
                   the_empty_environment)))

# expected: [ 1, [ 2, [ 3, null ] ] ]
