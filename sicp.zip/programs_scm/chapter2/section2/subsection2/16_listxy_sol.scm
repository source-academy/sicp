(define x (list 1 2 3))

(define y (list 4 5 6))
(list x y)


; expected: [ 4, [ 5, [ 6, null ] ] ]
