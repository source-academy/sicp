def make_decrementer(balance):
    return lambda amount: balance - amount
D = make_decrementer(25)
print(D(20))

# expected: 5
