odds = llist(1, 3, 5, 7)
