def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_return_value(content):
    return llist("return_value", content)
def is_return_value(value):
    return is_tagged_list(value, "return_value")
def return_value_content(value):
    return head(tail(value))

my_return_value = make_return_value(42)
is_return_value(my_return_value)
return _value_content(my_return_value)

# expected: 42
