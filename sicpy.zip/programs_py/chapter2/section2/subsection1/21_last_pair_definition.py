# last_pair to be given by student
def last_pair(items):
    return (items if is_none(tail(items))
            else last_pair(tail(items)))

print_llist(last_pair(llist(23, 72, 149, 34)))

# expected: llist(34)
