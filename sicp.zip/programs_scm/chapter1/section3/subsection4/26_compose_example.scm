;; compose to be written by student; see EXERCISE 1.42
(define (square x) (* x x))
(define (inc n) (+ n 1))
((compose square inc) 6)
