def plus_curried(x):
    return lambda y: x + y

print(plus_curried(3)(4))

# expected: 7
