def eval_function_definition(component, env):
    parameters = function_definition_parameter_symbols(component)
    body = function_definition_body(component)
    fun = make_function(parameters,
                        local_variables(parameters, body),
                        global_variables(body),
                        body,
                        env)
    assign_symbol_value(function_definition_symbol(component), fun, env)
    return None
