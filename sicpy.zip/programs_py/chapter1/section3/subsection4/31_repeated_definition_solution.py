def compose(f, g):
    return lambda x: f(g(x))
def square(x): return x * x
def repeated(f, n):
    return (lambda x: x) if n == 0 else compose(f, repeated(f, n - 1))

print(repeated(square, 2)(5))  # 625

# expected: 625
