def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
the_global_environment = setup_environment()
ref(head(head(the_global_environment)), 12)
