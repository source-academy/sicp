def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_sequence(stmt):
    return is_tagged_llist(stmt, 'sequence')
def sequence_statements(stmt):
    return head(tail(stmt))
def first_statement(stmts):
    return head(stmts)
def rest_statements(stmts):
    return tail(stmts)
def is_empty_sequence(stmts):
    return is_none(stmts)
def is_last_statement(stmts):
    return is_none(tail(stmts))

my_sequence = parse('1\nTrue\n45')
print(is_sequence(my_sequence))
my_actions = sequence_statements(my_sequence)
print(is_empty_sequence(my_actions))
print(is_last_statement(my_actions))
print(first_statement(my_actions))
print(rest_statements(my_actions))
print(llist_ref(rest_statements(my_actions), 1))

# expected: [ 'literal', [ 45, None ] ]
