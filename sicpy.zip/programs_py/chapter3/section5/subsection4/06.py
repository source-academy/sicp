def stream_tail(stream):
    return tail(stream)()
def integral(integrand, initial_value, dt):
    return pair(initial_value,
                None if is_none(integrand)
                else integral(stream_tail(integrand),
                              dt * head(integrand) + initial_value,
                              dt))
