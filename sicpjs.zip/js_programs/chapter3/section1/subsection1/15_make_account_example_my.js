const acc = make_account(100);

acc("withdraw")(50);
