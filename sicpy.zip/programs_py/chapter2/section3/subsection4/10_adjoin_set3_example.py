my_leaf_1 = make_leaf("A", 8)
my_leaf_2 = make_leaf("B", 3)

print(head(adjoin_set(my_leaf_1, adjoin_set(my_leaf_2, None))))
