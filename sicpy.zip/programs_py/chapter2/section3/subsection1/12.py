llist(llist("george"))
