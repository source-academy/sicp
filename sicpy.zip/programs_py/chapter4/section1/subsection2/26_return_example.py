def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
my_function_definition = parse('def f(x):\n    return x')
my_return = llist_ref(my_function_definition, 3)
print(llist_ref(my_return, 1))
