def is_element_of_set(x, set):
    return (False
            if is_none(set)
            else True
            if x == head(set)
            else is_element_of_set(x, tail(set)))
def adjoin_set(x, set):
    return (set
            if is_element_of_set(x, set)
            else pair(x, set))

print(adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))

# expected: [ 10, [ 15, [ 20, None ] ] ]
