(define (user-print object)
  (if (compound-procedure? object)
      (display (list 'compound-procedure
                     (procedure-parameters object)
                     (procedure-body object)
                     '<-procedure-env->))
      (display object)))
(define input-prompt ";;; M-Eval input:\n")
(define output-prompt ";;; M-Eval value:\n")

(define (driver-loop)
  (prompt-for-input input-prompt)
  (let ((input (read)))
    (if (null? input)
      'EVALUATOR-TERMINATED
      (let ((output (eval input the-global-environment)))
        (announce-output output-prompt)
        (user-print output)
        (driver-loop)))))

(define (prompt-for-input string)
  (newline) (display string))

(define (announce-output string)
  (newline) (display string))
(define the-global-environment (setup-environment))
(driver-loop)
(define (append x y)
   (if (null? x)
       y
       (cons (car x)
         (append (cdr x) y))))
