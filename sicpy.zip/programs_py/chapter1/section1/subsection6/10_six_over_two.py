print(6 / 2)

# expected: 3.0
