def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def horner_eval(x, coefficient_sequence):
    return reduce(lambda this_coeff, higher_terms: ,
                  0,
                  coefficient_sequence)
print(horner_eval(2, llist(1, 3, 0, 5, 0, 1)))
