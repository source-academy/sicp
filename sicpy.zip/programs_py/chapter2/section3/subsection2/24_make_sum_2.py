def number_equal(exp, num):
    return is_number(exp) and exp == num
def make_sum(a1, a2):
    return (a2
            if number_equal(a1, 0)
            else a1
            if number_equal(a2, 0)
            else a1 + a2
            if is_number(a1) and is_number(a2)
            else llist("+", a1, a2))

print(make_sum(2, 3))

# expected: 5
