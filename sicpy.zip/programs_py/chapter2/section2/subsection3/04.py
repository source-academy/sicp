def is_even(n):
    return n % 2 == 0
def fib(n):
    return (0 if n == 0
            else 1 if n == 1
            else fib(n - 1) + fib(n - 2))
def even_fibs(n):
    def next(k):
        if k > n:
            return None
        else:
            f = fib(k)
            return (pair(f, next(k + 1)) if is_even(f)
                    else next(k + 1))
    return next(0)

print(tail(even_fibs(9)))

# expected: [ 2, [ 8, [ 34, None ] ] ]
