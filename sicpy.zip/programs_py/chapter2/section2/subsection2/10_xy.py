x = llist(1, 2, 3)

y = llist(4, 5, 6)
