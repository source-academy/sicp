v = llist("a", "b", "c", "d")
