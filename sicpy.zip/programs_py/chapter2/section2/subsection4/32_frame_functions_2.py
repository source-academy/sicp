def make_vect(x, y):
    return pair(x, y)
def xcor_vect(vector):
    return head(vector)
def ycor_vect(vector):
    return tail(vector)
def scale_vect(factor, vector):
    return make_vect(factor * xcor_vect(vector), 
                     factor * ycor_vect(vector))
def add_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     + xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     + ycor_vect(vector2))
def sub_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     - xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     - ycor_vect(vector2))
def make_frame(origin, edge1, edge2):
    return pair(origin, pair(edge1, edge2))
def origin_frame(frame):
    return head(frame)
def edge1_frame(frame):
    return head(tail(frame))
def edge2_frame(frame):
    return tail(tail(frame))

my_origin = make_vect(1, 2)
my_edge_1 = make_vect(3, 4)
my_edge_2 = make_vect(5, 6)
my_frame = make_frame(my_origin, my_edge_1, my_edge_2)
print(edge2_frame(my_frame))

# expected: [ 5, 6 ]
