def make_record(key, data):
    return pair(key, data)
def key(record):
    return head(record)
def data(record):
    return tail(record)
