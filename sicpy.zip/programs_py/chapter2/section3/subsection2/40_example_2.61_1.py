print(deriv(llist("x", "*", 4), "x"))
