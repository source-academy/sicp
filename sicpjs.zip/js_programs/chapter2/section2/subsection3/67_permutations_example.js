length(permutations(list(1, 2, 3)));
