# functions from SICP Python 4.1.1
def evaluate(component, env):
    if is_literal(component):
        return literal_value(component)
    elif is_name(component):
        return lookup_symbol_value(symbol_of_name(component), env)
    elif is_application(component):
        return apply(evaluate(function_expression(component), env),
                     llist_of_values(arg_expressions(component), env))
    elif is_operator_combination(component):
        return evaluate(operator_combination_to_application(component),
                        env)
    elif is_conditional(component):
        return eval_conditional(component, env)
    elif is_lambda_expression(component):
        return make_function(lambda_parameter_symbols(component),
                             None,
                             None,
                             make_return_statement(lambda_body(component)),
                             env)
    elif is_sequence(component):
        return eval_sequence(sequence_statements(component), env)
    elif is_return_statement(component):
        return eval_return_statement(component, env)
    elif is_function_definition(component):
        return eval_function_definition(component, env)
    elif (is_pass_statement(component) or
          is_global_statement(component) or
          is_nonlocal_statement(component)):
        return None
    elif is_assignment(component):
        return eval_assignment(component, env)
    else:
        return error('unknown syntax -- evaluate', component)
def apply(fun, arguments):
    if is_built_in_function(fun):
        return apply_built_in_function(fun, arguments)
    elif is_compound_function(fun):
        locals = function_locals(fun)
        globals = function_globals(fun)
        unassigned_markers = map(lambda symbol: '*unassigned*', locals)
        global_markers = map(lambda symbol: '*global*', globals)
        result = evaluate(function_body(fun),
                          extend_environment(
                              append(function_parameters(fun),
                                     append(locals, globals)),
                              append(arguments,
                                     append(unassigned_markers,
                                            global_markers)),
                              function_environment(fun)))
        if is_return_value(result):
            return return_value_content(result)
        else:
            return None
    else:
        return error('unknown function type -- apply', fun)
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def llist_of_values(exps, env):
    return map(lambda arg: evaluate(arg, env), exps)
def eval_conditional(component, env):
    if is_truthy(evaluate(conditional_predicate(component), env)):
        return evaluate(conditional_consequent(component), env)
    else:
        return evaluate(conditional_alternative(component), env)
def eval_sequence(stmts, env):
    if is_empty_sequence(stmts):
        return None
    elif is_last_statement(stmts):
        return evaluate(first_statement(stmts), env)
    else:
        first_stmt_value = evaluate(first_statement(stmts), env)
        if is_return_value(first_stmt_value):
            return first_stmt_value
        else:
            return eval_sequence(rest_statements(stmts), env)
def eval_return_statement(component, env):
    return make_return_value(evaluate(return_expression(component),
                                      env))
def eval_assignment(component, env):
    value = evaluate(assignment_value_expression(component), env)
    assign_symbol_value(assignment_symbol(component), value, env)
    return None
def eval_function_definition(component, env):
    parameters = function_definition_parameter_symbols(component)
    body = function_definition_body(component)
    fun = make_function(parameters,
                        local_variables(parameters, body),
                        global_variables(body),
                        body,
                        env)
    assign_symbol_value(function_definition_symbol(component), fun, env)
    return None
def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_llist(component, 'name')
def symbol_of_name(component):
    return head(tail(component))
def is_global_statement(component):
    return is_tagged_llist(component, 'global_statement')
def is_nonlocal_statement(component):
    return is_tagged_llist(component, 'nonlocal_statement')
def declaration_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def is_assignment(component):
    return is_tagged_llist(component, 'assignment')
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_function_definition(component):
    return is_tagged_llist(component, 'function_definition')
def function_definition_name(component):
    return llist_ref(component, 1)
def function_definition_symbol(component):
    return symbol_of_name(function_definition_name(component))
def function_definition_parameters(component):
    return llist_ref(component, 2)
def function_definition_parameter_symbols(component):
    return map(symbol_of_name, function_definition_parameters(component))
def function_definition_body(component):
    return llist_ref(component, 3)
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
def declared_symbols(component, is_declaration):
    if is_sequence(component):
        return reduce(append,
                      None,
                      map(lambda statement: declared_symbols(statement,
                                                             is_declaration),
                          sequence_statements(component)))
    elif is_conditional(component):
        return append(declared_symbols(conditional_consequent(component),
                                       is_declaration),
                      declared_symbols(conditional_alternative(component),
                                       is_declaration))
    elif is_declaration(component):
        return target_symbols(component)
    else:
        return None
def target_symbols(component):
    if is_assignment(component):
        return llist(assignment_symbol(component))
    elif is_function_definition(component):
        return llist(function_definition_symbol(component))
    else:
        return declaration_symbols(component)
def global_variables(component):
    return declared_symbols(component, is_global_statement)
def nonlocal_variables(component):
    return declared_symbols(component, is_nonlocal_statement)
def assigned_variables(component):
    return declared_symbols(
        component,
        lambda statement: (is_assignment(statement) or
                           is_function_definition(statement)))
def local_variables(parameters, body):
    excluded = append(parameters,
                      append(global_variables(body), nonlocal_variables(body)))
    return filter(lambda symbol: is_none(member(symbol, excluded)),
                  assigned_variables(body))

