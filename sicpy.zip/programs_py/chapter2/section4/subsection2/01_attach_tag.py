def attach_tag(type_tag, contents):
    return pair(type_tag, contents)
def type_tag(datum):
    return (head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))

f_1 = llist("A", 4)
my_frequency_1 = attach_tag("frequency_list", f_1)

print(type_tag(my_frequency_1))

# expected: 'frequency_list'
