import { heart, stack, beside, show } from 'rune';

def up_split(painter, n):
    if n == 0:
        return painter
    else:
        smaller = up_split(painter, n - 1)
        return stack(beside(smaller, smaller), painter)

print(show(up_split(heart, 4)))
