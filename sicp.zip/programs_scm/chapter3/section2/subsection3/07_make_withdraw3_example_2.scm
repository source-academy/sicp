(define (make-withdraw initial-amount)
  (let ((balance initial-amount))
        (lambda (amount)
    (if (>= balance amount)
        (begin (set! balance (- balance amount))
               balance)
        "Insufficient funds"))))
(define W1 (make-withdraw 100))

(W1 50)

(define W2 (make-withdraw 100))

; expected: 20
