def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_llist(component, 'name')
def symbol_of_name(component):
    return head(tail(component))
def is_global_statement(component):
    return is_tagged_llist(component, 'global_statement')
def is_nonlocal_statement(component):
    return is_tagged_llist(component, 'nonlocal_statement')
def declaration_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def is_assignment(component):
    return is_tagged_llist(component, 'assignment')
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_function_definition(component):
    return is_tagged_llist(component, 'function_definition')
def function_definition_name(component):
    return llist_ref(component, 1)
def function_definition_symbol(component):
    return symbol_of_name(function_definition_name(component))
def function_definition_parameters(component):
    return llist_ref(component, 2)
def function_definition_parameter_symbols(component):
    return map(symbol_of_name, function_definition_parameters(component))
def function_definition_body(component):
    return llist_ref(component, 3)
def declared_symbols(component, is_declaration):
    if is_sequence(component):
        return reduce(append,
                      None,
                      map(lambda statement: declared_symbols(statement,
                                                             is_declaration),
                          sequence_statements(component)))
    elif is_conditional(component):
        return append(declared_symbols(conditional_consequent(component),
                                       is_declaration),
                      declared_symbols(conditional_alternative(component),
                                       is_declaration))
    elif is_declaration(component):
        return target_symbols(component)
    else:
        return None
def target_symbols(component):
    if is_assignment(component):
        return llist(assignment_symbol(component))
    elif is_function_definition(component):
        return llist(function_definition_symbol(component))
    else:
        return declaration_symbols(component)
def global_variables(component):
    return declared_symbols(component, is_global_statement)
def nonlocal_variables(component):
    return declared_symbols(component, is_nonlocal_statement)
def assigned_variables(component):
    return declared_symbols(
        component,
        lambda statement: (is_assignment(statement) or
                           is_function_definition(statement)))
def analyze_function_body(params, body):
    bfun = analyze(body)
    globals = global_variables(body)
    others = append(params, append(globals, nonlocal_variables(body)))
    locals = filter(lambda symbol: is_none(member(symbol, others)),
                    assigned_variables(body))
    def the_body(env, succeed, fail):
        add_bindings_to_frame(locals, '*unassigned*', first_frame(env))
        add_bindings_to_frame(globals, '*global*', first_frame(env))
        return bfun(env, succeed, fail)
    return the_body
def add_bindings_to_frame(symbols, val, frame):
    if is_none(symbols):
        return None
    else:
        add_binding_to_frame(head(symbols), val, frame)
        return add_bindings_to_frame(tail(symbols), val, frame)
def analyze_function_definition(component):
    symbol = function_definition_symbol(component)
    params = function_definition_parameter_symbols(component)
    bfun = analyze_function_body(params, function_definition_body(component))
    def the_function_definition(env, succeed, fail):
        fun = make_function(params, bfun, env)
        assign_symbol_value(symbol, fun, env)
        return succeed(None, fail)
    return the_function_definition
# functions from SICP JS 4.1.2
def is_literal(component):
    return is_tagged_llist(component, 'literal')
def literal_value(component):
    return head(tail(component))
def make_literal(value):
    return llist('literal', value)
def make_name(symbol):
    return llist('name', symbol)
def is_lambda_expression(component):
    return is_tagged_llist(component, 'lambda_expression')
def lambda_parameter_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def lambda_body(component):
    return head(tail(tail(component)))
def is_return_statement(component):
    return is_tagged_llist(component, 'return_statement')
def return_expression(component):
    return head(tail(component))
def make_return_statement(expression):
    return llist('return_statement', expression)
def is_pass_statement(component):
    return is_tagged_llist(component, 'pass_statement')
def is_conditional(component):
    return (is_tagged_llist(component, 'conditional_expression') or
            is_tagged_llist(component, 'conditional_statement'))
def conditional_predicate(component):
    return llist_ref(component, 1)
def conditional_consequent(component):
    return llist_ref(component, 2)
def conditional_alternative(component):
    return llist_ref(component, 3)
def is_sequence(stmt):
    return is_tagged_llist(stmt, 'sequence')
def sequence_statements(stmt):
    return head(tail(stmt))
def first_statement(stmts):
    return head(stmts)
def rest_statements(stmts):
    return tail(stmts)
def is_empty_sequence(stmts):
    return is_none(stmts)
def is_last_statement(stmts):
    return is_none(tail(stmts))
def is_operator_combination(component):
    return is_unary_operator_combination(component) or is_binary_operator_combination(component)
def is_unary_operator_combination(component):
    return is_tagged_llist(component, 'unary_operator_combination')
def is_binary_operator_combination(component):
    return is_tagged_llist(component, 'binary_operator_combination')
def operator_symbol(component):
    return llist_ref(component, 1)
def first_operand(component):
    return llist_ref(component, 2)
def second_operand(component):
    return llist_ref(component, 3)
def make_application(function_expression, argument_expressions):
    return llist('application', function_expression, argument_expressions)
def operator_combination_to_application(component):
    operator = operator_symbol(component)
    if is_unary_operator_combination(component):
        return make_application(make_name(operator),
                                llist(first_operand(component)))
    else:
        return make_application(make_name(operator),
                                llist(first_operand(component),
                                      second_operand(component)))
def is_application(component):
    return is_tagged_llist(component, 'application')
def function_expression(component):
    return head(tail(component))
def arg_expressions(component):
    return head(tail(tail(component)))

# functions from SICP Python 4.1.3
def is_truthy(x):
    if is_boolean(x):
        return x
    else:
        error('boolean expected, received', x)
def is_falsy(x):
    return not is_truthy(x)
def make_function(parameters, body, env):
    return llist('compound_function', parameters, body, env)
def is_compound_function(f):
    return is_tagged_llist(f, 'compound_function')
def function_parameters(f):
    return llist_ref(f, 1)

def function_body(f):
    return llist_ref(f, 2)

def function_environment(f):
    return llist_ref(f, 3)
def make_return_value(content):
    return llist('return_value', content)
def is_return_value(value):
    return is_tagged_llist(value, 'return_value')
def return_value_content(value):
    return head(tail(value))
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

def add_binding_to_frame(symbol, val, frame):
    set_head(frame, pair(symbol, head(frame)))
    set_tail(frame, pair(val, tail(frame)))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def extend_environment(symbols, vals, base_env):
    if length(symbols) == length(vals):
        return pair(make_frame(symbols, vals), base_env)
    elif length(symbols) < length(vals):
        error('too many arguments supplied', pair(symbols, vals))
    else:
        error('too few arguments supplied', pair(symbols, vals))
built_in_constants = llist(llist('math_pi', math_pi), llist('math_e', math_e))
built_in_constant_symbols = map(lambda c: head(c), built_in_constants)
built_in_constant_values = map(lambda c: head(tail(c)), built_in_constants)
def is_built_in_function(fun):
    return is_tagged_llist(fun, 'built_in')

def built_in_implementation(fun):
    return head(tail(fun))
def print_without_environments(*objects):
    def prepare(object):
        if is_compound_function(object):
            return '<compound-function>'
        elif is_built_in_function(object):
            return '<built-in-function>'
        elif is_pair(object):
            return pair(prepare(head(object)), prepare(tail(object)))
        else:
            return object
    return apply_in_underlying_python(print,
                                      map(prepare, llist(*objects)))
built_in_functions = llist(llist('head', head), llist('tail', tail), llist('pair', pair), llist('is_none', is_none), llist('llist', llist), llist('print', print_without_environments), llist('error', error), llist('abs', abs), llist('+', lambda x, y: x + y), llist('-', lambda x, y: x - y), llist('*', lambda x, y: x * y), llist('/', lambda x, y: x / y), llist('//', lambda x, y: x // y), llist('%', lambda x, y: x % y), llist('**', lambda x, y: x ** y), llist('==', lambda x, y: x == y), llist('!=', lambda x, y: x != y), llist('<', lambda x, y: x < y), llist('<=', lambda x, y: x <= y), llist('>', lambda x, y: x > y), llist('>=', lambda x, y: x >= y), llist('is', lambda x, y: x is y), llist('is not', lambda x, y: x is not y), llist('not', lambda x: not x), llist('-unary', lambda x: -x), llist('+unary', lambda x: +x))
built_in_function_symbols = map(head, built_in_functions)
built_in_function_objects = map(lambda fun: llist('built_in', head(tail(fun))), built_in_functions)
def setup_environment():
    built_in_environment = extend_environment(
        append(built_in_function_symbols, built_in_constant_symbols),
        append(built_in_function_objects, built_in_constant_values),
        the_empty_environment)
    return extend_environment(None, None, built_in_environment)
the_global_environment = setup_environment()
def lookup_symbol_value(symbol, env):
    def env_loop(env):
        def scan(symbols, vals):
            if is_none(symbols):
                return env_loop(enclosing_environment(env))
            elif symbol == head(symbols):
                if head(vals) == '*global*':
                    return lookup_symbol_value(symbol, the_global_environment)
                else:
                    return head(vals)
            else:
                return scan(tail(symbols), tail(vals))
        if env is the_empty_environment:
            error('unbound name', symbol)
        else:
            frame = first_frame(env)
            return scan(frame_symbols(frame), frame_values(frame))
    return env_loop(env)
def assign_symbol_value(symbol, val, env):
    def scan(symbols, vals):
        if is_none(symbols):
            if env is the_global_environment:
                add_binding_to_frame(symbol, val, first_frame(env))
            else:
                assign_symbol_value(symbol, val, enclosing_environment(env))
        elif symbol == head(symbols):
            if head(vals) == '*global*':
                assign_symbol_value(symbol, val, the_global_environment)
            else:
                set_head(vals, val)
        else:
            scan(tail(symbols), tail(vals))
    frame = first_frame(env)
    scan(frame_symbols(frame), frame_values(frame))

# functions from SICP Python 4.1.4
def apply_built_in_function(fun, arg_llist):
    return apply_in_underlying_python(built_in_implementation(fun), arg_llist)

# functions from SICP Python 4.3.3
def is_amb(component):
    return (is_application(component) and
            is_name(function_expression(component)) and
            symbol_of_name(function_expression(component)) == 'amb')
def amb_choices(component):
    return arg_expressions(component)
def analyze_literal(component):
    return lambda env, succeed, fail: succeed(literal_value(component), fail)
def analyze_name(component):
    symbol = symbol_of_name(component)
    return lambda env, succeed, fail: succeed(lookup_symbol_value(symbol, env),
                                              fail)
def analyze_lambda_expression(component):
    params = lambda_parameter_symbols(component)
    bfun = analyze_function_body(params,
                                 make_return_statement(lambda_body(component)))
    return lambda env, succeed, fail: succeed(make_function(params, bfun, env),
                                              fail)
def analyze_sequence(stmts):
    def sequentially(a, b):
        def the_sequence(env, succeed, fail):
            def a_succeed(a_value, fail2):
                if is_return_value(a_value):
                    return succeed(a_value, fail2)
                else:
                    return b(env, succeed, fail2)
            return a(env, a_succeed, fail)
        return the_sequence
    def loop(first_fun, rest_funs):
        if is_none(rest_funs):
            return first_fun
        else:
            return loop(sequentially(first_fun, head(rest_funs)),
                        tail(rest_funs))
    funs = map(analyze, stmts)
    if is_none(funs):
        return lambda env, succeed, fail: succeed(None, fail)
    else:
        return loop(head(funs), tail(funs))
def is_bound(symbol, env):
    def scan(symbols, vals):
        if is_none(symbols):
            return is_bound(symbol, enclosing_environment(env))
        elif symbol == head(symbols):
            if head(vals) == '*global*':
                return is_bound(symbol, the_global_environment)
            else:
                return True
        else:
            return scan(tail(symbols), tail(vals))
    if env is the_empty_environment:
        return False
    else:
        frame = first_frame(env)
        return scan(frame_symbols(frame), frame_values(frame))
def analyze_assignment(component):
    symbol = assignment_symbol(component)
    vfun = analyze(assignment_value_expression(component))
    def the_assignment(env, succeed, fail):
        def success(val, fail2):              # *1*
            if is_bound(symbol, env):
                old_value = lookup_symbol_value(symbol, env)
                assign_symbol_value(symbol, val, env)
                def restore():                # *2*
                    assign_symbol_value(symbol, old_value, env)
                    return fail2()
                return succeed(val, restore)
            else:
                assign_symbol_value(symbol, val, env)
                return succeed(val, fail2)
        return vfun(env, success, fail)
    return the_assignment
def analyze_conditional(component):
    pfun = analyze(conditional_predicate(component))
    cfun = analyze(conditional_consequent(component))
    afun = analyze(conditional_alternative(component))
    def the_conditional(env, succeed, fail):
        def pred_succeed(pred_value, fail2):
            if is_truthy(pred_value):
                return cfun(env, succeed, fail2)
            else:
                return afun(env, succeed, fail2)
        return pfun(env, pred_succeed, fail)
    return the_conditional
def analyze_return_statement(component):
    rfun = analyze(return_expression(component))
    def the_return_statement(env, succeed, fail):
        def val_succeed(val, fail2):
            return succeed(make_return_value(val), fail2)
        return rfun(env, val_succeed, fail)
    return the_return_statement
def get_args(afuns, env, succeed, fail):
    if is_none(afuns):
        return succeed(None, fail)
    else:
        def arg_succeed(arg, fail2):
            def args_succeed(args, fail3):
                return succeed(pair(arg, args), fail3)
            return get_args(tail(afuns), env, args_succeed, fail2)
        return head(afuns)(env, arg_succeed, fail)
def execute_application(fun, args, succeed, fail):
    if is_built_in_function(fun):
        return succeed(apply_built_in_function(fun, args), fail)
    elif is_compound_function(fun):
        def body_succeed(body_result, fail2):
            if is_return_value(body_result):
                return succeed(return_value_content(body_result), fail2)
            else:
                return succeed(None, fail2)
        env = extend_environment(function_parameters(fun),
                                 args,
                                 function_environment(fun))
        return function_body(fun)(env, body_succeed, fail)
    else:
        return error('unknown function type -- execute_application', fun)
def analyze_application(component):
    ffun = analyze(function_expression(component))
    afuns = map(analyze, arg_expressions(component))
    def the_application(env, succeed, fail):
        def fun_succeed(fun, fail2):
            def args_succeed(args, fail3):
                return execute_application(fun, args, succeed, fail3)
            return get_args(afuns, env, args_succeed, fail2)
        return ffun(env, fun_succeed, fail)
    return the_application
def analyze_amb(component):
    cfuns = map(analyze, amb_choices(component))
    def the_amb(env, succeed, fail):
        def try_next(choices):
            if is_none(choices):
                return fail()
            else:
                return head(choices)(env, succeed,
                                     lambda: try_next(tail(choices)))
        return try_next(cfuns)
    return the_amb
def analyze(component):
    if is_literal(component):
        return analyze_literal(component)
    elif is_name(component):
        return analyze_name(component)
    elif is_amb(component):
        return analyze_amb(component)
    elif is_application(component):
        return analyze_application(component)
    elif is_operator_combination(component):
        return analyze(operator_combination_to_application(component))
    elif is_conditional(component):
        return analyze_conditional(component)
    elif is_lambda_expression(component):
        return analyze_lambda_expression(component)
    elif is_sequence(component):
        return analyze_sequence(sequence_statements(component))
    elif is_return_statement(component):
        return analyze_return_statement(component)
    elif is_function_definition(component):
        return analyze_function_definition(component)
    elif (is_pass_statement(component) or
          is_global_statement(component) or
          is_nonlocal_statement(component)):
        return lambda env, succeed, fail: succeed(None, fail)
    elif is_assignment(component):
        return analyze_assignment(component)
    else:
        return error('unknown syntax -- analyze', component)
def ambeval(component, env, succeed, fail):
    return analyze(component)(env, succeed, fail)
def first_solution(input):
    return ambeval(parse(input), the_global_environment,
                   lambda val, next_alternative: val,
                   lambda: None)
my_amb_program = """
def member(item, x):
    if is_none(x):
        return None
    elif item == head(x):
        return x
    else:
        return member(item, tail(x))
def require(p):
    if not p:
        amb()
# solution by GitHub user jonathantorres
def an_integer_between(low, high):
    require(low <= high)
    return amb(low, an_integer_between(low+1, high))
def a_pythagorean_triple_between(low, high):
    i = an_integer_between(low, high)
    j = an_integer_between(i, high)
    k = an_integer_between(j, high)
    require(i * i + j * j == k * k)
    return llist(i, j, k)
a_pythagorean_triple_between(5, 15)
"""
print(first_solution(my_amb_program))

# expected: [ 5, [ 12, [ 13, None ] ] ]
