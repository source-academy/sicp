# chapter=4 
def is_variable(x): return is_string(x)
def is_same_variable(v1, v2):
    return is_variable(v1) and is_variable(v2) and v1 == v2
def deriv(exp, variable):
    return (0
            if is_number(exp)
            else (1 if is_same_variable(exp, variable) else 0)
            if is_variable(exp)
            else get("deriv", operator(exp))(operands(exp), variable))
def operator(exp): return head(exp)

def operands(exp): return tail(exp)
def make_sum(a1, a2):
    return llist("+", a1, a2)
            
def make_product(m1, m2):
    return llist("*", m1, m2)
            
def addend(operands):
    return head(operands)
            
def augend(operands):
    return head(tail(operands))
            
def multiplier(operands):
    return head(operands)
            
def multiplicand(operands):
    return head(tail(operands))
# operation_table, put and get
# from chapter 3 (section 3.3.3)
def deriv_sum(operands, variable):
    return make_sum(deriv(addend(operands), variable),
                    deriv(augend(operands), variable))
def deriv_product(operands, variable):
    return make_sum(make_product(multiplier(operands),
                        deriv(multiplicand(operands),
                              variable)),
                    make_product(deriv(multiplier(
                                             operands),
                                       variable),
                        multiplicand(operands)))
def install_deriv():
    put("deriv", "+", deriv_sum)
    put("deriv", "*", deriv_product)
    return "done"
print(install_deriv())

print(head(tail(head(tail(deriv(llist("*", llist("*", "x", "y"), llist("+", "x", 3)), "x"))))))

# expected: [ '*', [ 'x', [ 'y', None ] ] ]
