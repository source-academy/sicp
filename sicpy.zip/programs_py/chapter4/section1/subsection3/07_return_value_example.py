def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
my_return_value = make_return_value(42)
print(is_return_value(my_return_value))
print(return_value_content(my_return_value))
