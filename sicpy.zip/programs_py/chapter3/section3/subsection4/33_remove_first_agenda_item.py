def make_agenda():
    return llist(0)

def current_time(agenda):
    return head(agenda)

def set_current_time(agenda, time):
    set_head(agenda, time)

def segments(agenda):
    return tail(agenda)

def set_segments(agenda, segs):
    set_tail(agenda, segs)

def first_segment(agenda):
    return head(segments(agenda))

def rest_segments(agenda):
    return tail(segments(agenda))
def front_ptr(queue):
    return head(queue)

def rear_ptr(queue):
    return tail(queue)

def set_front_ptr(queue, item):
    set_head(queue, item)

def set_rear_ptr(queue, item):
    set_tail(queue, item)
def is_empty_queue(queue):
    return is_none(front_ptr(queue))
def delete_queue(queue):
    if is_empty_queue(queue):
        error("delete_queue called with an empty queue", queue)
    else:
        set_front_ptr(queue, tail(front_ptr(queue)))
        return queue
def make_time_segment(time, queue):
    return pair(time, queue)

def segment_time(s):
    return head(s)

def segment_queue(s):
    return tail(s)
def remove_first_agenda_item(agenda):
    q = segment_queue(first_segment(agenda))
    delete_queue(q)
    if is_empty_queue(q):
        set_segments(agenda, rest_segments(agenda))
    else:
        pass
