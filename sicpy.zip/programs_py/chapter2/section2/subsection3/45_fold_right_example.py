def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
# same as reduce
fold_right = reduce
print(length(fold_right(llist, None, llist(1, 2, 3))))
