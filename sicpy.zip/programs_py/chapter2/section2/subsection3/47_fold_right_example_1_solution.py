def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
# same as accumulate
fold_right = accumulate
def divide(x, y):
    return x / y
print(fold_right(divide, 1, llist(1, 2, 3)))
# result: 1.5

# expected: 1.5
