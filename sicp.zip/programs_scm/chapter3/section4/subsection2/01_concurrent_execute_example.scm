; chapter=3 variant=concurrent 
(define x 10)

(parallel-execute (lambda () (set! x (* x x)))
  (lambda () (set! x (+ x 1))))

; expected: 'all threads terminated'
