import { heart, stack, turn_upside_down, beside, flip_vert, flip_horiz, show } from 'rune';

def square_of_four(tl, tr, bl, br):
    return lambda painter: stack(beside(tl(painter), tr(painter)),
                            beside(bl(painter), br(painter)))
def identity(x):
    return x
def flipped_pairs(painter):
    combine4 = square_of_four(turn_upside_down, flip_vert, 
                                    flip_horiz, identity)
    return combine4(painter)

print(show(flipped_pairs(heart)))
