(define (make-sum a1 a2) (list '+ a1 a2))
(define (make-product m1 m2) (list '* m1 m2))

(make-sum (make-product 'x 3) (make-product 'y 'z))

; expected: [ '*', [ 'x', [ 3, null ] ] ]
