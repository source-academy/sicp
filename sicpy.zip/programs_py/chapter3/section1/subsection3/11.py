print(25 - 20)

# expected: 5
