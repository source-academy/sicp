(define x (list 'a 'b))
(define z1 (cons x x))
z1

; expected: [ [ 'a', [ 'b', null ] ], [ 'a', [ 'b', null ] ] ]
