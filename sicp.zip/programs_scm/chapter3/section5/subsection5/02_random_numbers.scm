(define random-numbers
  (cons-stream random-init
               (stream-map rand-update random-numbers)))

; expected: 172561279022
