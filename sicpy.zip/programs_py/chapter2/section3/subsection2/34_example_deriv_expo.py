print(head(tail(head(tail(deriv(llist("**", "x", 4), "x"))))))
