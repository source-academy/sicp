def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def cube(x):
    return x * x * x
def integral(f, a, b, dx):
    return sum(f,
               a + dx / 2,
               lambda x: x + dx,
               b) * dx

print(integral(cube, 0, 1, 0.01))

# expected: 0.24998750000000042
