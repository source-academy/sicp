def factorial(n):
    def term(i):
        return i
    def next(i):
        return i + 1
    return product_r(term, 1, next, n)
