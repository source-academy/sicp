three_list = llist("a", "b", "c")
one = pair("d", "e")
two = pair(one, one)
four_list = pair(two, "f")
seven_list = pair(two, two)
cycle = llist("g", "h", "i")
set_tail(tail(tail(cycle)), cycle)

# return 3; return 3; return 3
print(count_pairs(three_list))
print(count_pairs(four_list))
print(count_pairs(seven_list))

# return 3
print(count_pairs(cycle))
