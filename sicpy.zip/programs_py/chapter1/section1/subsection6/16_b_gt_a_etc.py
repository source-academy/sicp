a = 3
b = a + 1
print(b if b > a and b < a * b else a)

# expected: 4
