((flipped-pairs rogers) full-frame)
