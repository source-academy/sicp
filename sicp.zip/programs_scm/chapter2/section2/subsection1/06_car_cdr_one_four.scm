(define one-through-four (list 1 2 3 4))
(car (cdr one-through-four))

; expected: 2
