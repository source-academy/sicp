def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def remove(item, sequence):
    return filter(lambda x: x != item,
                  sequence)
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
print(length(remove(3, llist(1, 2, 3, 4, 5))))
