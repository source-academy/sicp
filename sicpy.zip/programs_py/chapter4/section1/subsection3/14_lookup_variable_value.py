def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def extend_environment(symbols, vals, base_env):
    if length(symbols) == length(vals):
        return pair(make_frame(symbols, vals), base_env)
    elif length(symbols) < length(vals):
        error('too many arguments supplied', pair(symbols, vals))
    else:
        error('too few arguments supplied', pair(symbols, vals))
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

def add_binding_to_frame(symbol, val, frame):
    set_head(frame, pair(symbol, head(frame)))
    set_tail(frame, pair(val, tail(frame)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
built_in_constants = llist(llist('math_pi', math_pi), llist('math_e', math_e))
built_in_constant_symbols = map(lambda c: head(c), built_in_constants)
built_in_constant_values = map(lambda c: head(tail(c)), built_in_constants)
def is_built_in_function(fun):
    return is_tagged_llist(fun, 'built_in')

def built_in_implementation(fun):
    return head(tail(fun))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def make_function(parameters, locals, globals, body, env):
    return llist('compound_function', parameters, locals, globals, body, env)
def is_compound_function(f):
    return is_tagged_llist(f, 'compound_function')
def function_parameters(f):
    return llist_ref(f, 1)

def function_locals(f):
    return llist_ref(f, 2)

def function_globals(f):
    return llist_ref(f, 3)

def function_body(f):
    return llist_ref(f, 4)

def function_environment(f):
    return llist_ref(f, 5)
def print_without_environments(*objects):
    def prepare(object):
        if is_compound_function(object):
            return '<compound-function>'
        elif is_built_in_function(object):
            return '<built-in-function>'
        elif is_pair(object):
            return pair(prepare(head(object)), prepare(tail(object)))
        else:
            return object
    return apply_in_underlying_python(print,
                                      map(prepare, llist(*objects)))
built_in_functions = llist(llist('head', head), llist('tail', tail), llist('pair', pair), llist('is_none', is_none), llist('llist', llist), llist('print', print_without_environments), llist('error', error), llist('abs', abs), llist('+', lambda x, y: x + y), llist('-', lambda x, y: x - y), llist('*', lambda x, y: x * y), llist('/', lambda x, y: x / y), llist('//', lambda x, y: x // y), llist('%', lambda x, y: x % y), llist('**', lambda x, y: x ** y), llist('==', lambda x, y: x == y), llist('!=', lambda x, y: x != y), llist('<', lambda x, y: x < y), llist('<=', lambda x, y: x <= y), llist('>', lambda x, y: x > y), llist('>=', lambda x, y: x >= y), llist('is', lambda x, y: x is y), llist('is not', lambda x, y: x is not y), llist('not', lambda x: not x), llist('-unary', lambda x: -x), llist('+unary', lambda x: +x))
built_in_function_symbols = map(head, built_in_functions)
built_in_function_objects = map(lambda fun: llist('built_in', head(tail(fun))), built_in_functions)
def setup_environment():
    built_in_environment = extend_environment(
        append(built_in_function_symbols, built_in_constant_symbols),
        append(built_in_function_objects, built_in_constant_values),
        the_empty_environment)
    return extend_environment(None, None, built_in_environment)
the_global_environment = setup_environment()
def lookup_symbol_value(symbol, env):
    def env_loop(env):
        def scan(symbols, vals):
            if is_none(symbols):
                return env_loop(enclosing_environment(env))
            elif symbol == head(symbols):
                if head(vals) == '*global*':
                    return lookup_symbol_value(symbol, the_global_environment)
                else:
                    return head(vals)
            else:
                return scan(tail(symbols), tail(vals))
        if env is the_empty_environment:
            error('unbound name', symbol)
        else:
            frame = first_frame(env)
            return scan(frame_symbols(frame), frame_values(frame))
    return env_loop(env)

my_environment = extend_environment(llist('x', 'y', 'z'), llist(1, 2, 3), the_empty_environment)
print(lookup_symbol_value('x', my_environment))

# expected: 1
