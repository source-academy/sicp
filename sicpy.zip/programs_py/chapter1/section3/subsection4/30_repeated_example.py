def square(x): return x * x
# repeated to be written by student; see EXERCISE 1.43
print(repeated(square, 2)(5))
