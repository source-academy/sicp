def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def append(x, y):
    return (y if is_none(x)
            else pair(head(x), append(tail(x), y)))
def last_pair(x):
    return (x if is_none(tail(x))
            else last_pair(tail(x)))
def append_mutator(x, y):
    set_tail(last_pair(x), y)
    return x
x = llist("a", "b")
y = llist("c", "d")
z = append(x, y)
print(z)
print(tail(x))
w = append_mutator(x, y)
print(w)
print(tail(x))
