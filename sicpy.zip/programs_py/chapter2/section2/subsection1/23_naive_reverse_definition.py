def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def reverse(items):
    def reverse_iter(items, result):
        return (result if is_none(items)
                else reverse_iter(tail(items),
                                  pair(head(items), result)))
    return reverse_iter(items, None)
def reverse(items):
    return (None if is_none(items)
            else append(reverse(tail(items)),
                                    pair(head(items), None)))

print(head(reverse(llist(1, 4, 5, 9, 16, 25))))

# expected: 25
