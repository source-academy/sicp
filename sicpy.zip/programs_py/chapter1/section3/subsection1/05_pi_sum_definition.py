def pi_sum(a, b):
    return 0 if a > b else 1 / (a * (a + 2)) + pi_sum(a + 4, b)

print(8 * pi_sum(1, 1000))

# expected: 3.139592655589783
