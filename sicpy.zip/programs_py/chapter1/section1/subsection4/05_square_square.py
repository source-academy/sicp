def square(x): return x * x
print(square(square(3)))

# expected: 81
