def plus(x, y):
    return x + y
def fold_left(op, initial, sequence):
    def iter(result, rest):
        return (result if is_none(rest)
                else iter(op(result, head(rest)),
                          tail(rest)))
    return iter(initial, sequence)
print(fold_left(plus, 0, llist(1, 2, 3)))

# expected: 6
