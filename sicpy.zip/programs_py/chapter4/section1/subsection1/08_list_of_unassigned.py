def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def llist_of_unassigned(symbols):
    return map(lambda symbol: "*unassigned*", symbols)
