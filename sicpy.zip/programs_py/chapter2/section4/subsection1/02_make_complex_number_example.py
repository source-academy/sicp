my_co_num_1 = make_from_real_imag(2.5, -0.5)
my_co_num_2 = make_from_real_imag(2.5, -0.5)

result = add_complex(my_co_num_1,
                     mul_complex(my_co_num_2,
                                 my_co_num_2))

print(imag_part(result))
