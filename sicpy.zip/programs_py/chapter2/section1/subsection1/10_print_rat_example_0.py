one_half = make_rat(1, 2)

print(print_rat(one_half))
