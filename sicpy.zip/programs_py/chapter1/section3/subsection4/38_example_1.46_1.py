def square(x): return x * x
def average(x, y):
    return (x + y) / 2
def improve(guess, x):
    return average(guess, x / guess)
def abs(x):
    return x if x >= 0 else - x
def is_good_enough(guess, x):
    return abs(square(guess) - x) < 0.001
def iterative_improve(is_good_enough, improve):
    def iterate(guess):
        return guess if is_good_enough(guess) else iterate(improve(guess))
    return iterate
def sqrt(x):
    return iterative_improve(lambda y: is_good_enough(y, x),
                             lambda y: improve(y, x))(1)

print(sqrt(49))
