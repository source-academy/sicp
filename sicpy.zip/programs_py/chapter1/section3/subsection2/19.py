def is_even(n):
    return n % 2 == 0
def expmod(base, exp, m):
    half_exp = expmod(base, exp // 2, m)
    return (1 if exp == 0
            else (half_exp * half_exp) % m if is_even(exp)
            else (base * expmod(base, exp - 1, m)) % m)

print(expmod(4, 3, 5))
