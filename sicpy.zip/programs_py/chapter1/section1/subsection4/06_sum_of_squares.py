def square(x): return x * x
def sum_of_squares(x, y):
    return square(x) + square(y)

print(sum_of_squares(3, 4))

# expected: 25
