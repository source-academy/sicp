;; double to be written by student; see EXERCISE 1.41
(define (inc n) (+ n 1))
(((double (double double)) inc) 5)
