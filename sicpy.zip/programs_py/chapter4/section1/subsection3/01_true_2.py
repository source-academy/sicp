def is_truthy(x):
    return not is_falsy(x)

def is_falsy(x):
    return (is_boolean(x) and not x) or (is_number(x) and (x == 0 or x != x)) or (is_string(x) and x == "") or is_null(x) or is_undefined(x)
