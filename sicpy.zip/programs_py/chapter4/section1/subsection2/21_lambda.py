def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_list(component, "name")
def symbol_of_name(component):
    return head(tail(component))
def is_lambda_expression(component):
    return is_tagged_list(component, "lambda_expression")
def lambda_parameter_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def lambda_body(component):
    return head(tail(tail(component)))

my_lambda = parse("lambda x: x")
print(is_lambda_expression(my_lambda))
print(lambda_parameter_symbols(my_lambda))
print(lambda_body(my_lambda))
