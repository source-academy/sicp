print(tree_to_linked_list_2(union_set_as_tree(
                    linked_list_to_tree(llist(1, 3, 5, 7)),
                    linked_list_to_tree(llist(2, 4, 6, 8)) ) ))
