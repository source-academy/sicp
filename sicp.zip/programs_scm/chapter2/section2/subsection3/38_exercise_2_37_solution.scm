
;; in Scheme, the operator symbol + is procedure name
;; in Scheme, the operator symbol * is procedure name
(define (dot-product v w)
  (accumulate + 0 (map * v w)))




; expected: [ 140, [ 160, [ 60, null ] ] ]
