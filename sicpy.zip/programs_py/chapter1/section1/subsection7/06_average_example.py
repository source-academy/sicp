print(average(3, 6))
