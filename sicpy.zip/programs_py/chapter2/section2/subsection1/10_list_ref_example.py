def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
squares = llist(1, 4, 9, 16, 25)

print(llist_ref(squares, 3))

# expected: 16
