v = llist("a", "b", "c", "d")
def mystery(x):
    def loop(x, y):
        if is_none(x):
            return y
        else:
            temp = tail(x)
            set_tail(x, y)
            return loop(temp, x)
    return loop(x, None)

w = mystery(v)
