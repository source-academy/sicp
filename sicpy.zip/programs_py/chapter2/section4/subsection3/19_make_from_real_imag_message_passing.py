# chapter=3 
def square(x): return x * x
def make_from_real_imag(x, y):
    def dispatch(op):
        return (x
                if op == "real_part"
                else y
                if op == "imag_part"
                else math_sqrt(square(x) + square(y))
                if op == "magnitude"
                else math_atan2(y, x)
                if op == "angle"
                else error("unknown op -- make_from_real_imag", op))
    return dispatch

def make_from_mag_ang(r, a):
    def dispatch(op):
        return (r * math_cos(a)
                if op == "real_part"
                else r * math_sin(a)
                if op == "imag_part"
                else r
                if op == "magnitude"
                else a
                if op == "angle"
                else error("unknown op -- make_from_real_imag", op))
    return dispatch

def apply_generic(op, arg):
    return head(arg)(op)
def real_part(z):
    return apply_generic("real_part", llist(z))
def imag_part(z):
    return apply_generic("imag_part", llist(z))
def magnitude(z):
    return apply_generic("magnitude", llist(z))
def angle(z):
    return apply_generic("angle", llist(z))
def add_complex(z1, z2):
    return make_from_real_imag(
               real_part(z1) + real_part(z2),
               imag_part(z1) + imag_part(z2))
def sub_complex(z1, z2):
    return make_from_real_imag(
               real_part(z1) - real_part(z2),
               imag_part(z1) - imag_part(z2))
def mul_complex(z1, z2):
    return make_from_mag_ang(
               magnitude(z1) * magnitude(z2),
               angle(z1) + angle(z2))
def div_complex(z1, z2):
    return make_from_mag_ang(
               magnitude(z1) / magnitude(z2),
               angle(z1) - angle(z2))
# operation_table, put and get
# from chapter 3 (section 3.3.3)
def assoc(key, records):
    return (None
            if is_none(records)
            else head(records)
            if key == head(head(records))
            else assoc(key, tail(records)))
def make_table():
    local_table = llist("*table*")
    def lookup(key_1, key_2):
        subtable = assoc(key_1, tail(local_table))
        if is_none(subtable):
            return None
        else:
            record = assoc(key_2, tail(subtable))
            return (None
                    if is_none(record)
                    else tail(record))
    def insert(key_1, key_2, value):
        subtable = assoc(key_1, tail(local_table))
        if is_none(subtable):
            set_tail(local_table,
                     pair(llist(key_1, pair(key_2, value)),
                          tail(local_table)))
        else:
            record = assoc(key_2, tail(subtable))
            if is_none(record):
                set_tail(subtable,
                         pair(pair(key_2, value),
                              tail(subtable)))
            else:
                set_tail(record, value)
    def dispatch(m):
        return (lookup
                if m == "lookup"
                else insert
                if m == "insert"
                else "undefined operation -- table")
    return dispatch
operation_table = make_table()
get = operation_table("lookup")
put = operation_table("insert")
def attach_tag(type_tag, contents):
    return pair(type_tag, contents)
def type_tag(datum):
    return (head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))
def install_rectangular_package():
    def real_part(z): return head(z)
    def imag_part(z): return tail(z)
    def make_from_real_imag(x, y): return pair(x, y)
    def magnitude(z):
        return math_sqrt(square(real_part(z)) +
                   square(imag_part(z)))
    def angle(z):
        return math_atan2(imag_part(z), real_part(z))
    def make_from_mag_ang(r, a):
        return pair(r * math_cos(a), r * math_sin(a))
    # interface to the rest of the system
    def tag(x):
        return attach_tag("rectangular", x)
    put("real_part", llist("rectangular"), real_part)
    put("imag_part", llist("rectangular"), imag_part)
    put("magnitude", llist("rectangular"), magnitude)
    put("angle", llist("rectangular"), angle)
    put("make_from_real_imag", "rectangular",
        lambda x, y: tag(make_from_real_imag(x, y)))
    put("make_from_mag_ang", "rectangular",
        lambda r, a: tag(make_from_mag_ang(r, a)))
    return "done"

install_rectangular_package()
def install_polar_package():
    # internal functions
    def magnitude(z): return head(z)
    def angle(z): return tail(z)
    def make_from_mag_ang(r, a): return pair(r, a)
    def real_part(z):
        return magnitude(z) * math_cos(angle(z))
    def imag_part(z):
        return magnitude(z) * math_sin(angle(z))
    def make_from_real_imag(x, y):
        return pair(math_sqrt(square(x) + square(y)),
                    math_atan2(y, x))

    # interface to the rest of the system
    def tag(x): return attach_tag("polar", x)
    put("real_part", llist("polar"), real_part)
    put("imag_part", llist("polar"), imag_part)
    put("magnitude", llist("polar"), magnitude)
    put("angle", llist("polar"), angle)
    put("make_from_real_imag", "polar",
        lambda x, y: tag(make_from_real_imag(x, y)))
    put("make_from_mag_ang", "polar",
        lambda r, a: tag(make_from_mag_ang(r, a)))
    return "done"

print(install_polar_package())

my_complex_number = make_from_real_imag(1.0, 4.5)

result = add_complex(my_complex_number,
                     my_complex_number)

print(imag_part(result))

# expected: 9
