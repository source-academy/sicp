; chapter=3 variant=non-det 
(define *unparsed* '())
