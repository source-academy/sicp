def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag

is_tagged_list(llist("name", "x"), "name")

# expected: true
