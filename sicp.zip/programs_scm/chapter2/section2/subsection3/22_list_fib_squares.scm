(define (square x) (* x x))
(define (fib n)
  (cond ((= n 0) 0)
        ((= n 1) 1)
        (else (+ (fib (- n 1))
                 (fib (- n 2))))))
(define (enumerate-interval low high)
   (if (> low high)
      nil
      (cons low (enumerate-interval (+ low 1) high))))
(define (list-fib-squares n)
  (accumulate cons
              nil
              (map square
                   (map fib
                        (enumerate-interval 0 n)))))

(list-fib-squares 10)

; expected: 11
