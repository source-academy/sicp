def average(x, y):
    return (x + y) / 2
def improve(guess, x):
    return average(guess, x / guess)
def sqrt_iter(guess, x):
    return (guess
            if is_good_enough(guess, x)
            else sqrt_iter(improve(guess, x), x))

def sqrt(x):
    return sqrt_iter(1, x)
