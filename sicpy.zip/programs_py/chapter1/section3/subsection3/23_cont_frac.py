# cont_frac to be written by student; see exercise 1.37
# iterative process
def cont_frac(n, d, k):
    def fraction(i, current):
        return current if i == 0 else fraction(i - 1, n(i) / (d(i) + current))
    return fraction(k, 0)

print(cont_frac(lambda i: 1, lambda i: 1, 20))

# expected: 0.6180339850173578
