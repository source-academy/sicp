def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
print(length(prime_sum_pairs(6)))
