def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
x = llist(llist(1, 2), llist(3, 4))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
# fringe to be written by student
def fringe(x):
    return (None if is_none(x)
            else append(fringe(head(x)), fringe(tail(x)))
            if is_pair(x)
            else llist(x))

print(length(fringe(llist(x, x))))

# expected: 8
