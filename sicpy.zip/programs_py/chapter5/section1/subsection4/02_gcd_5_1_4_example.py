print(gcd(20, 12))
