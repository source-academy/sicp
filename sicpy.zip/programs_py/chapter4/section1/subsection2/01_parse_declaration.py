parse('size = 2\n5 * size')
