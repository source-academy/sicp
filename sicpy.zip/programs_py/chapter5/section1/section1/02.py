def factorial(n):
    def iter(product, counter):
        return product if counter > n else iter(counter * product, counter + 1)
    return iter(1, 1)

print(factorial(5))
