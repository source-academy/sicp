(define a 3)

; expected: undefined
