(define (make-tableau transform s)
  (cons-stream s
               (make-tableau transform
                             (transform s))))
(define (square x) (* x x))
(define (euler-transform s)
  (let ((s0 (stream-ref s 0))           ; $S_{n-1}$
        (s1 (stream-ref s 1))           ; $S_{n}$
        (s2 (stream-ref s 2)))          ; $S_{n+1}$
    (cons-stream (- s2 (/ (square (- s2 s1))
                          (+ s0 (* -2 s1) s2)))
                 (euler-transform (stream-cdr s)))))
(define (scale-stream stream factor)
  (stream-map (lambda (x) (* x factor)) stream))
(define (add-streams s1 s2)
  (stream-map + s1 s2))
(define (partial-sum s)
  (cons-stream (stream-car s)
               (add-streams (stream-cdr s)
                            (partial-sum s))))
(define (pi-summands n)
  (cons-stream (/ 1.0 n)
               (stream-map - (pi-summands (+ n 2)))))

(define pi-stream
  (scale-stream (partial-sums (pi-summands 1)) 4))
(define (accelerated-sequence transform s)
  (stream-map stream-car
              (make-tableau transform s)))

(display-stream (accelerated-sequence euler-transform
                                      pi-stream))
