(define (make-account balance)
   (define (withdraw amount)
      (if (>= balance amount)
         (begin (set! balance (- balance amount))
                balance)
            "Insufficient funds"))
   (define (deposit amount)
      (set! balance (+ balance amount))
      balance)
   (define (dispatch m)
      (cond ((eq? m 'withdraw) withdraw)
            ((eq? m 'deposit) deposit)
            (else (error "Unknown request - - MAKE-ACCOUNT"
                   m))))
   dispatch)
(define peter-acc (make-account 100))
(define paul-acc peter-acc)

; expected: 20
