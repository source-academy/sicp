def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
print(llist_ref(append(llist(1, 3), llist(5, 7, 9)), 4))

# expected: 9
