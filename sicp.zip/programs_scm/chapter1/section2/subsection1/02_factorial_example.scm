(factorial 5)
