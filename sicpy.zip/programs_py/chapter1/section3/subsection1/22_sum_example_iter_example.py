def inc(n):
    return n + 1
def sum_cubes(a, b):
    return sum(cube, a, inc, b)
print(sum_cubes(1, 10))
