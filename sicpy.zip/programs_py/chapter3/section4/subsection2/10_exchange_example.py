a1 = make_account(100)
a2 = make_account(200)
a3 = make_account(300)

def peter():
    print('Peter balance a1 before', a1('balance'))
    print('Peter balance a2 before', a2('balance'))
    exchange(a1, a2)
    print('Peter balance a1 after', a1('balance'))
    print('Peter balance a2 after', a2('balance'))

def paul():
    print('Paul balance a1 before', a1('balance'))
    print('Paul balance a3 before', a3('balance'))
    exchange(a1, a3)
    print('Paul balance a1 after', a1('balance'))
    print('Paul balance a3 after', a3('balance'))

print(concurrent_execute(peter, paul))
