def is_truthy(x):
    if is_boolean(x):
        return x
    else:
        error('boolean expected, received', x)
def is_falsy(x):
    return not is_truthy(x)

print(is_truthy(False))
# should print False, because only True is truthy

# expected: False
