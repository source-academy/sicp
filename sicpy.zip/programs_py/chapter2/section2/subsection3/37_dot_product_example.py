print(dot_product(llist(1, 2), llist(3, 4)))
