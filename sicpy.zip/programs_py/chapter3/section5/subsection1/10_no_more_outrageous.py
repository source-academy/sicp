def stream_tail(stream):
    return tail(stream)()
def stream_filter(pred, stream):
    return (None if is_none(stream)
            else pair(head(stream),
                      lambda: stream_filter(pred, stream_tail(stream)))
                if pred(head(stream))
            else stream_filter(pred, stream_tail(stream)))
def square(x): return x * x
def smallest_divisor(n):
    return find_divisor(n, 2)

def find_divisor(n, test_divisor):
    return (n if square(test_divisor) > n
            else test_divisor if divides(test_divisor, n)
            else find_divisor(n, test_divisor + 1))

def divides(a, b):
    return b % a == 0
def is_prime(n):
    return n == smallest_divisor(n)
def stream_enumerate_interval(low, high):
    return (None if low > high
            else pair(low,
                      lambda: stream_enumerate_interval(low + 1, high)))
print(head(stream_tail(stream_filter(
                     is_prime,
                     stream_enumerate_interval(10000, 1000000)))))

# expected: 10009
