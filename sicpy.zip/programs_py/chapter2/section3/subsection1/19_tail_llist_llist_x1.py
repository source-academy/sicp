print(tail(llist(llist("x1", "x2"), llist("y1", "y2"))))
# [["y1", ["y2", None]], None]

# expected: [ [ 'y1', [ 'y2', None ] ], None ]
