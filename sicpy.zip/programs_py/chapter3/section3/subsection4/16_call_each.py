def call_each(functions):
    if is_none(functions):
        return "done"
    else:
        head(functions)()
        return call_each(tail(functions))
