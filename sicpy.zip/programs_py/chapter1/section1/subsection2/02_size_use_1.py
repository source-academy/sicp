size = 2
print(size)

# expected: 2
