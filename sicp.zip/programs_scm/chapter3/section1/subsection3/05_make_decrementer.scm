(define (make-decrementer balance)
            (lambda (amount)
            (- balance amount)))
