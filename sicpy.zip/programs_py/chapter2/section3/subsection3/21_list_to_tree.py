def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def entry(tree): return head(tree)

def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def make_tree(entry, left, right):
    return llist(entry, left, right)
def linked_list_to_tree(elements):
    return head(partial_tree(elements, length(elements)))
def partial_tree(elts, n):
    if n == 0:
        return pair(None, elts)
    else:
        left_size = (n - 1) // 2
        left_result = partial_tree(elts, left_size)
        left_tree = head(left_result)
        non_left_elts = tail(left_result)
        right_size = n - (left_size + 1)
        this_entry = head(non_left_elts)
        right_result = partial_tree(tail(non_left_elts), right_size)
        right_tree = head(right_result)
        remaining_elts = tail(right_result)
        return pair(make_tree(this_entry, left_tree, right_tree),
                    remaining_elts)

print(head(tail(linked_list_to_tree(llist(10, 20, 30)))))

# expected: [ 10, [ None, [ None, None ] ] ]
