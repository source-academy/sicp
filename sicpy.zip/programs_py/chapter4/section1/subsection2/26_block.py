def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_block(component):
    return is_tagged_list(component, "block")
def block_body(component):
    return head(tail(component))
def make_block(statement):
    return llist("block", statement)

my_block = parse("{ 1; true; 45; }")
print(is_block(my_block))
print(block_body(my_block))
