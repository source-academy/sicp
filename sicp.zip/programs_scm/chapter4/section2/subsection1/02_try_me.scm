; chapter=2 variant=lazy 
(define (try a b)
  (if (= a 0) 1 b))

; expected: 1
