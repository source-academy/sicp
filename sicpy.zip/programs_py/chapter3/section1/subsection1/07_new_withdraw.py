def make_withdraw_balance_100():
    balance = 100
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return "Insufficient funds"
    return withdraw

new_withdraw = make_withdraw_balance_100()

new_withdraw(60)
print(new_withdraw(60))
