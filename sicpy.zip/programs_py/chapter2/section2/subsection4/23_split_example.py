import { heart, stack, beside, show } from 'rune';

def split(bigger_op, smaller_op):
    def rec_split(painter, n):
        if n == 0:
            return painter
        else:
            smaller = rec_split(painter, n - 1)
            return bigger_op(painter,
                        smaller_op(smaller, smaller))
    return rec_split
right_split = split(beside, stack)

print(show(right_split(heart, 4)))
