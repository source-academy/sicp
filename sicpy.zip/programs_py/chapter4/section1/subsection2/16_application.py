def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_application(component):
    return is_tagged_llist(component, 'application')
def function_expression(component):
    return head(tail(component))
def arg_expressions(component):
    return head(tail(tail(component)))

my_application = parse('math_pow(3, 4)')
print(is_application(my_application))
print(function_expression(my_application))
print(arg_expressions(my_application))
