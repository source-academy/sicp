print(entry(
  left_branch(
    right_branch(
      make_tree(10,
                None,
                make_tree(30,
                          make_tree(20, None, None),
                          None))))))
