(identity 42)
