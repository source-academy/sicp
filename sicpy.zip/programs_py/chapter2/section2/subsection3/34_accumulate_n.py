def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def plus(x, y):
    return x + y
def reduce_n(op, init, seqs):
    return (None if is_none(head(seqs))
            else pair(reduce(op, init, map(lambda x: head(x), seqs)),
                      reduce_n(op, init, map(lambda x: tail(x), seqs))))

seq_seq = llist(llist(1, 2, 3), llist(4, 5, 6),
                llist(7, 8, 9), llist(10, 11, 12))
print(reduce_n(plus, 0, seq_seq))

# expected: [ 22, [ 26, [ 30, None ] ] ]
