(define z2 (cons (list 'a 'b) (list 'a 'b)))
z2

; expected: [ [ 'a', [ 'b', null ] ], [ 'a', [ 'b', null ] ] ]
