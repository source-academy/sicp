def identity(x):
    return x
print(show(square_of_four(turn_upside_down, identity, 
                    quarter_turn_right, quarter_turn_left)
     (heart)
    ))
