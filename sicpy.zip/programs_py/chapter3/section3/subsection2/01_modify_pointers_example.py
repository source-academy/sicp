q = pair(1, 2)
set_front_ptr(q, 42)
print(front_ptr(q))
