def number_equal(exp, num):
    return is_number(exp) and exp == num

print(number_equal(3, 3))

# expected: True
