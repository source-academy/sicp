# chapter=2 variant=lazy 
xs = None
# Source Academy opens this program
# in lazy mode. Choose the Python §2 language
# to compare with strict mode
def unless(condition, usual_value, exceptional_value):
    return exceptional_value if condition else usual_value

unless(is_none(xs), head(xs), print('error: xs should not be empty'))
