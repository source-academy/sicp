# functions from SICP Python 4.1.1
