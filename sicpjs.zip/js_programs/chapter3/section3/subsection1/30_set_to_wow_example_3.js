const z2 = pair(list("a", "b"), list("a", "b"));
z2;

// expected: [ [ 'a', [ 'b', null ] ], [ 'a', [ 'b', null ] ] ]
