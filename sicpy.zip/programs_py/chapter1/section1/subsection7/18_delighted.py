def conditional(predicate, then_clause, else_clause):
    return then_clause if predicate else else_clause
def abs(x):
    return x if x >= 0 else - x
def square(x): return x * x
def is_good_enough(guess, x):
    return abs(square(guess) - x) < 0.001
def average(x, y):
    return (x + y) / 2
def improve(guess, x):
    return average(guess, x / guess)
def sqrt_iter(guess, x):
    return conditional(is_good_enough(guess, x),
                       guess,
                       sqrt_iter(improve(guess, x),
                                 x))

print(sqrt_iter(3, 25))
