def expt(b, n):
    return expt_iter(b, n, 1)

def expt_iter(b, counter, product):
    return (product
            if counter == 0
            else expt_iter(b, counter - 1, b * product))

print(expt(3, 4))

# expected: 81
