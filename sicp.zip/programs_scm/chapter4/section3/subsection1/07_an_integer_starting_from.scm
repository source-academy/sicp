; chapter=3 variant=non-det 
(define (an-integer-starting-from n)
  (amb n (an-integer-starting-from (+ n 1))))

; expected: 5
