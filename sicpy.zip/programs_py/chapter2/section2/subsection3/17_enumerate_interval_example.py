def enumerate_interval(low, high):
    return (None if low > high
            else pair(low,
                      enumerate_interval(low + 1, high)))
print(tail(tail(tail(enumerate_interval(2, 7)))))
