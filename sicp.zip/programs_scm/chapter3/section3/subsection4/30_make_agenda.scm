(define (make-agenda) (list 0))
                
(define (current-time agenda) (car agenda))
                
(define (set-current-time! agenda time)
  (set-car! agenda time))
                
(define (segments agenda) (cdr agenda))
                
(define (set-segments! agenda segments)
  (set-cdr! agenda segments))
                
(define (first-segment agenda) (car (segments agenda)))
                
(define (rest-segments agenda) (cdr (segments agenda)))
