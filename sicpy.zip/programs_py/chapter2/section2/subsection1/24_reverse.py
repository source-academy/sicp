def reverse(items):
    def reverse_iter(items, result):
        return (result if is_none(items)
                else reverse_iter(tail(items),
                                  pair(head(items), result)))
    return reverse_iter(items, None)

print(head(reverse(llist(1, 4, 5, 9, 16, 25))))

# expected: 25
