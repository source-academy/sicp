my_amb_program = """
def member(item, x):
    if is_none(x):
        return None
    elif item == head(x):
        return x
    else:
        return member(item, tail(x))
