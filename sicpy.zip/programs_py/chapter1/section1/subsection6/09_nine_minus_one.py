print(9 - 1)

# expected: 8
