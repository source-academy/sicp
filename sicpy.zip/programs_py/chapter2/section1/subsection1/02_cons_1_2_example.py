x = pair(1, 2)
print(head(x))

# expected: 1
