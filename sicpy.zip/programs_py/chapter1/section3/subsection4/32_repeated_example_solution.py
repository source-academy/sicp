def square(x): return x * x
print(repeated(square, 2)(5))  # 625
