three_list = llist("a", "b", "c")
cycle = llist("g", "h", "i")
set_tail(tail(tail(cycle)), cycle)

# displays False
print(contains_cycle(three_list))

# displays True
print(contains_cycle(cycle))
