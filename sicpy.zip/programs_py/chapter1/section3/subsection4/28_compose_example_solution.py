def inc(n):
    return n + 1
def square(x): return x * x
print(compose(square, inc)(6))  # returns 49
