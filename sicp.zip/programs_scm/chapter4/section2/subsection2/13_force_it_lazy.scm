(define (evaluated-thunk? obj)
  (tagged-list? obj 'evaluated-thunk))

(define (thunk-value evaluated-thunk) (cadr evaluated-thunk))

(define (force-it obj)
  (cond ((thunk? obj)
         (let ((result (actual-value
                        (thunk-exp obj)
                        (thunk-env obj))))
           (set-car! obj 'evaluated-thunk)
           (set-car! (cdr obj) result)  
           (set-cdr! (cdr obj) '())     
           result))
        ((evaluated-thunk? obj)
         (thunk-value obj))
        (else obj)))

(define the-global-environment (setup-environment))
(eval (read) the-global-environment)
