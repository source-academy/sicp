my_account = make_account_and_serializer(100)

deposit(my_account, 200)

print(print(my_account("balance")))
