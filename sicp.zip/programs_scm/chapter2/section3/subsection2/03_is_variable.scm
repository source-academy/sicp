(define (variable? x) (symbol? x))

(variable? 'xyz)

; expected: true
