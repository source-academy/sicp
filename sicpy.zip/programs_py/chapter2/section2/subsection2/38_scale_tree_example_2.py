print(head(scale_tree(llist(1, llist(2, llist(3, 4), 5), llist(6, 7)),
           10)))
