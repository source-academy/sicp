ints1 = integers_from(1)
ints0 = integers_from(0)
adds = lambda x, y: x + y

print(eval_stream(stream_map_2(adds, ints1, ints0), 5))
print(print(eval_stream(stream_map_2_optimized(adds, ints1, ints0), 5)))
