def make_vect(x, y):
    return pair(x, y)
def xcor_vect(vector):
    return head(vector)
def ycor_vect(vector):
    return tail(vector)
def scale_vect(factor, vector):
    return make_vect(factor * xcor_vect(vector), 
                     factor * ycor_vect(vector))
def add_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     + xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     + ycor_vect(vector2))
def sub_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     - xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     - ycor_vect(vector2))
my_start = make_vect(0, 1)
my_end = make_vect(1, 1)
my_segment = make_segment(my_start, my_end)

print(my_segment)
