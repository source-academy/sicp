(define (add-streams s1 s2)
  (stream-map + s1 s2))
(define fibs
  (cons-stream 0
               (cons-stream 1
                            (add-streams (stream-cdr fibs)
                                         fibs))))

; expected: 6765
