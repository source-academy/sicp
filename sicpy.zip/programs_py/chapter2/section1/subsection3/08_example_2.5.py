print(tail(pair(3, 4)))
