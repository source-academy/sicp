def append(x, y):
    return y if is_none(x) else pair(head(x), append(tail(x), y))
