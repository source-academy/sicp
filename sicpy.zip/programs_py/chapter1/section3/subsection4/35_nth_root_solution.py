def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
def average(x, y):
    return (x + y) / 2
def average_damp(f):
    return lambda x: average(x, f(x))
def compose(f, g):
    return lambda x: f(g(x))
def repeated(f, n):
    return (lambda x: x) if n == 0 else compose(f, repeated(f, n - 1))
def square(x): return x * x
def is_even(n):
    return n % 2 == 0
def fast_expt(b, n):
    return (1 if n == 0
            else square(fast_expt(b, n // 2)) if is_even(n)
            else b * fast_expt(b, n - 1))
def nth_root(n, x):
    return fixed_point(repeated(average_damp,
                                math_floor(math_log2(n)))
                       (lambda y: x / fast_expt(y, n - 1)),
                       1)

print(nth_root(5, 32))

# expected: 2.000001512995761
