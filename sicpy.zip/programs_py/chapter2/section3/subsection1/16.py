def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))
member("red", llist("red", "shoes", "blue", "socks"))
