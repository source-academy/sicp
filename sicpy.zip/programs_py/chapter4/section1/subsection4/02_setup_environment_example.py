def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
the_global_environment = setup_environment()
print(head(head(head(enclosing_environment(the_global_environment)))))
