def pair(x, y):
    def dispatch(m):
        return (x if m == "head"
                else y if m == "tail"
                else error("undefined operation -- pair", m))
    return dispatch

def head(z):
    return z("head")

def tail(z):
    return z("tail")

x = pair(1, 2)
print(head(x))

# expected: 1
