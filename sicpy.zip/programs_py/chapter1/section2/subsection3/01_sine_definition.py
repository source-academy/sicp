def abs(x):
    return x if x >= 0 else - x
def cube(x):
    return x * x * x

def p(x):
    return 3 * x - 4 * cube(x)

def sine(angle):
    return angle if not (abs(angle) > 0.1) else p(sine(angle / 3))

print(sine(math_pi / 2))
