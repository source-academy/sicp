def abs(x):
    return x if x >= 0 else - x
print(abs(-5))

# expected: 5
