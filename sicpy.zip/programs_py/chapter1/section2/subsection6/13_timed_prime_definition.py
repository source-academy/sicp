def square(x): return x * x
def smallest_divisor(n):
    return find_divisor(n, 2)

def find_divisor(n, test_divisor):
    return (n if square(test_divisor) > n
            else test_divisor if divides(test_divisor, n)
            else find_divisor(n, test_divisor + 1))

def divides(a, b):
    return b % a == 0
def is_prime(n):
    return n == smallest_divisor(n)
def timed_prime_test(n):
    print(n)
    return start_prime_test(n, get_time())

def start_prime_test(n, start_time):
    return (report_prime(get_time() - start_time) if is_prime(n)
            else False)

def report_prime(elapsed_time):
    print(" *** ")
    print(elapsed_time)
    return True

timed_prime_test(43)
