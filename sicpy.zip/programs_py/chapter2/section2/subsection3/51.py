def plus(x, y):
    return x + y
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
# same as reduce
fold_right = reduce
print(fold_right(plus, 0, llist(1, 2, 3)))

# expected: 6
