def pair(x, y):
    def dispatch(m):
        return (x if m == 0
                else y if m == 1
                else error("argument not 0 or 1 -- pair", m))
    return dispatch
def head(z): return z(0)

def tail(z): return z(1)

x = pair(1, 2)
print(head(x))

# expected: 1
