def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
def scale_stream(stream, factor):
    return stream_map(lambda x: x * factor,
                      stream)
twos = pair(2, lambda: twos)
sixes = scale_stream(twos, 3)
print(stream_ref(sixes, 50))
