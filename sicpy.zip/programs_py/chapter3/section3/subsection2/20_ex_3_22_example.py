q = make_queue()
print_queue(q)  # prints: None
insert_queue(q, "a")
print_queue(q)  # prints: ["a", None]
insert_queue(q, "b")
print_queue(q)  # prints: ["a", ["b", None]]
delete_queue(q)
print(print_queue(q))  # prints: ["b", None]
