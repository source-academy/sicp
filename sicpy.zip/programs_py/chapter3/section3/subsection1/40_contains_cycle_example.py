def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def last_pair(x):
    return (x if is_none(tail(x))
            else last_pair(tail(x)))
def make_cycle(x):
    set_tail(last_pair(x), x)
    return x
c = make_cycle(llist("c", "d", "e"))
c1 = append(llist("a", "b"), c)

print(contains_cycle(c1))
