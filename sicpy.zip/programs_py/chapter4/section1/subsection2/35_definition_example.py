my_assignment_statement = parse("x = 1")
print(is_declaration(my_assignment_statement))
print(assignment_symbol(my_assignment_statement))
print(assignment_value_expression(my_assignment_statement))
