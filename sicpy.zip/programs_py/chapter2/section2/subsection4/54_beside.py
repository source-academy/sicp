def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def make_vect(x, y):
    return pair(x, y)
def xcor_vect(vector):
    return head(vector)
def ycor_vect(vector):
    return tail(vector)
def scale_vect(factor, vector):
    return make_vect(factor * xcor_vect(vector), 
                     factor * ycor_vect(vector))
def add_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     + xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     + ycor_vect(vector2))
def sub_vect(vector1, vector2):
    return make_vect(xcor_vect(vector1)  
                     - xcor_vect(vector2), 
                     ycor_vect(vector1)  
                     - ycor_vect(vector2))
def make_frame(origin, edge1, edge2):
    return llist(origin, edge1, edge2)
def origin_frame(frame):
    return llist_ref(frame, 0)
def edge1_frame(frame):
    return llist_ref(frame, 1)
def edge2_frame(frame):
    return llist_ref(frame, 2)
def frame_coord_map(frame):
    return lambda v: add_vect(origin_frame(frame), 
                         add_vect(scale_vect(xcor_vect(v), 
                                             edge1_frame(frame)), 
                                  scale_vect(ycor_vect(v), 
                                             edge2_frame(frame))))
def transform_painter(painter, origin, corner1, corner2):
    def transformed(frame):
        m = frame_coord_map(frame)
        new_origin = m(origin)
        return painter(make_frame(
                           new_origin,
                           sub_vect(m(corner1), new_origin),
                           sub_vect(m(corner2), new_origin)))
    return transformed
unit_origin = make_vect(0, 0)
unit_edge_1 = make_vect(1, 0)
unit_edge_2 = make_vect(0, 1)
unit_frame = make_frame(unit_origin, 
                              unit_edge_1,
                              unit_edge_2)
def make_segment(v_start, v_end):
    return pair(v_start, v_end)
def start_segment(v):
    return head(v)
def end_segment(v):
    return tail(v)
def for_each(fun, items):
    if is_none(items):
        return None
    else:
        fun(head(items))
        for_each(fun, tail(items))
# "drawing a line" here simulated
# by printing the coordinates of
# the start and end of the line
def draw_line(v_start, v_end):
    print("line starting at")
    print(v_start)
    print("line ending at")
    print(v_end)
def segments_to_painter(segment_list):
    return lambda frame: 
             for_each(lambda segment:
                        draw_line(
                            frame_coord_map(frame)
                                (start_segment(segment)), 
                            frame_coord_map(frame)
                                (end_segment(segment))), 
                      segment_list)
x_start_1 = make_vect(0, 0)
x_end_1 = make_vect(1, 1)
x_segment_1 = make_segment(x_start_1, 
                                 x_end_1)
x_start_2 = make_vect(1, 0)
x_end_2 = make_vect(0, 1)
x_segment_2 = make_segment(x_start_2, 
                                 x_end_2)
x_painter = segments_to_painter(
                              llist(x_segment_1, 
                                   x_segment_2))
print(x_painter(unit_frame))
def beside(painter1, painter2):
    split_point = make_vect(0.5, 0)
    paint_left  = transform_painter(painter1,
                                    make_vect(0, 0),
                                    split_point,
                                    make_vect(0, 1))
    paint_right = transform_painter(painter2,
                                    split_point,
                                    make_vect(1, 0),
                                    make_vect(0.5, 1))
    def painter(frame):
        paint_left(frame)
        paint_right(frame)
    return painter

print(beside(x_painter, x_painter)(unit_frame))
