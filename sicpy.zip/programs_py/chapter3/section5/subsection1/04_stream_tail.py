# chapter=2 
def stream_tail(stream):
    return tail(stream)()

print(head(stream_tail(pair(4, lambda: pair(5, lambda: None)))))

# expected: 5
