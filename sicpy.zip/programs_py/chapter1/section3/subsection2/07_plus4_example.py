print(plus4(3))
