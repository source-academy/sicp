def expt(b, n):
    def expt_iter(counter, product):
        return product if counter == 0 else expt_iter(counter - 1, b * product)
    return expt_iter(n, 1)

print(expt(3, 4))

# expected: 81
