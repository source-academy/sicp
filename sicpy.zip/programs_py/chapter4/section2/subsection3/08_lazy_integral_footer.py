def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
ref(solve(lambda x: x, 1, 0.1), 10)
"""
