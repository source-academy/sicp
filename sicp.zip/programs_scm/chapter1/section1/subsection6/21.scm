(define (square x) (* x x))
(define (f x y z)
   (let ((smallest (if (> x y) (if (> y z) z y) (if (> x z) z x))))
      (- (+ (square x) (square y) (square z)) (square smallest))))

(f 4 7 2)
