(define (cube x) (* x x x))
(cube 3)

; expected: 27
