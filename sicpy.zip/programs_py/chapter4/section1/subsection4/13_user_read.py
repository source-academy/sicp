# for testing, there is no user who could type an input
def user_read(prompt_string):
    return ''
