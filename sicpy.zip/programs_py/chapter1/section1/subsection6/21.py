def square(x): return x * x
def f(x, y, z):
   return (square(x) + square(y) + square(z)
           # subtract the square of the smallest
           - square((z if y > z else y) if x > y else (z if x > z else x)))

print(f(4, 7, 2))
