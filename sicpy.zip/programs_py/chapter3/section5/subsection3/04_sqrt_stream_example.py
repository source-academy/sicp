def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
max_display = 9
def display_stream(s):
    def display_stream_iter(st, n):
        if is_none(st):
            pass
        elif n == 0:
            print("", "...")
        else:
            print(head(st))
            display_stream_iter(stream_tail(st), n - 1)
    display_stream_iter(s, max_display)
def average(x, y):
    return (x + y) / 2
def sqrt_improve(guess, x):
    return average(guess, x / guess)
def sqrt_stream(x):
    return pair(1, lambda: stream_map(lambda guess: sqrt_improve(guess, x),
                                      sqrt_stream(x)))
print(stream_ref(sqrt_stream(2), 5))

# expected: 1.414213562373095
