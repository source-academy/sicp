def average(x, y):
    return (x + y) / 2
def square(x): return x * x
def average_damp(f):
    return lambda x: average(x, f(x))

print(average_damp(square)(10))

# expected: 55.0
