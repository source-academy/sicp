def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def square(x): return x * x
# tree_map to be written by student
def square_tree(tree): return tree_map(square, tree)
# square_tree to be written by student
def tree_map(f, tree):
    return map(lambda sub_tree: (None if is_none(sub_tree)
                                 else tree_map(f, sub_tree)
                                 if is_pair(sub_tree)
                                 else f(sub_tree)),
               tree)

print(tail(tail(square_tree(llist(1,
                 llist(2, llist(3, 4), 5), 
                 llist(6, 7))))))

# expected: [ [ 36, [ 49, None ] ], None ]
