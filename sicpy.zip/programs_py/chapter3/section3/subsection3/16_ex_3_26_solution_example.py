t = make_table()
get = t("lookup")
put = t("insert")
show_table = t("print")

# The test results

put(3, "d")
put(1, "a")
put(2, "b")
put(2, "c")
put(4, "e")
put(5, "f")

show_table()

print(get(2))  # prints: "c"
