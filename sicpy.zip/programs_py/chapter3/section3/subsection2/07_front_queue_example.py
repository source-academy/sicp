q = pair(pair(1, 2), 3)
print(front_queue(q))
