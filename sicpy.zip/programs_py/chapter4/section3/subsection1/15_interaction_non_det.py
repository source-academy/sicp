# chapter=3 variant=non-det 
def stream_tail(stream):
    return tail(stream)()
def stream_filter(pred, stream):
    return (None if is_none(stream)
            else pair(head(stream),
                      lambda: stream_filter(pred, stream_tail(stream)))
                if pred(head(stream))
            else stream_filter(pred, stream_tail(stream)))
def square(x): return x * x
def is_divisible(x, y):
    return x % y == 0
def integers_starting_from(n):
    return pair(n, lambda: integers_starting_from(n + 1))
def is_prime(n):
    def iter(ps):
        return (True if square(head(ps)) > n
                else False if is_divisible(n, head(ps))
                else iter(stream_tail(ps)))
    return iter(primes)

primes = pair(2,
              lambda: stream_filter(
                          is_prime,
                          integers_starting_from(3)))
def prime_sum_pair(list1, list2):
    a = an_element_of(list1)
    b = an_element_of(list2)
    require(is_prime(a + b))
    return llist(a, b)
prime_sum_pair(llist(1, 3, 5, 8), llist(20, 35, 110))
# Press the Run button for the first solution. Type
# retry
# in the REPL on the right, for more solutions
