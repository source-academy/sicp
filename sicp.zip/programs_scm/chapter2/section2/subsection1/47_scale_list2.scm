(define (scale-list items factor)
  (map (lambda (x) (* x factor))
       items))

(scale-list (list 1 2 3 4 5) 10)

; expected: [ 30, [ 40, [ 50, null ] ] ]
