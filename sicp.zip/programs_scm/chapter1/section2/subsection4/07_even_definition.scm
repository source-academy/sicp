(define (even? n)
  (= (remainder n 2) 0))

(even 7)
