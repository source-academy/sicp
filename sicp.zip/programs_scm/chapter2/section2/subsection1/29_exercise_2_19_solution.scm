;; first-denomination, except-first-denomination
;; and no-more? to be given by student
(define (cc amount coin-values)
  (cond ((= amount 0) 1)
        ((or (< amount 0) (no-more? coin-values)) 0)
        (else
         (+ (cc amount
                (except-first-denomination coin-values))
            (cc (- amount
                   (first-denomination coin-values))
                coin-values)))))
(define us-coins (list 50 25 10 5 1))

(define uk-coins (list 100 50 20 10 5 2 1))


(cc 100 us-coins)

; expected: 292
