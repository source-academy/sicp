def make_mutex():
    cell = llist(False)
    def the_mutex(m):
        return ((the_mutex('acquire')  # retry
                     if test_and_set(cell)
                 else True)
                   if m == 'acquire'
                else clear(cell) if m == 'release'
                else error('unknown request -- mutex', m))
    return the_mutex

def clear(cell):
    set_head(cell, False)
def make_serializer():
    mutex = make_mutex()
    def serializer(f):
        def serialized_f():
            mutex('acquire')
            val = f()
            mutex('release')
            return val
        return serialized_f
    return serializer
def make_account(balance):
    def withdraw(amount):
        nonlocal balance
        if balance >= amount:
            balance = balance - amount
            return balance
        else:
            return 'Insufficient funds'
    def deposit(amount):
        nonlocal balance
        balance = balance + amount
        return balance
    protect = make_serializer()
    def dispatch(m):
        return (protect(withdraw) if m == 'withdraw'
                else protect(deposit) if m == 'deposit'
                else balance if m == 'balance'
                else error('unknown request -- make_account', m))
    return dispatch
a1 = make_account(400)
a2 = make_account(100)

def peter():
    print('Peter balance a1 before', a1('balance'))
    print('Peter balance a2 before', a2('balance'))
    transfer(a1, a2, 50)
    print('Peter balance a1 after', a1('balance'))
    print('Peter balance a2 after', a2('balance'))

def paul():
    print('Paul balance a1', a1('balance'))
    print('Paul balance a2', a2('balance'))
    print('Paul balance a1', a1('balance'))
    print('Paul balance a2', a2('balance'))
    print('Paul balance a1', a1('balance'))
    print('Paul balance a2', a2('balance'))

print(concurrent_execute(peter, paul))
