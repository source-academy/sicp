(define (set-to-wow! x)
  (set-car! (car x) 'wow)
  x)
(define x (list 'a 'b))
(define z1 (cons x x))
(set-to-wow! z1)

; expected: [ [ 'wow', [ 'b', null ] ], [ 'wow', [ 'b', null ] ] ]
