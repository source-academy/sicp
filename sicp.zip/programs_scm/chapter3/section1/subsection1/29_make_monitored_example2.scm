(define s (make-monitored sqrt))
(s 100)
(s 'how-many-calls?)
