print(head(tail(head(tail(adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))))))
