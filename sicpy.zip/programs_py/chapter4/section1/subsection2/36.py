def make_conditional_expr(predicate, consequent_expression,
                          alternative_expression):
    return llist('conditional_expression', predicate,
                 consequent_expression, alternative_expression)
def make_literal(value):
    return llist('literal', value)
# Syntax selectors
def logical_operation(component):
    return head(tail(component))
def first_expression(component):
    return head(tail(tail(component)))
def second_expression(component):
    return head(tail(tail(tail(component))))
def logical_composition_to_conditional_expr(component):
    operation = logical_operation(component)
    if operation == 'and':
        return make_conditional_expr(first_expression(component),
                                     second_expression(component),
                                     make_literal(False))
    elif operation == 'or':
        return make_conditional_expr(first_expression(component),
                                     make_literal(True),
                                     second_expression(component))
    else:
        return error('unknown operation -- '
                     'logical_composition_to_conditional_expr', component)
print(logical_composition_to_conditional_expr(parse('a and b')))
print(logical_composition_to_conditional_expr(parse('a or b')))
print(logical_composition_to_conditional_expr(
          parse('(a and not b) or (not a and b)')))
