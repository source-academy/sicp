; chapter=3 variant=non-det 
(define (require p)
  (if (not p) (amb)))

; expected: 5
