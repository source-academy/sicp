# iterative process
def cont_frac(n, d, k):
    def fraction(i, current):
        return current if i == 0 else fraction(i - 1, n(i) / (d(i) + current))
    return fraction(k, 0)
def tan_cf(x, k):
    return cont_frac(lambda i: x if i == 1 else - x * x,
                     lambda i: 2 * i - 1,
                     k)

print(tan_cf(math_pi, 14))
# math_tan(math_pi)

# expected: -2.8271597168564594e-16
