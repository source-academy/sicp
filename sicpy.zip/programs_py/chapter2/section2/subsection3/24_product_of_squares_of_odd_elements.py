def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def square(x): return x * x
def is_odd(n):
    return n % 2 == 1
def times(x, y):
    return x * y
def product_of_squares_of_odd_elements(sequence):
    return reduce(times,
                  1,
                  map(square,
                      filter(is_odd, sequence)))

print(product_of_squares_of_odd_elements(llist(1, 2, 3, 4, 5)))

# expected: 225
