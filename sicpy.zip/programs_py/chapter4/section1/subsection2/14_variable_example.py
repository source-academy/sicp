my_name_statement = parse("x;")
print(is_name(my_name_statement))
print(symbol_of_name(my_name_statement))
