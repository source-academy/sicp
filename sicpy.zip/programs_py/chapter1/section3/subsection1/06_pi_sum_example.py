print(8 * pi_sum(1, 1000))
