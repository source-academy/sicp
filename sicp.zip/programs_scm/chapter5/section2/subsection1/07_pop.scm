(define (pop stack)
  (stack 'pop))

(define (push stack value)
  ((stack 'push) value))
