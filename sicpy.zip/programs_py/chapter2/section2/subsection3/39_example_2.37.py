v = llist(10, 20, 30)
m1 = llist(llist(1, 2, 3), llist(3, 5, 1), llist(1, 1, 1))
m2 = llist(llist(1, 2, 3), llist(4, 5, 6), llist(7, 8, 9))

print(matrix_times_vector(m1, v))
# transpose(m1)
# matrix_times_matrix(m1, m2)
