def make_decrementer(balance):
    return lambda amount: balance - amount
print(make_decrementer(25)(20))

# expected: 5
