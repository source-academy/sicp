sample_tree = make_code_tree(
                  make_leaf("A", 4),
                  make_code_tree(
                      make_leaf("B", 2),
                      make_code_tree(
                          make_leaf("D", 1),
                          make_leaf("C", 1))))
sample_frequencies = llist(llist("A", 4),
                           llist("B", 2),
                           llist("C", 1),
                           llist("D", 1))

print(sample_tree
      == generate_huffman_tree(sample_frequencies))
