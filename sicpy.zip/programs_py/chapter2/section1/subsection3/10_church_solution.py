one = lambda f: lambda x: f(x)
two = lambda f: lambda x: f(f(x))

def plus(n, m):
    return lambda f: lambda x: n(f)(m(f)(x))

# testing

three = plus(one, two)

def church_to_number(c):
    return c(lambda n: n + 1)(0)
print(church_to_number(three))

# expected: 3
