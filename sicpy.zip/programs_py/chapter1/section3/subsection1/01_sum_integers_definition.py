def sum_integers(a, b):
    return 0 if a > b else a + sum_integers(a + 1, b)

print(sum_integers(1, 10))

# expected: 55
