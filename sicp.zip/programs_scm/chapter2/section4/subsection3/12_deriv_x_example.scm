(deriv '(+ x 3) 'x)
