def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
def is_return_statement(component):
    return is_tagged_list(component, "return_statement")
def return_expression(component):
    return head(tail(component))

my_function_definition = parse("function f(x) { return x; }")
my_return = ref(my_function_definition, 3)
ref(my_return, 1)

# expected: [ 'name', [ 'x', null ] ]
