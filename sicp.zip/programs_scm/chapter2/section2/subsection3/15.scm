(define (accumulate op initial sequence)
  (if (null? sequence)
    initial
    (op (car sequence)
        (accumulate op initial (cdr sequence)))))
(accumulate cons nil (list 1 2 3 4 5))

; expected: [ 3, [ 4, [ 5, null ] ] ]
