def logical_and(s1, s2):
    return (1 if s1 == 1 and s2 == 1
            else (0 if s2 == 0 or s2 == 1
                  else error("invalid signal", s2))
                if s1 == 0 or s1 == 1
            else error("invalid signal", s1))
