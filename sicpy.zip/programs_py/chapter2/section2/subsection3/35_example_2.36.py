def plus(x, y):
    return x + y
seq_seq = llist(llist(1, 2, 3), llist(4, 5, 6),
                llist(7, 8, 9), llist(10, 11, 12))
print(accumulate_n(plus, 0, seq_seq))
