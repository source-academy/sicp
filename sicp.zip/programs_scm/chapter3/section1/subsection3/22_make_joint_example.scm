(define paul-acc
  (make-joint peter-acc 'open-sesame 'rosebud))
