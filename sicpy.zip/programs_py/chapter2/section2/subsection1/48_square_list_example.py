print(tail(square_linked_list(llist(1, 2, 3, 4))))
