# compose to be written by student; see EXERCISE 1.42
def square(x): return x * x
def inc(n):
    return n + 1
print(compose(square, inc)(6))
