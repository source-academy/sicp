;; same as accumulate
(define fold_right accumulate)
;; in Scheme, the operator symbol * is procedure name
(fold-right / 1 (list 1 2 3))
