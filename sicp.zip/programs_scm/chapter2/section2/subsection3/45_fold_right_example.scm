;; same as accumulate
(define fold_right accumulate)
(fold-right list nil (list 1 2 3))
