def square(x): return x * x
def f_2(x, y):
    return (lambda a, b: 
            x * square(a) + y * b + a * b)(1 + x * y, 1 - y)

print(f_2(3, 4))

# expected: 456
