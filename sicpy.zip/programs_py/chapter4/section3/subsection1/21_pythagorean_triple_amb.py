# chapter=3 variant=non-det 
def a_pythagorean_triple_between(low, high):
    i = an_integer_between(low, high)
    j = an_integer_between(i, high)
    k = an_integer_between(j, high)
    require(i * i + j * j == k * k)
    return llist(i, j, k)

a_pythagorean_triple_between(5, 15)
# Press the Run button for the first solution. Type
# retry
# in the REPL on the right, for more solutions
