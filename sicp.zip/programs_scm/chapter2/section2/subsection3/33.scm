

(count-leaves (cons (list 1 2) (list 3 4)))

; expected: 4
