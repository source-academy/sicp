def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
def average(x, y):
    return (x + y) / 2
def sqrt(x):
    return fixed_point(lambda y: average(y, x / y), 1)

print(sqrt(5))

# expected: 2.236067977499978
