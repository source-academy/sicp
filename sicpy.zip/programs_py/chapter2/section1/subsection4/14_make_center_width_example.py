def make_interval(x, y):
    return pair(x, y)
def lower_bound(i):
    return head(i)
def upper_bound(i):
    return tail(i)
my_interval = make_center_width(1, 0.5)
print(width(my_interval))
