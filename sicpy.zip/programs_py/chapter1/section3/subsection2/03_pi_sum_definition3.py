def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def pi_sum(a, b):
    return sum(lambda x: 1 / (x * (x + 2)),
               a,
               lambda x: x + 4,
               b)

print(8 * pi_sum(1, 1000))

# expected: 3.139592655589783
