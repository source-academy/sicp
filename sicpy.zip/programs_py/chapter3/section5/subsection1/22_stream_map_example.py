def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))
my_stream = pair(4, lambda: pair(5, lambda: None))
calls = 0
def inc(x):
    global calls
    calls = calls + 1
my_stream_2 = stream_map(inc, my_stream)

stream_ref(my_stream_2, 1)
stream_ref(my_stream_2, 1)
print(calls)
