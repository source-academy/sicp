print('"' == "")

# expected: False
