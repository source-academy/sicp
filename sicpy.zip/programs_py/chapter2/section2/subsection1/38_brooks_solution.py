def plus_curried(x):
    return lambda y: x + y
# brooks to be written by the student
def brooks(f, items):
    return (f if is_none(items)
            else brooks(f(head(items)), tail(items)))

print(brooks(plus_curried, llist(3, 4)))

# expected: 7
