;; in Scheme, the operator symbol + is procedure name
;; in Scheme, the operator symbol * is procedure name

(define (dot-product v w)
  (accumulate + 0 (map * v w)))

(dot-product (list 1 2) (list 3 4))

; expected: 11
