def fold_left(op, initial, sequence):
    def iter(result, rest):
        return (result if is_none(rest)
                else iter(op(result, head(rest)),
                          tail(rest)))
    return iter(initial, sequence)
def divide(x, y):
    return x / y
print(fold_left(divide, 1, llist(1, 2, 3)))
# result: 0.16666666666666666

# expected: 0.16666666666666666
