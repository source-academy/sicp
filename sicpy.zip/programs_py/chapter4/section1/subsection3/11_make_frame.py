def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

my_frame = make_frame(llist("x", "y"), llist(1, 2))
frame_symbols(my_frame)

# expected: [ 'x', [ 'y', null ] ]
