def stream_tail(stream):
    return tail(stream)()
def memo(fun):
    already_run = False
    result = None
    def memoized():
        nonlocal already_run, result
        if not already_run:
            result = fun()
            already_run = True
            return result
        else:
            return result
    return memoized
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
def stream_map_optimized(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      memo(lambda:
                           stream_map_optimized(f, stream_tail(s)))))

my_stream = pair(4, lambda: pair(5, lambda: None))

my_stream_2 = stream_map(lambda x: x, my_stream)

stream_ref(my_stream_2, 1)
stream_ref(my_stream_2, 1)
# the number 5 is shown twice
# because the same delayed
# object is forced twice

calls = 0
def inc(x):
    global calls
    calls = calls + 1
my_stream_3 = stream_map_optimized(inc, my_stream)

stream_ref(my_stream_3, 1)
stream_ref(my_stream_3, 1)
print(calls)

# expected: 2
