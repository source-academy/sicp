print(count_leaves(pair(llist(1, 2), llist(3, 4))))
