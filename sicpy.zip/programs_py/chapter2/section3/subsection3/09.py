def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def is_element_of_set(x, set):
    return (False
            if is_none(set)
            else True
            if x == head(set)
            else is_element_of_set(x, tail(set)))
def intersection_set(set1, set2):
    return (None
            if is_none(set1) or is_none(set2)
            else pair(head(set1), intersection_set(tail(set1), set2))
            if is_element_of_set(head(set1), set2)
            else intersection_set(tail(set1), set2))
def adjoin_set(x, set):
    return pair(x, set)
def union_set(set1, set2):
    return append(set1, set2)

print(tail(tail(tail(union_set(
   adjoin_set(10, adjoin_set(20, adjoin_set(30, None))),
   adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))))))

# expected: [ 10, [ 15, [ 20, None ] ] ]
