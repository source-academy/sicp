(define v (list 'a 'b 'c 'd))
