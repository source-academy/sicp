def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def square(x): return x * x
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
print(llist_ref(map(square, llist(1, 2, 3, 4, 5)), 4))

# expected: 25
