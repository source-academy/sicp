print(show(up_split(heart, 4)))
