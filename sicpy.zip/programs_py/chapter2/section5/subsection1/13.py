def attach_tag(type_tag, contents):
    return (pair("python_number", contents)
            if is_number(contents)
            else pair(type_tag, contents))
def type_tag(datum):
    return ("python_number"
            if is_number(datum)
            else head(datum)
            if is_pair(datum)
            else error("bad tagged datum -- type_tag", datum))
def contents(datum):
    return (datum
            if is_number(datum)
            else tail(datum)
            if is_pair(datum)
            else error("bad tagged datum -- contents", datum))
