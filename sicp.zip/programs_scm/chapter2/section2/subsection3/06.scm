(define (square x) (* x x))
(define (map proc items)
  (if (null? items)
      nil
      (cons (proc (car items))
            (map proc (cdr items)))))
(map square (list 1 2 3 4 5))

; expected: 25
