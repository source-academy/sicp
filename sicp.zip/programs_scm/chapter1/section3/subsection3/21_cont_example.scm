;; cont-frac to be written by student; see exercise 1.37
(cont-frac (lambda (i) 1.0)
           (lambda (i) 1.0)
           k)
