def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
print(tail(map(lambda x: x * x, llist(1, 2, 3, 4))))

# expected: [ 4, [ 9, [ 16, None ] ] ]
