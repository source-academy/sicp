a_pythagorean_triple_between(5, 15)
"""
