((application? exp)
(apply (actual-value (operator exp) env)
       (operands exp)
       env))

(define the-global-environment (setup-environment))
(eval (read) the-global-environment)

; expected: 3
