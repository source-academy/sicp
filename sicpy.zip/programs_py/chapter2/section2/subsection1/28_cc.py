# first_denomination, except_first_denomination
# and no_more to be given by student
us_coins = llist(50, 25, 10, 5, 1)
uk_coins = llist(100, 50, 20, 10, 5, 2, 1)
def cc(amount, coin_values):
    return (1 if amount == 0
            else 0 if amount < 0 or no_more(coin_values)
            else cc(amount, except_first_denomination(coin_values)) +
                 cc(amount - first_denomination(coin_values), coin_values))

print(cc(100, us_coins))
