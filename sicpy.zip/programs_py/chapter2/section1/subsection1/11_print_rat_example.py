def make_rat(n, d): return pair(n, d)

def numer(x): return head(x)

def denom(x): return tail(x)
def print_rat(x):
    print(str(numer(x)) + " / " + str(denom(x)))
one_half = make_rat(1, 2)

print(one_half)

# expected: [ 1, 2 ]
