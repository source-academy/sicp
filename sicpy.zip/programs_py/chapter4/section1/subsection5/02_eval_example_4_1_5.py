eval('5 * 5')

print(eval('5 * 5'))
