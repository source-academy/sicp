

; expected: [ 22, [ 26, [ 30, null ] ] ]
