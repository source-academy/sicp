def square(x): return x * x
# square_tree to be written by student
def square_tree(tree):
    return (None if is_none(tree)
            else square(tree) if not is_pair(tree)
            else pair(square_tree(head(tree)),
                      square_tree(tail(tree))))

print(tail(tail(square_tree(llist(1,
                 llist(2, llist(3, 4), 5), 
                 llist(6, 7))))))

# expected: [ [ 36, [ 49, None ] ], None ]
