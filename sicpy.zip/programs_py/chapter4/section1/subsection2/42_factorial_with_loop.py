def factorial(n):
    product = 1
    counter = 1
    while counter <= n:
        product = counter * product
        counter = counter + 1
    return product
