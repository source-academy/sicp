def count_pairs(x):
    return (0 if not is_pair(x)
            else count_pairs(head(x)) +
                 count_pairs(tail(x)) +
                 1)
three_list = llist("a", "b", "c")
one = pair("d", "e")
two = pair(one, one)
four_list = pair(two, "f")
seven_list = pair(two, two)
cycle = llist("g", "h", "i")
set_tail(tail(tail(cycle)), cycle)

# return 3; return 4; return 7
print(count_pairs(three_list))
print(count_pairs(four_list))
print(count_pairs(seven_list))

# never return at all
print(count_pairs(cycle))
