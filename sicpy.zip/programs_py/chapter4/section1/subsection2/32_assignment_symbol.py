def is_tagged_list(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))

my_assignment_statement = parse("x = 1")
print(is_declaration(my_assignment_statement))
print(assignment_symbol(my_assignment_statement))
print(assignment_value_expression(my_assignment_statement))
