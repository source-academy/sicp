# chapter=3 variant=non-det 
def an_integer_starting_from(n):
    return amb(n, an_integer_starting_from(n + 1))

x = an_integer_starting_from(1)
require(x >= 4.5)
x
# Press the Run button for the first solution. Type
# retry
# in the REPL on the right, for more solutions
