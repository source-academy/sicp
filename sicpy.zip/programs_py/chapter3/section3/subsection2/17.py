def make_queue():
    return pair(None, None)
def front_ptr(queue):
    return head(queue)

def rear_ptr(queue):
    return tail(queue)

def set_front_ptr(queue, item):
    set_head(queue, item)

def set_rear_ptr(queue, item):
    set_tail(queue, item)
def is_empty_queue(queue):
    return is_none(front_ptr(queue))
def insert_queue(queue, item):
    new_pair = pair(item, None)
    if is_empty_queue(queue):
        set_front_ptr(queue, new_pair)
        set_rear_ptr(queue, new_pair)
    else:
        set_tail(rear_ptr(queue), new_pair)
        set_rear_ptr(queue, new_pair)
    return queue
def delete_queue(queue):
    if is_empty_queue(queue):
        error("delete_queue called with an empty queue", queue)
    else:
        set_front_ptr(queue, tail(front_ptr(queue)))
        return queue
def print_queue(q):
    return print(head(q))

q1 = make_queue()
print_queue(q1)  # prints: None
insert_queue(q1, "a")
print_queue(q1)  # prints: ["a", None]
insert_queue(q1, "b")
print_queue(q1)  # prints: ["a", ["b", None]]
delete_queue(q1)
print(print_queue(q1))  # prints: ["b", None]
