def make_sum(a1, a2): return llist("+", a1, a2)

def make_product(m1, m2): return llist("*", m1, m2)
def addend(s): return head(tail(s))

print(addend(make_sum("x", 3)))

# expected: 'x'
