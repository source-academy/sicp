def plus_curried(x):
    return lambda y: x + y
# brooks_curried to be written by the student
print(brooks_curried(llist(plus_curried, 3, 4)))
