(define (make-decrementer balance)
            (lambda (amount)
            (- balance amount)))
((make-decrementer 25) 20)

; expected: 5
