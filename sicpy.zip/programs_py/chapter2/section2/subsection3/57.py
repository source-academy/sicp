def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def enumerate_interval(low, high):
    return (None if low > high
            else pair(low,
                      enumerate_interval(low + 1, high)))
n = 6
print(length(accumulate(append,
           None,
           map(lambda i: map(lambda j: llist(i, j),
                             enumerate_interval(1, i - 1)),
               enumerate_interval(1, n)))))

# expected: 15
