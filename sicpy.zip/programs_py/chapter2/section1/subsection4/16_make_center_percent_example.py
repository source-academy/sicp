my_interval = make_center_percent(6.0, 10)
print(percent(my_interval))
