f_1 = llist("A", 4)
my_frequency_1 = attach_tag("frequency_list", f_1)

print(type_tag(my_frequency_1))
