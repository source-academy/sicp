print(tail(tail(tail(union_set(
   adjoin_set(10, adjoin_set(20, adjoin_set(30, None))),
   adjoin_set(10, adjoin_set(15, adjoin_set(20, None))))))))
