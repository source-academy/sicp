is_tagged_list(llist("name", "x"), "name")
