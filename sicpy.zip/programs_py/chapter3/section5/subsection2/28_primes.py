def stream_tail(stream):
    return tail(stream)()
def stream_filter(pred, stream):
    return (None if is_none(stream)
            else pair(head(stream),
                      lambda: stream_filter(pred, stream_tail(stream)))
                if pred(head(stream))
            else stream_filter(pred, stream_tail(stream)))
def square(x): return x * x
def is_divisible(x, y):
    return x % y == 0
def integers_starting_from(n):
    return pair(n, lambda: integers_starting_from(n + 1))
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
def is_prime(n):
    def iter(ps):
        return (True if square(head(ps)) > n
                else False if is_divisible(n, head(ps))
                else iter(stream_tail(ps)))
    return iter(primes)

primes = pair(2,
              lambda: stream_filter(is_prime,
                                    integers_starting_from(3)))

print(stream_ref(primes, 50))

# expected: 233
