balance = 100
def withdraw(amount):
    global balance
    if balance >= amount:
        balance = balance - amount
        return balance
    else:
        return "Insufficient funds"

print(withdraw(25))  # output: 75

# expected: 75
