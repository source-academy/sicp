print(f(5))
