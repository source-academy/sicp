def conditional(predicate, then_clause, else_clause):
    return then_clause if predicate else else_clause
print(conditional(2 == 3, 0, 5))
