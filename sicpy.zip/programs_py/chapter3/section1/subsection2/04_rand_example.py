rand()
rand()
print(rand())
