(define (inc n) (+ n 1))




; expected: 21
