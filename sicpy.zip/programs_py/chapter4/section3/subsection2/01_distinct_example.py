distinct(llist(1, 2, 4, 4, 5))
