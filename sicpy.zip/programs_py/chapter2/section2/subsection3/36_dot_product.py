def accumulate(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    accumulate(op, initial, tail(sequence))))
def plus(x, y):
    return x + y
def times(x, y):
    return x * y
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def accumulate_n(op, init, seqs):
    return (None if is_none(head(seqs))
            else pair(accumulate(op, init, map(lambda x: head(x), seqs)),
                      accumulate_n(op, init, map(lambda x: tail(x), seqs))))
def dot_product(v, w):
    return accumulate(plus, 0, accumulate_n(times, 1, llist(v, w)))

print(dot_product(llist(1, 2), llist(3, 4)))

# expected: 11
