(find-variable 'w '((y z) (a b c d e) (x y)))
