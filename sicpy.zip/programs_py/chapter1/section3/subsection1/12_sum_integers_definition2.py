def sum(term, a, next, b):
    return 0 if a > b else term(a) + sum(term, next(a), next, b)
def inc(n):
    return n + 1
def identity(x):
    return x
def sum_integers(a, b):
    return sum(identity, a, inc, b)

print(sum_integers(1, 10))

# expected: 55
