import { heart, stack, beside, flip_vert, show } from 'rune';

heart2 = beside(heart, flip_vert(heart))
# heart4 = stack(heart2, heart2)

print(show(heart2))
# show(heart4)
