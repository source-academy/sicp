def scale_linked_list(items, factor):
    return (None if is_none(items)
            else pair(head(items) * factor,
                      scale_linked_list(tail(items), factor)))
print(tail(tail(scale_linked_list(llist(1, 2, 3, 4, 5), 10))))
