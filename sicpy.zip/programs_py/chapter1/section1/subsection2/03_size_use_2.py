size = 2
print(5 * size)

# expected: 10
