def greater_or_equal(x, y):
    return not (x < y)

print(greater_or_equal(7, 4))
