def ref(items, n):
    return (head(items) if n == 0
            else ref(tail(items), n - 1))
ref(integers, 17)
"""
