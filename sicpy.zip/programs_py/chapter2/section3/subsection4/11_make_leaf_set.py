def make_leaf(symbol, weight):
    return llist("leaf", symbol, weight)
def is_leaf(object):
    return head(object) == "leaf"
def symbol_leaf(x): return head(tail(x))

def weight_leaf(x): return head(tail(tail(x)))
def left_branch(tree): return head(tail(tree))

def right_branch(tree): return head(tail(tail(tree)))

def symbols(tree):
    return (llist(symbol_leaf(tree))
            if is_leaf(tree)
            else head(tail(tail(tail(tree)))))
def weight(tree):
    return (weight_leaf(tree)
            if is_leaf(tree)
            else head(tail(tail(tail(tail(tree))))))
def adjoin_set(x, set):
    return (llist(x)
            if is_none(set)
            else pair(x, set)
            if weight(x) < weight(head(set))
            else pair(head(set), adjoin_set(x, tail(set))))
def make_leaf_set(pairs):
    if is_none(pairs):
        return None
    else:
        first_pair = head(pairs)
        return adjoin_set(
                   make_leaf(head(first_pair),        # symbol
                             head(tail(first_pair))), # frequency
                   make_leaf_set(tail(pairs)))

print(head(make_leaf_set( llist(llist("A", 4),
                          llist("B", 2),
                          llist("C", 1),
                          llist("D", 1)))))

# expected: [ 'leaf', [ 'D', [ 1, None ] ] ]
