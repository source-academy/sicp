my_leaf = make_leaf("A", 8)

print(weight_leaf(my_leaf))
