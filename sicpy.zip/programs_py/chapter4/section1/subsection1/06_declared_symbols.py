def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
def map(fun, items):
    return (None if is_none(items)
            else pair(fun(head(items)),
                      map(fun, tail(items))))
def reduce(op, initial, sequence):
    return (initial if is_none(sequence)
            else op(head(sequence),
                    reduce(op, initial, tail(sequence))))
def is_tagged_llist(component, the_tag):
    return is_pair(component) and head(component) == the_tag
def is_name(component):
    return is_tagged_llist(component, 'name')
def symbol_of_name(component):
    return head(tail(component))
def is_global_statement(component):
    return is_tagged_llist(component, 'global_statement')
def is_nonlocal_statement(component):
    return is_tagged_llist(component, 'nonlocal_statement')
def declaration_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def is_assignment(component):
    return is_tagged_llist(component, 'assignment')
def assignment_symbol(component):
    return symbol_of_name(head(tail(component)))
def assignment_value_expression(component):
    return head(tail(tail(component)))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def is_function_definition(component):
    return is_tagged_llist(component, 'function_definition')
def function_definition_name(component):
    return llist_ref(component, 1)
def function_definition_symbol(component):
    return symbol_of_name(function_definition_name(component))
def function_definition_parameters(component):
    return llist_ref(component, 2)
def function_definition_parameter_symbols(component):
    return map(symbol_of_name, function_definition_parameters(component))
def function_definition_body(component):
    return llist_ref(component, 3)
# functions from SICP Python 4.1.1
def evaluate(component, env):
    if is_literal(component):
        return literal_value(component)
    elif is_name(component):
        return lookup_symbol_value(symbol_of_name(component), env)
    elif is_application(component):
        return apply(evaluate(function_expression(component), env),
                     llist_of_values(arg_expressions(component), env))
    elif is_operator_combination(component):
        return evaluate(operator_combination_to_application(component),
                        env)
    elif is_conditional(component):
        return eval_conditional(component, env)
    elif is_lambda_expression(component):
        return make_function(lambda_parameter_symbols(component),
                             make_return_statement(lambda_body(component)),
                             env)
    elif is_sequence(component):
        return eval_sequence(sequence_statements(component), env)
    elif is_return_statement(component):
        return eval_return_statement(component, env)
    elif is_function_definition(component):
        return eval_function_definition(component, env)
    elif (is_pass_statement(component) or
          is_global_statement(component) or
          is_nonlocal_statement(component)):
        return None
    elif is_assignment(component):
        return eval_assignment(component, env)
    else:
        return error('unknown syntax -- evaluate', component)
def apply(fun, arguments):
    if is_built_in_function(fun):
        return apply_built_in_function(fun, arguments)
    elif is_compound_function(fun):
        body = function_body(fun)
        globals = global_variables(body)
        others = append(globals, nonlocal_variables(body))
        locals = filter(lambda symbol: is_none(member(symbol, others)),
                        assigned_variables(body))
        unassigned_markers = map(lambda symbol: '*unassigned*', locals)
        global_markers = map(lambda symbol: '*global*', globals)
        result = evaluate(body,
                          extend_environment(
                              append(function_parameters(fun),
                                     append(locals,
                                            globals)),
                              append(arguments,
                                     append(unassigned_markers,
                                            global_markers)),
                              function_environment(fun)))
        if is_return_value(result):
            return return_value_content(result)
        else:
            return None
    else:
        return error('unknown function type -- apply', fun)
def llist_of_values(exps, env):
    return map(lambda arg: evaluate(arg, env), exps)
def eval_conditional(component, env):
    if is_truthy(evaluate(conditional_predicate(component), env)):
        return evaluate(conditional_consequent(component), env)
    else:
        return evaluate(conditional_alternative(component), env)
def eval_sequence(stmts, env):
    if is_empty_sequence(stmts):
        return None
    elif is_last_statement(stmts):
        return evaluate(first_statement(stmts), env)
    else:
        first_stmt_value = evaluate(first_statement(stmts), env)
        if is_return_value(first_stmt_value):
            return first_stmt_value
        else:
            return eval_sequence(rest_statements(stmts), env)
def eval_return_statement(component, env):
    return make_return_value(evaluate(return_expression(component),
                                      env))
def eval_assignment(component, env):
    value = evaluate(assignment_value_expression(component), env)
    assign_symbol_value(assignment_symbol(component), value, env)
    return value
def eval_function_definition(component, env):
    fun = make_function(function_definition_parameter_symbols(component),
                        function_definition_body(component),
                        env)
    assign_symbol_value(function_definition_symbol(component), fun, env)
    return None
def filter(predicate, sequence):
    return (None if is_none(sequence)
            else pair(head(sequence),
                      filter(predicate, tail(sequence)))
            if predicate(head(sequence))
            else filter(predicate, tail(sequence)))
def member(item, x):
    return (None if is_none(x)
            else x if item == head(x)
            else member(item, tail(x)))

# functions from SICP JS 4.1.2
def is_literal(component):
    return is_tagged_llist(component, 'literal')
def literal_value(component):
    return head(tail(component))
def make_literal(value):
    return llist('literal', value)
def make_name(symbol):
    return llist('name', symbol)
def is_lambda_expression(component):
    return is_tagged_llist(component, 'lambda_expression')
def lambda_parameter_symbols(component):
    return map(symbol_of_name, head(tail(component)))
def lambda_body(component):
    return head(tail(tail(component)))
def is_return_statement(component):
    return is_tagged_llist(component, 'return_statement')
def return_expression(component):
    return head(tail(component))
def make_return_statement(expression):
    return llist('return_statement', expression)
def is_pass_statement(component):
    return is_tagged_llist(component, 'pass_statement')
def is_conditional(component):
    return (is_tagged_llist(component, 'conditional_expression') or
            is_tagged_llist(component, 'conditional_statement'))
def conditional_predicate(component):
    return llist_ref(component, 1)
def conditional_consequent(component):
    return llist_ref(component, 2)
def conditional_alternative(component):
    return llist_ref(component, 3)
def is_sequence(stmt):
    return is_tagged_llist(stmt, 'sequence')
def sequence_statements(stmt):
    return head(tail(stmt))
def first_statement(stmts):
    return head(stmts)
def rest_statements(stmts):
    return tail(stmts)
def is_empty_sequence(stmts):
    return is_none(stmts)
def is_last_statement(stmts):
    return is_none(tail(stmts))
def is_operator_combination(component):
    return is_unary_operator_combination(component) or is_binary_operator_combination(component)
def is_unary_operator_combination(component):
    return is_tagged_llist(component, 'unary_operator_combination')
def is_binary_operator_combination(component):
    return is_tagged_llist(component, 'binary_operator_combination')
def operator_symbol(component):
    return llist_ref(component, 1)
def first_operand(component):
    return llist_ref(component, 2)
def second_operand(component):
    return llist_ref(component, 3)
def make_application(function_expression, argument_expressions):
    return llist('application', function_expression, argument_expressions)
def operator_combination_to_application(component):
    operator = operator_symbol(component)
    if is_unary_operator_combination(component):
        return make_application(make_name(operator),
                                llist(first_operand(component)))
    else:
        return make_application(make_name(operator),
                                llist(first_operand(component),
                                      second_operand(component)))
def is_application(component):
    return is_tagged_llist(component, 'application')
def function_expression(component):
    return head(tail(component))
def arg_expressions(component):
    return head(tail(tail(component)))

# functions from SICP Python 4.1.3
def is_truthy(x):
    if is_boolean(x):
        return x
    else:
        error('boolean expected, received', x)
def is_falsy(x):
    return not is_truthy(x)
def make_function(parameters, body, env):
    return llist('compound_function', parameters, body, env)
def is_compound_function(f):
    return is_tagged_llist(f, 'compound_function')
def function_parameters(f):
    return llist_ref(f, 1)

def function_body(f):
    return llist_ref(f, 2)

def function_environment(f):
    return llist_ref(f, 3)
def make_return_value(content):
    return llist('return_value', content)
def is_return_value(value):
    return is_tagged_llist(value, 'return_value')
def return_value_content(value):
    return head(tail(value))
def enclosing_environment(env):
    return tail(env)

def first_frame(env):
    return head(env)

the_empty_environment = None
def make_frame(symbols, values):
    return pair(symbols, values)

def frame_symbols(frame):
    return head(frame)

def frame_values(frame):
    return tail(frame)

def add_binding_to_frame(symbol, val, frame):
    set_head(frame, pair(symbol, head(frame)))
    set_tail(frame, pair(val, tail(frame)))
def length(items):
    return (0 if is_none(items)
            else 1 + length(tail(items)))
def extend_environment(symbols, vals, base_env):
    if length(symbols) == length(vals):
        return pair(make_frame(symbols, vals), base_env)
    elif length(symbols) < length(vals):
        error('too many arguments supplied', pair(symbols, vals))
    else:
        error('too few arguments supplied', pair(symbols, vals))
built_in_constants = llist(llist('math_pi', math_pi), llist('math_e', math_e))
built_in_constant_symbols = map(lambda c: head(c), built_in_constants)
built_in_constant_values = map(lambda c: head(tail(c)), built_in_constants)
def is_built_in_function(fun):
    return is_tagged_llist(fun, 'built_in')

def built_in_implementation(fun):
    return head(tail(fun))
def print_without_environments(*objects):
    def prepare(object):
        if is_compound_function(object):
            return '<compound-function>'
        elif is_built_in_function(object):
            return '<built-in-function>'
        elif is_pair(object):
            return pair(prepare(head(object)), prepare(tail(object)))
        else:
            return object
    return apply_in_underlying_python(print,
                                      map(prepare, llist(*objects)))
built_in_functions = llist(llist('head', head), llist('tail', tail), llist('pair', pair), llist('is_none', is_none), llist('llist', llist), llist('print', print_without_environments), llist('error', error), llist('abs', abs), llist('+', lambda x, y: x + y), llist('-', lambda x, y: x - y), llist('*', lambda x, y: x * y), llist('/', lambda x, y: x / y), llist('//', lambda x, y: x // y), llist('%', lambda x, y: x % y), llist('**', lambda x, y: x ** y), llist('==', lambda x, y: x == y), llist('!=', lambda x, y: x != y), llist('<', lambda x, y: x < y), llist('<=', lambda x, y: x <= y), llist('>', lambda x, y: x > y), llist('>=', lambda x, y: x >= y), llist('is', lambda x, y: x is y), llist('is not', lambda x, y: x is not y), llist('not', lambda x: not x), llist('-unary', lambda x: -x), llist('+unary', lambda x: +x))
built_in_function_symbols = map(head, built_in_functions)
built_in_function_objects = map(lambda fun: llist('built_in', head(tail(fun))), built_in_functions)
def setup_environment():
    built_in_environment = extend_environment(
        append(built_in_function_symbols, built_in_constant_symbols),
        append(built_in_function_objects, built_in_constant_values),
        the_empty_environment)
    return extend_environment(None, None, built_in_environment)
the_global_environment = setup_environment()
def lookup_symbol_value(symbol, env):
    def env_loop(env):
        def scan(symbols, vals):
            if is_none(symbols):
                return env_loop(enclosing_environment(env))
            elif symbol == head(symbols):
                if head(vals) == '*global*':
                    return lookup_symbol_value(symbol, the_global_environment)
                else:
                    return head(vals)
            else:
                return scan(tail(symbols), tail(vals))
        if env is the_empty_environment:
            error('unbound name', symbol)
        else:
            frame = first_frame(env)
            return scan(frame_symbols(frame), frame_values(frame))
    return env_loop(env)
def assign_symbol_value(symbol, val, env):
    def scan(symbols, vals):
        if is_none(symbols):
            if env is the_global_environment:
                add_binding_to_frame(symbol, val, first_frame(env))
            else:
                assign_symbol_value(symbol, val, enclosing_environment(env))
        elif symbol == head(symbols):
            if head(vals) == '*global*':
                assign_symbol_value(symbol, val, the_global_environment)
            else:
                set_head(vals, val)
        else:
            scan(tail(symbols), tail(vals))
    frame = first_frame(env)
    scan(frame_symbols(frame), frame_values(frame))

# functions from SICP Python 4.1.4
def apply_built_in_function(fun, arg_llist):
    return apply_in_underlying_python(built_in_implementation(fun), arg_llist)

def declared_symbols(component, is_declaration):
    if is_sequence(component):
        return reduce(append,
                      None,
                      map(lambda statement: declared_symbols(statement,
                                                             is_declaration),
                          sequence_statements(component)))
    elif is_conditional(component):
        return append(declared_symbols(conditional_consequent(component),
                                       is_declaration),
                      declared_symbols(conditional_alternative(component),
                                       is_declaration))
    elif is_declaration(component):
        return target_symbols(component)
    else:
        return None
def target_symbols(component):
    if is_assignment(component):
        return llist(assignment_symbol(component))
    elif is_function_definition(component):
        return llist(function_definition_symbol(component))
    else:
        return declaration_symbols(component)
def global_variables(component):
    return declared_symbols(component, is_global_statement)
def nonlocal_variables(component):
    return declared_symbols(component, is_nonlocal_statement)
def assigned_variables(component):
    return declared_symbols(
        component,
        lambda statement: (is_assignment(statement) or
                           is_function_definition(statement)))

print(global_variables(parse('global x\nnonlocal y\nx = 1')))

# expected: ['x', None]
