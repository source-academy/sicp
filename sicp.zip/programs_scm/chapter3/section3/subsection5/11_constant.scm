(define (has-value? connector)
  (connector 'has-value?))

(define (get-value connector)
  (connector 'value))

(define (set-value! connector new-value informant)
  ((connector 'set-value!) new-value informant))

(define (forget-value! connector retractor)
  ((connector 'forget) retractor))

(define (connect connector new-constraint)
  ((connector 'connect) new-constraint))
(define (constant value connector)
  (define (me request)
    (error "Unknown request - - CONSTANT" request))
  (connect connector me)
  (set-value! connector value me)
  me)
