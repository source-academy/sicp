const a = make_account(100, "rosebud");
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
a("withdraw", "rosebad")(50);
