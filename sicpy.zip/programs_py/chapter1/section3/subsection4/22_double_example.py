# double to be written by student; see EXERCISE 1.41
def inc(n):
    return n + 1
print(double(double(double))(inc)(5))
