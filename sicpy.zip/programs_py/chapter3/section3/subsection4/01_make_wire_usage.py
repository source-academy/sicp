def call_each(functions):
    if is_none(functions):
        return "done"
    else:
        head(functions)()
        return call_each(tail(functions))
def make_wire():
    signal_value = 0
    action_functions = None
    def set_my_signal(new_value):
        nonlocal signal_value
        if signal_value != new_value:
            signal_value = new_value
            return call_each(action_functions)
        else:
            return "done"
    def accept_action_function(fun):
        nonlocal action_functions
        action_functions = pair(fun, action_functions)
        fun()
    def dispatch(m):
        return (signal_value if m == "get_signal"
                else set_my_signal if m == "set_signal"
                else accept_action_function if m == "add_action"
                else error("unknown operation -- wire", m))
    return dispatch
a = make_wire()
b = make_wire()
c = make_wire()
d = make_wire()
e = make_wire()
s = make_wire()
