(define (square x) (* x x))
(square (+ 2 5))
