(define (make-decrementer balance)
            (lambda (amount)
            (- balance amount)))
(define D (make-decrementer 25))
(D 20)

; expected: 5
