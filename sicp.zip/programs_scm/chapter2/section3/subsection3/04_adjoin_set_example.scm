(adjoin-set 10 (adjoin-set 15 (adjoin-set 20 nil)))
