print(llist("a", "b", "c"))
# ["a", ["b", ["c", None]]]

# expected: [ 'a', [ 'b', [ 'c', None ] ] ]
