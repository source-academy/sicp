print(is_element_of_set(20,
    make_tree(10,
        None,
        make_tree(30,
            make_tree(20, None, None),
            None))))
