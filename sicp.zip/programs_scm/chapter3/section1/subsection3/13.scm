(define (make-decrementer balance)
            (lambda (amount)
            (- balance amount)))
(define D1 (make-decrementer 25))

(define D2 (make-decrementer 25))
