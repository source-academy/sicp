# make_joint to be written by students
paul_acc = make_joint(peter_acc, "open sesame", "rosebud")
