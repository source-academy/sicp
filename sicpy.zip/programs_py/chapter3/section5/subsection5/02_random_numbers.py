def stream_tail(stream):
    return tail(stream)()
def stream_ref(s, n):
    return (head(s) if n == 0
            else stream_ref(stream_tail(s), n - 1))

def stream_map(f, s):
    return (None if is_none(s)
            else pair(f(head(s)),
                      lambda: stream_map(f, stream_tail(s))))

def stream_for_each(fun, s):
    if is_none(s):
        return True
    else:
        fun(head(s))
        return stream_for_each(fun, stream_tail(s))
# A very simple rand_update function computes a number
# from 0 (inclusive) to 200560490131 (a large prime)
# from a value x by multiplying it with a constant a,
# adding a constant b, and then taking the remainder
# of dividing it by the large prime. We used it here
# for illustration only, and do not claim any
# statistical properties.
m = 200560490131
a = 1103515245
b = 12345

def rand_update(x):
    return (a * x + b) % m
random_init = 123456789
random_numbers = pair(random_init,
                      lambda: stream_map(rand_update, random_numbers))

print(stream_ref(random_numbers, 4))

# expected: 15486198720
