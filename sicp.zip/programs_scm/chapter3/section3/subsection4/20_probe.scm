(define (make-agenda) (list 0))
                
(define (current-time agenda) (car agenda))
                
(define (set-current-time! agenda time)
  (set-car! agenda time))
                
(define (segments agenda) (cdr agenda))
                
(define (set-segments! agenda segments)
  (set-cdr! agenda segments))
                
(define (first-segment agenda) (car (segments agenda)))
                
(define (rest-segments agenda) (cdr (segments agenda)))
(define the-agenda (make-agenda))
(define inverter-delay 2)
(define and-gate-delay 3)
(define or-gate-delay 5)
(define (get-signal wire)
  (wire 'get-signal))
                
(define (set-signal! wire new-value)
  ((wire 'set-signal!) new-value))
                

(define (add-action! wire action-procedure)
  ((wire 'add-action!) action-procedure))
(define (probe name wire)
  (add-action! wire
               (lambda ()
                 (newline)
                 (display name)
                 (display " ")
                 (display (current-time the-agenda))
                 (display "  New-value = ")
                 (display (get-signal wire)))))
