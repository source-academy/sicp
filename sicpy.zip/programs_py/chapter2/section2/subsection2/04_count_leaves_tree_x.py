x = pair(llist(1, 2), llist(3, 4))
def count_leaves(x):
    return (0 if is_none(x)
            else 1 if not is_pair(x)
            else count_leaves(head(x)) + count_leaves(tail(x)))
print(count_leaves(x))

# expected: 4
