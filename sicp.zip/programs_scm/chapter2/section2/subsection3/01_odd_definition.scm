(define (odd? n)
  (= (remainder n 2) 1))
