def last_pair(x):
    return (x if is_none(tail(x))
            else last_pair(tail(x)))
def llist_ref(items, n):
    return (head(items) if n == 0
            else llist_ref(tail(items), n - 1))
def make_cycle(x):
    set_tail(last_pair(x), x)
    return x

z = make_cycle(llist("a", "b", "c"))
print(llist_ref(z, 100))
