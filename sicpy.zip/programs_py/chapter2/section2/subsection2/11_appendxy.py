def append(list1, list2):
    return (list2 if is_none(list1)
            else pair(head(list1), append(tail(list1), list2)))
x = llist(1, 2, 3)

y = llist(4, 5, 6)
append(x, y)
