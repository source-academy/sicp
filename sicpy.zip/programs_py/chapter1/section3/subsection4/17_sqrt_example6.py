def abs(x):
    return x if x >= 0 else - x
tolerance = 0.00001
def fixed_point(f, first_guess):
    def close_enough(x, y):
        return abs(x - y) < tolerance
    def try_with(guess):
        next = f(guess)
        return next if close_enough(guess, next) else try_with(next)
    return try_with(first_guess)
def fixed_point_of_transform(g, transform, guess):
    return fixed_point(transform(g), guess)
def square(x): return x * x
dx = 0.00001
def deriv(g):
    return lambda x: (g(x + dx) - g(x)) / dx
def newton_transform(g):
    return lambda x: x - g(x) / deriv(g)(x)
def newtons_method(g, guess):
    return fixed_point(newton_transform(g), guess)
def sqrt(x):
    return fixed_point_of_transform(lambda y: square(y) - x,
                                    newton_transform,
                                    1)
print(sqrt(6))
