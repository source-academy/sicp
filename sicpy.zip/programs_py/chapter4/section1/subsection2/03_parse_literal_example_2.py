parse("'hello world'")
