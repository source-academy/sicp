print(head(tail(head(tail(deriv(llist("*", llist("*", "x", "y"), llist("+", "x", 3)), "x"))))))
