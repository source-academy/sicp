def square(x): return x * x
def f_3(x, y):
    a = 1 + x * y
    b = 1 - y
    return x * square(a) + y * b + a * b

print(f_3(3, 4))

# expected: 456
