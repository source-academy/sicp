(deriv '(* (* x y) (+ x 3)) 'x)
