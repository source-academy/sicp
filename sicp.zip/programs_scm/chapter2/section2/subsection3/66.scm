(define (flatmap proc seq)
  (accumulate append nil (map proc seq)))
(define (permutations s)
  (if (null? s)             ; empty set?
    (list nil)              ; sequence containing empty set
    (flatmap (lambda (x)
               (map (lambda (p) (cons x p))
                    (permutations (remove x s))))
             s)))

(permutations (list 1 2 3))

; expected: 6
