def average(x, y):
    return (x + y) / 2
def average_damp(f):
    return lambda x: average(x, f(x))
def square(x): return x * x
print(average_damp(square)(10))
